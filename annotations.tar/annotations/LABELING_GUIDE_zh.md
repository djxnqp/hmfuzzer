# 75 条最终候选：人工标注指南

## 1. 原则与独立性

- 标注对象是冻结证据所支持的结论，不是模型 `analysis` 的措辞是否可信。完整驱动、选中日志、完整日志和原始分析均在对应 `evidence/E_*.json` 中。
- A、B 两位标注者须独立阅读并逐条判断。不得查看对方文件、协调员表或系统去重预测。两份任务仅顺序不同，任务集合完全相同。
- 模板中的 POS/NEG 历史抽样标签、`is_effective` 和模型结论都不是人工真值。不得把 AI 输出直接复制为人工标签。
- 每一行均须由真实标注者填写 `reviewer_id`、完成时间、理由，并将 `human_attestation` 填为 `YES`。使用 AI 辅助分诊时填写 `ai_assistance_used=YES` 并说明用途；最终判断和理由仍须由本人核实。AI 字段不参与指标计算。
- 不要改写 `task_id`、`review_key`、`pair_id`、证据路径或证据文件。留空表示未完成，评分脚本会拒绝计算。

## 2. 候选的五级分层标签（`final_label`，单选）

按以下顺序作判断，避免把“有报错”直接等同于“有漏洞”：

1. **`security_vulnerability`**：证据指向 HarmonyOS 应用层 API 或被测系统实现中的安全性质缺陷，并给出可辨认的安全影响或违反的安全策略，例如越权、认证/授权绕过、敏感信息泄露、注入、可被攻击者利用的内存或资源安全问题。必须有驱动和日志支持，不能只因分析文本声称存在 CWE 就选此项。
2. **`functional_defect`**：证据支持真实的功能/健壮性缺陷，但不足以建立安全影响或攻击者可利用性，例如非预期崩溃、错误状态未处理、资源释放问题而安全后果未证实。
3. **`expected_rejection`**：日志反映的是 API 按文档或常规契约拒绝非法输入、缺失权限、无效参数或不支持的操作，且没有证据表明拒绝机制被绕过或造成额外安全/功能缺陷。
4. **`driver_or_environment_error`**：主要异常来自测试驱动自身、示例代码误用、编译/运行接入、设备或系统环境、无关后台服务、日志噪声，不能归因于目标 API 缺陷。若目标缺陷与驱动错误同时存在，须在理由中说明并按有直接证据的目标缺陷分类。
5. **`inconclusive`**：现有证据不足、证据互相矛盾，或需要未提供的文档/复现结果才能区分上述类别。不得以本类代替审慎判断；理由中写明缺失什么证据。

### CWE 条件判断（`cwe_judgment`）

- 仅当 `final_label=security_vulnerability` 时，判断冻结的 `claimed_cwe` 是否准确描述该安全缺陷：填 `correct`、`incorrect` 或证据不足时填 `uncertain`。若 `incorrect` 且能确定更合适 CWE，在 `corrected_cwe` 填 `CWE-数字`，否则留空并解释。
- 其余四类统一填 `not_applicable`，`corrected_cwe` 留空。CWE 准确率只在裁决为安全漏洞且 CWE 判断为 correct/incorrect 的记录上计算。
- 不要仅凭 CWE 名称与分析文本一致就判 correct；须核对驱动行为、日志原因和安全影响。

## 3. 去重对标签（`pair_label`，单选）

比较两份**原始分析记录**及其候选证据，而不是比较文字相似度：

- **`same`**：两者指向同一被测对象上的同一根因/同一缺陷实例。即使表述、CWE 或 0-day/1-day 类型不同，只要根因相同也可判 same。
- **`different`**：根因、受影响 API/组件、触发条件或安全后果存在实质差别，应保留为不同发现。仅文字不同不足以判 different。
- **`uncertain`**：证据不足以确定 same/different，理由中说明需要的信息。

评审文件不显示组内/跨组属性或系统预测。协调员 `dedup_pairs.csv` 才保存 `pair_scope` 和 `system_same`，供完成后评分。指标采用 raw-analysis pair 口径：`system_same=1` 当且仅当两条原始分析属于数据库合并的同一 `(pid,type)` 组。

## 4. 裁决

- 两位标注者完成全部候选和全部去重对后，协调员才可打开双方结果进行裁决。
- `adjudication.csv` 和 `dedup_adjudication.csv` 必须逐行完成；裁决者须是真实人员、填写理由并作人工确认。裁决标签使用相同词表。
- 裁决不是简单多数投票；须回到证据解决分歧。候选裁决 CWE 规则与第 2 节相同。
- `uncertain`/`inconclusive` 不应被暗中当作正确或错误；评分脚本按 README 的明示口径处理。

## 5. 完成检查与评分

在 `hmfuzzer/` 下运行：

```bash
python -X utf8 revision_stats/task19_score_annotations.py
```

只有两位标注者和裁决的候选 75 行、去重对全部行均通过完整性、词表、身份与一致性检查时，脚本才生成指标。未完成时会以非零状态退出，不生成任何“100%”结果。
