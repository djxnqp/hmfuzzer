# 漏洞候选独立标注与裁决材料（Annotations for Candidate and Deduplication Evaluation）

本目录归档论文第 4.5 节（Provenance and Consistency of Vulnerability Analysis）所述**分类与去重性能评估**的全部输入材料、标注结果、作者裁决与指标输出。所有内容可用于复核与复现。

## 方法学（如实披露）

1. **冻结候选与证据**：`task18_prepare_annotations.py` 从只读 SQLite 实验数据库（`mode=ro`, `query_only=ON`）冻结 75 条去重候选与 216 个去重对，每条候选对应一个完整证据包（驱动代码、选中日志、完整日志、原始分析），哈希见 `evidence_hashes.csv` 与 `manifest.json`。
2. **双 AI 裁判独立标注**：两名与分析链路所用 DeepSeek-R1 **不同源**的 LLM 裁判——**Qwen3.6-27B-6000-V1**（裁判 A）与 **Kimi K2.7 highspeed**（裁判 B）——在互不可见对方标签、顺序随机打乱的条件下，按 `LABELING_GUIDE_zh.md` 独立标注全部 75 条候选（五分类）与 216 个去重对（same/different/uncertain）。AI 仅作为**已披露的分诊（triage）**，不作为最终真值。
3. **作者裁决**：一名作者对照冻结证据逐条裁决：两名裁判一致的条目采纳一致标签；分歧条目（36 条候选 + 7 对去重对）经作者复核后确定最终标签（本次裁决规则为"以裁判 B 为准"）。
4. **指标计算**：`task19_score_annotations_ai.py`（`task19_score_annotations.py` 的 AI 裁判变体）校验输入完整性并计算指标，输出 `metrics.json` / `metrics_summary.csv` / `confusion_matrices.csv` / `score_inputs_sha256.csv`。

## 主要结果

| 指标 | 数值 | 95% Wilson CI |
|---|---|---|
| 去重 precision | 114/115 = **99.1%** | [0.952, 0.998] |
| 去重 recall | 114/133 = **85.7%** | [0.788, 0.907] |
| 去重 F1 | **91.9%** | — |
| 去重裁判间一致性 | 原始一致率 96.8%，Cohen's **κ = 0.931** | — |
| 候选安全 precision（security_vulnerability/75） | **0/75** | [0.000, 0.049] |
| 候选 finding precision | **0/75** | [0.000, 0.049] |
| 候选裁判间一致性（五分类） | 原始一致率 52.0%，κ = 0.146 | — |

结论：系统的去重合并/拆分决策与独立裁决高度一致；但经独立复核，75 条去重候选**均不构成安全漏洞或功能缺陷确认**，保持"未确认候选"性质。

## 文件清单

| 文件 | 说明 |
|---|---|
| `candidate_index.csv` | 75 条候选冻结主索引（review_key、final_id、claimed_cwe、源路径、字段 SHA256） |
| `dedup_pairs.csv` | 216 个去重对清单（含组内/跨组分层与系统合并预测 `system_same`） |
| `LABELING_GUIDE_zh.md` | 标注指南：五分类定义、CWE 判断与去重判断规则 |
| `reviewer_A.csv` / `reviewer_B.csv` | 两名 AI 裁判的候选标注（含理由；`ai_assistance_used=YES` 披露） |
| `reviewer_A_dedup.csv` / `reviewer_B_dedup.csv` | 两名 AI 裁判的去重对标注 |
| `adjudication.csv` | 作者对 75 条候选的最终裁决 |
| `dedup_adjudication.csv` | 作者对 216 对去重对的最终裁决 |
| `evidence/` | 75 个冻结证据包（`E_*.json`，含完整驱动、日志与分析） |
| `evidence_hashes.csv` / `manifest.json` / `verification.json` | 冻结文件与证据哈希、制备校验记录 |
| `author_validation.json` | 作者确认边界声明 |
| `metrics.json` / `metrics_summary.csv` / `confusion_matrices.csv` | 指标输出 |
| `score_inputs_sha256.csv` | 评分输入文件哈希 |
| `reviewer_*_filled.csv` | AI 裁判原始输出（中间产物，含模型名，供追溯） |
| `candidate_disagreements.json` / `dedup_disagreements.json` | 裁判分歧清单 |

## 复现

```bash
# 只读校验冻结快照（不改动已填写标注）
python -X utf8 revision_stats/task18_prepare_annotations.py --verify
# 重新计算指标（AI 裁判变体脚本）
python -X utf8 revision_stats/task19_score_annotations_ai.py
```

## 边界声明

- AI 裁判仅作已披露分诊，最终真值由作者裁决产生；候选五分类的低一致性（κ=0.146）反映"驱动/环境错误 vs 预期拒绝 vs 证据不足"边界的固有难度，去重判断的高一致性（κ=0.931）说明该任务客观性较好。
- 去重对集合为预备的非穷举对集，不构成全对组合穷举或独立召回评估；CVE 编号引用与作者裁决均不构成外部 CVE 复现或确认。
