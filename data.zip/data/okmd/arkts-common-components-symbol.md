# Symbol Glyph (SymbolGlyph/SymbolSpan)

**SymbolGlyph** is a component designed for icon glyphs, making it easy to use sophisticated icons, including multi-colored and animated icons. You can add symbol glyphs in text through the use of the **SymbolSpan** component, a child of the **Text** component. For details, see [SymbolGlyph](../reference/apis-arkui/arkui-ts/ts-basic-components-symbolGlyph.md) and [SymbolSpan](../reference/apis-arkui/arkui-ts/ts-basic-components-symbolSpan.md).


## Creating a Symbol Glyph

You create a symbol glyph by referencing a resource through $r. Currently, only the preset symbol resources are supported.

  ```ts
  SymbolGlyph($r('sys.symbol.ohos_folder_badge_plus'))
      .fontSize(96)
      .renderingStrategy(SymbolRenderingStrategy.SINGLE)
      .fontColor([Color.Black, Color.Green, Color.White])
  ```
  ![symbol_folder_badge_plus](figures/symbol_ohos_folder_badge_plus.png)


## Adding to Text

To embed a symbol glyph within a text string, use [SymbolSpan](../reference/apis-arkui/arkui-ts/ts-basic-components-symbolSpan.md) as a child of the [Text](../reference/apis-arkui/arkui-ts/ts-basic-components-text.md) component. You can nest multiple **SymbolSpan** components to display a series of symbol glyphs. 

- Create a **SymbolSpan** component.

  The **SymbolSpan** component works only when included in a **Text** component. It does not display any content when used alone.


  ```ts
  Text() {
    SymbolSpan($r('sys.symbol.ohos_trash'))
      .fontWeight(FontWeight.Normal)
      .fontSize(96)
  }
  ```
  ![symbol_trash](figures/symbolspan_trash.png)


- Set the size of the **SymbolSpan** component through [fontSize](../reference/apis-arkui/arkui-ts/ts-basic-components-symbolSpan.md#fontsize).


  ```ts
  Row() {
    Column() {
      Text("48")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_folder_badge_plus'))
          .fontSize(48)
          .renderingStrategy(SymbolRenderingStrategy.SINGLE)
          .fontColor([Color.Black, Color.Green, Color.White])
      }
    }

    Column() {
      Text("72")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_folder_badge_plus'))
          .fontSize(72)
          .renderingStrategy(SymbolRenderingStrategy.SINGLE)
          .fontColor([Color.Black, Color.Green, Color.White])
      }
    }

    Column() {
      Text("96")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_folder_badge_plus'))
          .fontSize(96)
          .renderingStrategy(SymbolRenderingStrategy.SINGLE)
          .fontColor([Color.Black, Color.Green, Color.White])
      }
    }
  }
  ```
  ![symbolSpan_multi_fontSize](figures/symbolspan_multi_fontsize.png)

- Set the weight of the **SymbolSpan** component through [fontWeight](../reference/apis-arkui/arkui-ts/ts-basic-components-symbolSpan.md#fontweight).

  ```ts
  Row() {
    Column() {
      Text("Light")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_trash'))
        .fontWeight(FontWeight.Lighter)
        .fontSize(96)
      }
    }

    Column() {
      Text("Normal")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_trash'))
          .fontWeight(FontWeight.Normal)
          .fontSize(96)
      }
    }

    Column() {
      Text("Bold")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_trash'))
          .fontWeight(FontWeight.Bold)
          .fontSize(96)
      }
    }
  }
  ```
  ![symbolSpan_multi_fontWeight_trash](figures/symbol_multi_fontweight_trash.png)

- Set the color of the **SymbolSpan** component through [fontColor](../reference/apis-arkui/arkui-ts/ts-basic-components-symbolSpan.md#fontcolor).

  ```ts
  Row() {
    Column() {
      Text("Black")
      Text() {
          SymbolSpan($r('sys.symbol.ohos_folder_badge_plus'))
            .fontSize(96)
            .fontColor([Color.Black])
      }
    }

    Column() {
      Text("Green")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_folder_badge_plus'))
          .fontSize(96)
          .fontColor([Color.Green])
      }
    }

    Column() {
      Text("Pink")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_folder_badge_plus'))
          .fontSize(96)
          .fontColor([Color.Pink])
      }
    }
  }
  ```
  ![symbolSpan_multi_fontColor](figures/symbolspan_multi_fontcolor.PNG)

- Set the rendering strategy of the **SymbolSpan** component through [renderingStrategy](../reference/apis-arkui/arkui-ts/ts-basic-components-symbolSpan.md#renderingstrategy).

  ```ts
  Row() {
    Column() {
      Text("Single-color mode")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_folder_badge_plus'))
          .fontSize(96)
          .renderingStrategy(SymbolRenderingStrategy.SINGLE)
          .fontColor([Color.Black, Color.Green, Color.White])
      }
    }

    Column() {
      Text("Multi-color mode")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_folder_badge_plus'))
          .fontSize(96)
          .renderingStrategy(SymbolRenderingStrategy.MULTIPLE_COLOR)
          .fontColor([Color.Black, Color.Green, Color.White])
      }
    }

    Column() {
      Text("Layered mode")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_folder_badge_plus'))
          .fontSize(96)
          .renderingStrategy(SymbolRenderingStrategy.MULTIPLE_OPACITY)
          .fontColor([Color.Black, Color.Green, Color.White])
      }
    }
  }
  ```
  ![symbolSpan_multi_renderingStrategy](figures/symbolspan_multi_renderingStrategy.png)

- Set the effect strategy of the **SymbolSpan** component through [effectStrategy](../reference/apis-arkui/arkui-ts/ts-basic-components-symbolSpan.md#effectstrategy).

  ```ts
  Row() {
    Column() {
      Text("No effect")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_wifi'))
          .fontSize(96)
          .effectStrategy(SymbolEffectStrategy.NONE)
      }
    }

    Column() {
      Text("Overall scale effect")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_wifi'))
          .fontSize(96)
          .effectStrategy(SymbolEffectStrategy.SCALE)
      }
    }

    Column() {
      Text("Hierarchical effect")
      Text() {
        SymbolSpan($r('sys.symbol.ohos_wifi'))
          .fontSize(96)
          .effectStrategy(SymbolEffectStrategy.HIERARCHICAL)
      }
    }
  }
  ```
  ![symbolSpan_multi_effectStrategy](figures/symbolspan_multi_effectStrategy.gif)

- **SymbolSpan** does not support universal events.

## Customizing Symbol Glyph Animations

In addition to using the **effectStrategy** attribute, which triggers an animation once it is activated, you can control the animation playback and choose from a variety of effect strategies using the following two methods.

For details about how **effectStrategy** works with **symbolEffect**, see [SymbolGlyph.symbolEffect](../reference/apis-arkui/arkui-ts/ts-basic-components-symbolGlyph.md#symboleffect12-1).

- Use the **symbolEffect** attribute to set both the effect strategy and playback state of **SymbolGlyph**.

  ```ts
  @State isActive: boolean = true;
  Column() {
    Text("Variable Color Effect")
    SymbolGlyph($r('sys.symbol.ohos_wifi'))
      .fontSize(96)
      .symbolEffect(new HierarchicalSymbolEffect(EffectFillStyle.ITERATIVE), this.isActive)
    Button(this.isActive ? 'Off' : 'Play').onClick(() => {
      this.isActive = !this.isActive;
    })
  }
  ```
  ![symbolGlyph_symbolEffect_isActive](figures/symbolGlyph_symbolEffect_isActive.gif)

- Use the **symbolEffect** attribute to set both the effect strategy and the trigger for playback of **SymbolGlyph**.

  ```ts
  @State triggerValueReplace: number = 0;
  Column() {
    Text("Bounce Effect")
    SymbolGlyph($r('sys.symbol.ellipsis_message_1'))
      .fontSize(96)
      .fontColor([Color.Gray])
      .symbolEffect(new BounceSymbolEffect(EffectScope.WHOLE, EffectDirection.UP), this.triggerValueReplace)
    Button('Trigger').onClick(() => {
      this.triggerValueReplace = this.triggerValueReplace + 1;
    })
  }
  ```
  ![BounceSymbolEffect](figures/symbolGlyph_bounceSymbolEffect_trigger.gif)


## Adding Events

You can add universal events, such as [onClick](../reference/apis-arkui/arkui-ts/ts-universal-events-click.md#onclick) and [onTouch](../reference/apis-arkui/arkui-ts/ts-universal-events-touch.md#ontouch), to the **SymbolGlyph** component to handle user interactions.

```ts
@State wifiColor: ResourceColor = Color.Black;
SymbolGlyph($r('sys.symbol.ohos_wifi'))
.fontSize(96)
.fontColor([this.wifiColor])
.onClick(()=>{
  this.wifiColor = Color.Gray
})
```
![symbolGlyph_onClick](figures/symbolGlyph_onClick.gif)

## Example

This example shows how to implement a playlist with the use of **symbolEffect**, **fontSize**, and **fontColor**.

```ts
// xxx.ets
@Entry
@Component
struct Index {
  @State triggerValueReplace: number = 0;
  @State symbolSources: Resource[] = [$r('sys.symbol.repeat'), $r('sys.symbol.repeat_1'), $r('sys.symbol.arrow_left_arrow_right')]
  @State symbolSourcesIndex: number = 0;
  @State symbolText: string[] = ['Play in order','Loop song','Shuffle']
  @State symbolTextIndex: number = 0;
  @State fontColorValue:ResourceColor = Color.Grey;
  @State fontColorValue1:ResourceColor = '#E8E8E8';

  build() {
    Column( { space: 10 }) {
      Row() {
        Text(){
          Span('Playlist')
            .fontSize(20)
            .fontWeight(FontWeight.Bolder)
          Span('(101)')
        }
      }
      Row() {
        Row({ space: 5 }) {
          SymbolGlyph(this.symbolSources[this.symbolSourcesIndex])
            .symbolEffect(new ReplaceSymbolEffect(EffectScope.WHOLE), this.triggerValueReplace)
            .fontSize(20)
            .fontColor([this.fontColorValue])
          Text(this.symbolText[this.symbolTextIndex])
            .fontColor(this.fontColorValue)
        }
        .onClick(()=>{
          this.symbolTextIndex++;
          this.symbolSourcesIndex++;
          this.triggerValueReplace++;
          if (this.symbolSourcesIndex > (this.symbolSources.length - 1)) {
            this.symbolSourcesIndex = 0;
            this.triggerValueReplace = 0;
          }
          if (this.symbolTextIndex > (this.symbolText.length - 1)) {
            this.symbolTextIndex = 0;
          }
        })
        .width('75%')

        Row({ space: 5 }) {
          Text(){
            SymbolSpan($r('sys.symbol.arrow_down_circle_badge_vip_circle_filled'))
              .fontColor([this.fontColorValue])
              .fontSize(20)
          }
          Text(){
            SymbolSpan($r('sys.symbol.heart_badge_plus'))
              .fontColor([this.fontColorValue])
              .fontSize(20)
          }
          Text(){
            SymbolSpan($r('sys.symbol.ohos_trash'))
              .fontColor([this.fontColorValue])
              .fontSize(20)
          }
        }
        .width('25%')
      }
      Divider().width(5).color(this.fontColorValue1).width('98%')
      Row(){
        Row(){
          Text("Song 1")
        }.width('82%')
        Row({ space: 5}) {
          SymbolGlyph($r('sys.symbol.play_arrow_triangle_2_circlepath'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
          SymbolGlyph($r('sys.symbol.trash'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
        }
      }
      Divider().width(5).color(this.fontColorValue1).width('98%')
      Row(){
        Row(){
          Text("Song 2")
        }.width('82%')
        Row({ space: 5}) {
          SymbolGlyph($r('sys.symbol.play_arrow_triangle_2_circlepath'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
          SymbolGlyph($r('sys.symbol.trash'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
        }
      }
      Divider().width(5).color(this.fontColorValue1).width('98%')
      Row(){
        Row(){
          Text("Song 3")
        }.width('82%')
        Row({ space: 5}) {
          SymbolGlyph($r('sys.symbol.play_arrow_triangle_2_circlepath'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
          SymbolGlyph($r('sys.symbol.trash'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
        }
      }
      Divider().width(5).color(this.fontColorValue1).width('98%')
      Row(){
        Row(){
          Text("Song 4")
        }.width('82%')
        Row({ space: 5}) {
          SymbolGlyph($r('sys.symbol.play_arrow_triangle_2_circlepath'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
          SymbolGlyph($r('sys.symbol.trash'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
        }
      }
      Divider().width(5).color(this.fontColorValue1).width('98%')
      Row(){
        Row(){
          Text("Song 5")
        }.width('82%')
        Row({ space: 5}) {
          SymbolGlyph($r('sys.symbol.play_arrow_triangle_2_circlepath'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
          SymbolGlyph($r('sys.symbol.trash'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
        }
      }
      Divider().width(5).color(this.fontColorValue1).width('98%')
      Row(){
        Row(){
          Text("Song 6")
        }.width('82%')
        Row({ space: 5}) {
          SymbolGlyph($r('sys.symbol.play_arrow_triangle_2_circlepath'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
          SymbolGlyph($r('sys.symbol.trash'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
        }
      }
      Divider().width(5).color(this.fontColorValue1).width('98%')
      Row(){
        Row(){
          Text("Song 7")
        }.width('82%')
        Row({ space: 5}) {
          SymbolGlyph($r('sys.symbol.play_arrow_triangle_2_circlepath'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
          SymbolGlyph($r('sys.symbol.trash'))
            .fontColor([this.fontColorValue])
            .fontSize(20)
        }
      }
      Divider().width(5).color(this.fontColorValue1).width('98%')
      Column(){
        Text("Close")
      }
      .alignItems(HorizontalAlign.Center)
      .width('98%')
    }
    .alignItems(HorizontalAlign.Start)
    .width('100%')
    .height(400)
    .padding({
      left:10,
      top:10
    })
  }
}
```
![symbol_scene_demo](figures/symbol_music_demo.gif)
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: symbol_ohos_folder_badge_plus.png
###Image description: The image depicts a simple icon that represents the addition or creation of a new folder. The icon consists of a folder symbol, which is a common graphical representation for a file or directory in computer file systems. The folder is depicted in a standard, rectangular shape with rounded corners. 

To the right of the folder, there is a plus sign (+). The plus sign is a universal symbol used to indicate the addition of something, in this case, the creation of a new folder. This icon is typically used in user interfaces, such as file managers or desktop environments, to allow users to easily create new folders.

### Analysis and Description:

1. **Folder Icon**:
   - **Shape**: Rectangular with rounded corners.
   - **Color**: The folder is usually depicted in a neutral color, such as gray or black, to ensure it stands out against the background.

2. **Plus Sign (+)**:
   - **Position**: Located to the right of the folder.
   - **Color**: The plus sign is typically colored in a contrasting color to the folder, such as white or light gray, to make it easily noticeable.

3. **Purpose**:
   - **Function**: The icon is used to represent the action of creating a new folder. This is a common feature in many operating systems and file management applications.

4. **Context**:
   - **Usage**: This icon is commonly found in graphical user interfaces (GUIs) for file management. It is used to allow users to create new folders within a directory structure, which is essential for organizing files and directories.

### Relevant Knowledge:

In computer file systems, folders are used to organize files into a hierarchical structure. This structure helps users manage their files more efficiently by grouping similar files together. The plus sign next to the folder icon is a direct reference to the action of adding a new folder, which is a fundamental operation in file management.

### Conclusion:

The image is a clear and concise representation of the action of creating a new folder. The use of a standard folder icon combined with a plus sign effectively communicates the intended function to users. This icon is a common feature in various operating systems and file management applications, facilitating the creation of new folders for organizing files.
##Image Name: symbolspan_trash.png
###Image description: The image depicts a simple, black-and-white icon of a trash can. The trash can is illustrated with a lid that is open, revealing the interior. The design is minimalistic, with clean lines and no additional details or textures. This type of icon is commonly used to represent waste disposal or recycling in various contexts, such as on computer interfaces, in manuals, or on signs.
##Image Name: symbolspan_multi_fontsize.png
###Image description: The image depicts three icons, each representing a folder with an additional symbol indicating the option to add more content. The icons are arranged horizontally and are labeled with numbers: 48, 72, and 96. Each icon has a different size, with the number indicating the capacity or size of the folder.

1. **First Icon (48)**:
   - This icon is the smallest among the three.
   - It shows a folder with a plus sign (+) on the right side, indicating the option to add more content.
   - The number "48" is placed above the folder, suggesting that this folder has a capacity of 48 units.

2. **Second Icon (72)**:
   - This icon is larger than the first one.
   - Similar to the first icon, it also features a folder with a plus sign (+) on the right side.
   - The number "72" is placed above the folder, indicating that this folder has a capacity of 72 units.

3. **Third Icon (96)**:
   - This icon is the largest among the three.
   - It also shows a folder with a plus sign (+) on the right side.
   - The number "96" is placed above the folder, indicating that this folder has a capacity of 96 units.

### Analysis and Description

The image is likely illustrating a concept of increasing capacity or size of folders, possibly in a digital or software context. The numbers above each folder represent the maximum capacity or size that each folder can hold. The plus sign (+) next to each folder indicates that users can add more content to these folders.

### Chain of Thought (CoT) Analysis

1. **Identify the Objects**:
   - Three icons representing folders.
   - Each folder has a plus sign indicating the option to add more content.
   - Numbers above each folder indicating the capacity or size.

2. **Determine the Sequence**:
   - The icons are arranged in ascending order of size, from smallest to largest.
   - The numbers correspond to the capacity of each folder, increasing from 48 to 72 to 96.

3. **Interpret the Context**:
   - The image likely represents a digital interface where users can manage files and folders.
   - The plus sign suggests expandable or expandable storage options.

4. **Conclusion**:
   - The image effectively communicates the concept of increasing folder capacity or size, with each icon representing a different level of storage capacity.

### Conclusion

The image is a clear and concise representation of increasing folder capacities, with each icon showing a folder and a plus sign indicating the option to add more content. The numbers above each folder provide a quantitative measure of the capacity, helping users understand the available storage options.
##Image Name: symbol_multi_fontweight_trash.png
###Image description: The image shows three different representations of a trash can, labeled "Light," "Normal," and "Bold." Each trash can is depicted in a different style, indicating variations in the thickness and weight of the lines used to draw them.

1. **Light**: The trash can on the left is drawn with thin lines. The outline is delicate and the details are minimal. This style gives the trash can a more delicate and less prominent appearance.

2. **Normal**: The trash can in the middle is drawn with medium-weight lines. The outline is clear and the details are well-defined, making it a balanced and standard representation.

3. **Bold**: The trash can on the right is drawn with thick lines. The outline is robust and the details are pronounced. This style gives the trash can a more prominent and assertive appearance.

These variations in line weight and thickness are often used in graphic design to convey different levels of emphasis or to fit different design contexts. The "Light" style is typically used for delicate or subtle designs, the "Normal" style for standard or balanced designs, and the "Bold" style for attention-grabbing or assertive designs.
##Image Name: symbolspan_multi_fontcolor.PNG
###Image description: The image consists of three folder icons, each with a different color and a plus sign (+) on them. The folders are arranged horizontally from left to right. Here is a detailed description of each folder:

1. **Black Folder**:
   - **Color**: Black
   - **Shape**: The folder is rectangular with rounded corners.
   - **Plus Sign**: There is a plus sign (+) located on the right side of the folder, indicating that it can be added to or contains additional items.

2. **Green Folder**:
   - **Color**: Green
   - **Shape**: Similar to the black folder, it is rectangular with rounded corners.
   - **Plus Sign**: The plus sign (+) is also present on the right side of the folder.

3. **Pink Folder**:
   - **Color**: Pink
   - **Shape**: The folder is rectangular with rounded corners, similar to the other two folders.
   - **Plus Sign**: The plus sign (+) is located on the right side of the folder.

The plus sign (+) on each folder typically represents the ability to add or include more items within the folder. This is a common design element in user interfaces to indicate expandability or additional content.
##Image Name: symbolspan_multi_renderingStrategy.png
###Image description: The image consists of three icons, each representing a different mode of operation for a file management system. The icons are labeled as "Single-color mode," "Multi-color mode," and "Layered mode."

1. **Single-color mode icon**:
   - This icon depicts a folder with a single color, likely green, indicating that it is in single-color mode.
   - The folder has a green plus sign (+) on it, suggesting that it can be added to or modified in some way.

2. **Multi-color mode icon**:
   - This icon shows a folder with multiple colors, indicating that it is in multi-color mode.
   - The folder has a green plus sign (+) on it, similar to the single-color mode icon, suggesting that it can also be added to or modified.

3. **Layered mode icon**:
   - This icon represents a folder with a layered appearance, indicating that it is in layered mode.
   - The folder has a green plus sign (+) on it, consistent with the other icons, suggesting that it can be added to or modified.

The icons are designed to visually represent the different modes of operation for managing files, with the green plus sign indicating the ability to add or modify the files within each mode.
