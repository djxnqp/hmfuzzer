# Progress Indicator (Progress)


The **Progress** component is used to provide an indicator that shows the progress of an operation. For details, see [Progress](../reference/apis-arkui/arkui-ts/ts-basic-components-progress.md).


## Creating a Progress Indicator

You can create a progress indicator by calling the following API:

```ts
Progress(options: {value: number, total?: number, type?: ProgressType})
```


In this API, **value** indicates the initial progress, **total** indicates the total progress, and **type** indicates the style of the progress indicator.

```ts
Progress({ value: 24, total: 100, type: ProgressType.Linear }) // Create a linear progress indicator whose total progress is 100 and initial progress is 24.
```


![create](figures/create.png)


## Setting the Progress Indicator Style

Progress indicators come in five styles. When creating a progress indicator, you can specify its style by setting the **ProgressType** parameter to any of the following: **ProgressType.Linear** (linear style), **ProgressType.Ring** (indeterminate ring style), **ProgressType.ScaleRing** (determinate ring style), **ProgressType.Eclipse** (eclipse style), and **ProgressType.Capsule** (capsule style).


- Linear style (default style)

  >**NOTE**
  >
  > Since API version 9, the progress indicator adaptively switches to the vertical layout if its height is greater than the width and remains the horizontal layout if the height is equal to the width.


  ```ts
  Progress({ value: 20, total: 100, type: ProgressType.Linear }).width(200).height(50)
  Progress({ value: 20, total: 100, type: ProgressType.Linear }).width(50).height(200)
  ```

  ![en-us_image_0000001562700417](figures/en-us_image_0000001562700417.png)

- Indeterminate ring style

  ```ts
  // The progress indicator in the indeterminate ring style on the left: Retain its default settings for the foreground color (blue gradient) and stroke width (2.0 vp).
  Progress({ value: 40, total: 150, type: ProgressType.Ring }).width(100).height(100)
  // The right progress indicator in the indeterminate ring style on the right.
  Progress({ value: 40, total: 150, type: ProgressType.Ring }).width(100).height(100)
      .color(Color.Grey)	// Set the foreground color to gray.
      .style({ strokeWidth: 15})	// Set the stroke width to 15.0 vp.
  ```

  ![progress_ring](figures/progress_ring.png)

- Determinate ring style

  ```ts
  Progress({ value: 20, total: 150, type: ProgressType.ScaleRing }).width(100).height(100)
      .backgroundColor(Color.Black)
      .style({ scaleCount: 20, scaleWidth: 5 })	// Set the total number of scales to 20 and the scale width to 5 vp.
  Progress({ value: 20, total: 150, type: ProgressType.ScaleRing }).width(100).height(100)
      .backgroundColor(Color.Black)
      .style({ strokeWidth: 15, scaleCount: 20, scaleWidth: 5 })	// Set the stroke width to 15, the total number of scales to 20, and the scale width to 5 vp.
  Progress({ value: 20, total: 150, type: ProgressType.ScaleRing }).width(100).height(100)
      .backgroundColor(Color.Black)
      .style({ strokeWidth: 15, scaleCount: 20, scaleWidth: 3 })	// Set the stroke width to 15, the total number of scales to 20, and the scale width to 3 vp.
  ```

  ![progress_scalering](figures/progress_scalering.png)

- Eclipse style

  ```ts
  // The progress indicator in the eclipse style on the left: Retain its default settings for the foreground color (blue).
  Progress({ value: 10, total: 150, type: ProgressType.Eclipse }).width(100).height(100)
  // The progress indicator in the eclipse style on the right: Set its foreground color to gray.
  Progress({ value: 20, total: 150, type: ProgressType.Eclipse }).color(Color.Grey).width(100).height(100)
  ```

  ![progress_circle](figures/progress_circle.png)

- Capsule style
  >**NOTE**
  >
  >-  At both ends, the progress indicator in the capsule style works in a same manner as that in the eclipse style.
  >-  In the middle part of the capsule, the progress indicator works in a same manner as the linear style.
  >
  >-  If the height is greater than the width, the progress indicator adaptively switches to the vertical layout.


  ```ts
  Progress({ value: 10, total: 150, type: ProgressType.Capsule }).width(100).height(50)
  Progress({ value: 20, total: 150, type: ProgressType.Capsule }).width(50).height(100).color(Color.Grey)
  Progress({ value: 50, total: 150, type: ProgressType.Capsule }).width(50).height(100).color(Color.Blue).backgroundColor(Color.Black)
  ```

  ![progress_captule](figures/progress_captule.png)


## Example Scenario

In this example, the progress of the **Progress** component is updated by clicking the button. After the button is clicked, the value of **progressValue** is incremented and passed by the **value** attribute to the **Progress** component, which is then updated accordingly.

```ts
@Entry
@Component
struct ProgressCase1 { 
  @State progressValue: number = 0	// Set the initial progress of the progress indicator to 0.
  build() {
    Column() {
      Column() {
        Progress({value:0, total:100, type:ProgressType.Capsule}).width(200).height(50).value(this.progressValue)
        Row().width('100%').height(5)
        Button("Progress + 5")
          .onClick(()=>{
            this.progressValue += 5
            if (this.progressValue > 100){
              this.progressValue = 0
            }
          })
      }
    }.width('100%').height('100%')
  }
}
```


![progress](figures/progress.gif)
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: create.png
###Image description: The image depicts a simple, minimalist design featuring a horizontal blue bar on a white background. The blue bar is positioned horizontally across the center of the image, occupying approximately one-third of the width. The bar is solid blue with no gradients or patterns, and it appears to be a progress bar or loading indicator, commonly used to show the progress of a process or task. The white background provides a stark contrast, making the blue bar stand out prominently.
##Image Name: en-us_image_0000001562700417.png
###Image description: The image depicts a simple geometric figure consisting of two lines. One line is horizontal and extends from the left side of the image to the right, occupying about two-thirds of the width. The other line is vertical and extends from the top to the bottom of the image, occupying about one-third of the height. Both lines are white, and there is a blue dot at the end of each line, indicating the endpoints. The background is plain white, which makes the lines and dots stand out clearly.
##Image Name: progress_ring.png
###Image description: The image consists of two circular progress indicators, each with a different color and style. 

1. **Left Circular Progress Indicator:**
   - **Shape:** The indicator is a perfect circle.
   - **Color:** The circle is primarily white with a blue arc.
   - **Arc:** The arc is a blue line that starts from the top left and extends towards the bottom right of the circle. The arc is incomplete, indicating that the process is not yet finished.
   - **Background:** The background of the circle is white, which makes the blue arc stand out clearly.

2. **Right Circular Progress Indicator:**
   - **Shape:** The indicator is also a perfect circle.
   - **Color:** The circle is primarily white with a gray arc.
   - **Arc:** The arc is a gray line that starts from the top right and extends towards the bottom left of the circle. The arc is also incomplete, indicating that the process is not yet finished.
   - **Background:** The background of the circle is white, which makes the gray arc stand out clearly.

Both indicators are designed to show the progress of a process, with the arc representing the portion of the process that has been completed. The incomplete arcs suggest that the process is ongoing and not yet complete. The use of contrasting colors (blue and gray) helps to distinguish between the two indicators visually.
##Image Name: progress_scalering.png
###Image description: The image consists of three circular patterns, each containing a series of horizontal lines. The patterns are arranged side by side, from left to right.

1. **Left Circle:**
   - This circle is the smallest among the three.
   - It contains a series of evenly spaced horizontal lines.
   - The lines are thin and black.
   - There are no blue lines or any other variations in color.

2. **Middle Circle:**
   - This circle is larger than the left one but smaller than the right one.
   - It also contains a series of evenly spaced horizontal lines.
   - The lines are thin and black.
   - There is a single blue line that is longer than the others, positioned towards the top right of the circle.

3. **Right Circle:**
   - This circle is the largest among the three.
   - It contains a series of evenly spaced horizontal lines.
   - The lines are thin and black.
   - There is a single blue line that is longer than the others, positioned towards the top right of the circle.

**Analysis and Description:**

The image appears to be a simple graphical representation, possibly used to illustrate a concept or pattern. The presence of blue lines among the black lines suggests a distinction or emphasis on those particular lines. The consistent spacing and uniformity of the lines indicate a structured and organized pattern.

**Possible Interpretations:**

1. **Educational Context:**
   - The image could be used in an educational setting to teach about patterns, symmetry, or basic geometry. The blue lines might represent a special case or an anomaly within the pattern.

2. **Design Element:**
   - In design, such patterns can be used as decorative elements or as part of a logo or icon. The blue lines could signify a particular brand or theme.

3. **Mathematical Concept:**
   - The image might be used to illustrate a mathematical concept, such as the distribution of elements in a set or the identification of outliers in a sequence.

**Conclusion:**

The image is a simple yet effective representation of a pattern with a distinguishing feature. The consistent use of black lines with a single blue line in each circle suggests a deliberate design choice to highlight certain elements. This could be used in various contexts, from educational to design, and mathematical applications.
##Image Name: progress_circle.png
###Image description: The image consists of two circular objects, each with a different shading pattern. Both circles are white in color and have a smooth, rounded appearance.

1. **Left Circle:**
   - The left circle is shaded with a blue color on the left side, transitioning to white on the right side.
   - The blue shading is concentrated on the left half of the circle, creating a gradient effect where the blue color is more intense on the left and fades into white on the right.
   - The circle is uniformly filled with the blue color on the left side, and the right side remains white.

2. **Right Circle:**
   - The right circle is shaded with a gray color on the left side, transitioning to white on the right side.
   - The gray shading is concentrated on the left half of the circle, creating a gradient effect where the gray color is more intense on the left and fades into white on the right.
   - The circle is uniformly filled with the gray color on the left side, and the right side remains white.

Both circles are identical in shape and size, with the left circle having a blue gradient and the right circle having a gray gradient. The shading patterns create a visual effect of light and shadow, giving the circles a three-dimensional appearance.
##Image Name: progress_captule.png
###Image description: The image consists of three distinct objects, each representing a different stage or state of a switch or toggle mechanism. These objects are arranged horizontally from left to right.

1. **Left Object (Initial State):**
   - This object is an elongated, oval shape with a smooth, curved surface.
   - It has a light blue gradient fill, transitioning from a lighter shade at the top to a slightly darker shade at the bottom.
   - The object appears to be in a neutral or off state, as there are no visible markings or indicators of activation.

2. **Middle Object (Intermediate State):**
   - This object is similar in shape to the first but includes a notable feature: a curved, semi-circular cutout or indentation.
   - The cutout is located at the top of the object and is filled with a gray color.
   - This cutout suggests that the object is transitioning from an initial state to an active state, possibly indicating that the switch is being turned on or activated.

3. **Right Object (Final State):**
   - This object is also oval-shaped but has a more pronounced and distinct feature compared to the previous two.
   - The top half of the object is filled with a blue color, while the bottom half is filled with a black color.
   - The division between the blue and black halves is sharp and clear, indicating a complete transition from the initial state.
   - This object represents the final state of the switch, where it is fully activated or turned on.

### Analysis and Description:
The objects in the image likely represent a visual progression of a switch or toggle mechanism, transitioning from an initial state to an active state. The left object is in its initial state, the middle object is in the process of transitioning, and the right object is in its final active state. The use of color gradients and distinct shapes helps to clearly illustrate the state changes, making it easy to understand the progression from off to on.

### Chain of Thought (CoT) Analysis:
1. **Initial State (Left Object):**
   - The light blue gradient suggests a neutral or off state.
   - The smooth, curved surface indicates a passive or inactive state.

2. **Intermediate State (Middle Object):**
   - The gray cutout indicates a transition phase.
   - The curved shape suggests a gradual change from the initial state.

3. **Final State (Right Object):**
   - The sharp division between blue and black colors indicates a complete transition.
   - The distinct shapes confirm the switch is fully activated.

### Conclusion:
The image effectively uses visual cues to depict the state transition of a switch or toggle mechanism, from initial to final states. The use of color gradients and distinct shapes helps to clearly illustrate the progression, making it easy to understand the state changes.
