# Ability Assistant


Ability Assistant (AA) is a tool used to start applications and test cases. It provides basic application debugging and testing capabilities, for example, starting application components, forcibly stopping processes, and printing application component information.

> **NOTE**
>
> Before using this tool, you must obtain the <!--Del-->[<!--DelEnd-->hdc tool<!--Del-->](../../device-dev/subsystems/subsys-toolchain-hdc-guide.md)<!--DelEnd--> and run the hdc shell command.


## help
  Displays help information for the Ability Assistant.

  **Return value**

  Returns the help information.

  **Method**


  ```bash
  aa help
  ```


## start
  Starts an application component. The target component can be the PageAbility and ServiceAbility components of the FA model or the UIAbility and ServiceExtensionAbility components of the Stage model. The **exported** tag in the configuration file of the target component cannot be set to **false**.

| Name| Description             |
| -------- |-------------------|
| -h/--help | Help information.            |
| -d | Device ID. This parameter is optional.   |
| -a | Ability name. This parameter is optional.|
| -b | Bundle name. This parameter is optional. |
| -m | Module name. This parameter is optional. |
| -U | URI. This parameter is optional.        |
| -A | Action. This parameter is optional.     |
| -e | Entity. This parameter is optional.     |
| -t | Type. This parameter is optional.       |
| -S | Whether to enter the application sandbox during debugging. This parameter is optional. If this parameter is carried, the application sandbox is entered. Otherwise, the application sandbox is not entered.|
| --pi  | Key-value pair of the integer type. This parameter is optional.    |
| --pb  | Key-value pair of the Boolean type. This parameter is optional.    |
| --ps  | Key-value pair of the string type. This parameter is optional.   |
| --psn | Keyword of an empty string. This parameter is optional.    |
| --wl | Left margin of the window, in px. This parameter is optional.<br>**Constraints**:<br>This field is valid only when the 2-in-1 device is in developer mode and the application to start uses a debug signature.|
| --wt | Top margin of the window, in px. This parameter is optional.<br>**Constraints**:<br>This field is valid only when the 2-in-1 device is in developer mode and the application to start uses a debug signature.|
| --wh | Window height, in px. This parameter is optional.<br>**Constraints**:<br>This field is valid only when the 2-in-1 device is in developer mode and the application to start uses a debug signature.|
| --ww | Window width, in px. This parameter is optional.<br>**Constraints**:<br>This field is valid only when the 2-in-1 device is in developer mode and the application to start uses a debug signature.|
| -D | Debugging mode. This parameter is optional.       |
| -p | Optimization mode. This parameter is optional. This command can be customized.       |

  **Return value**

  Returns "start ability successfully." if the ability is started; returns "error: failed to start ability." and the corresponding error information otherwise.

  **Method**


  ```bash
  # Display the ability started.
  aa start [-d <deviceId>] [-a <abilityName> -b <bundleName>] [-m <moduleName>] [-D] [-S] [--pi <key> <integer-value>] [--pb <key> <bool-value: true/false/t/f, case insensitive] [--ps <key> <value>] [--psn <key>] [--wl <windowLeft>] [--wt <windowTop>] [--wh <windowHeight>] [--ww <windowWidth>] [-p <perf-cmd>]
  
  # Implicitly start an ability. If none of the parameters in the command is set, the startup fails.
  aa start [-d <deviceId>] [-U <URI>] [-t <type>] [-A <action>] [-e <entity>] [-D] [--pi <key> <integer-value>] [--pb <key> <bool-value: true/false/t/f, case insensitive] [--ps <key> <value>] [--psn <key>] [--wl <windowLeft>] [--wt <windowTop>] [--wh <windowHeight>] [--ww <windowWidth>] [-p <perf-cmd>]
  ```

  **Example**

The following uses the implicit startup of an ability as an example.
  > **NOTE**
  > 
  > This example describes only the usage of some fields. For details about ability matching rules, see [Matching Rules of Explicit Want and Implicit Want](../application-models/explicit-implicit-want-mappings.md).


  - Configure **uris** for the target ability in the **module.json5** file.

      ```json
      {
        "name": "TargetAbility",
        ......
        "exported": true,
        "skills": [
          {
            "actions":[
              "ohos.want.action.viewData"
            ],
            "uris":[
              {
                "scheme": "myscheme",
                "host": "www.test.com",
                "port": "8080",
                "path": "path",
              }
            ]
          }
        ]
      }
      ```


  - Implicitly start the ability.

    - Run the **-U** command to start an application page.

        ```bash
        aa start -U myscheme://www.test.com:8080/path
        ```

    - If parameters need to be carried, run the following command:

        ```bash
        aa start -U myscheme://www.test.com:8080/path --pi paramNumber 1 --pb paramBoolean true --ps paramString teststring  --psn paramNullString
        ```

      The following is an example for the UIAbility to obtain input parameters:
    
        ```ts
        import UIAbility from '@ohos.app.ability.UIAbility';
        import hilog from '@ohos.hilog';
        import Want from '@ohos.app.ability.Want';

        export default class TargetAbility extends UIAbility {
          onCreate(want:Want, launchParam) {
            hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onCreate');
            let paramNumber = want.parameters.paramNumber
            let paramBoolean = want.parameters.paramBoolean
            let paramString = want.parameters.paramString
            let paramNullString = want.parameters.paramNullString
          }
        }
        ```

    - Run the **-A -U** command to start the browser and redirect to a specified page.

      The following uses **https://www.example.com** as an example. Replace it with the actual URL.

        ```bash
        aa start -A ohos.want.action.viewData -U https://www.example.com
        ```


## stop-service
  Stops a ServiceAbility.

| Name| Description|
| -------- | -------- |
| -h/--help | Help information.|
| -d | Device ID. This parameter is optional.|
| -a | Ability name. This parameter is mandatory.|
| -b | Bundle name. This parameter is mandatory.|
| -m | Module name. This parameter is optional.|

  **Return value**

  Returns "stop service ability successfully." if the ServiceAbility is stopped; returns "error: failed to stop service ability." otherwise.

  **Method**


  ```bash
  aa stop-service [-d <deviceId>] -a <abilityName> -b <bundleName> [-m <moduleName>]
  ```

## dump<sup>(deprecated)</sup>
  > **NOTE**
  >
  > This command is supported since API version 7 and deprecated since API version 9. You are advised to use **[hidumper](../dfx/hidumper.md) -s AbilityManagerService** instead.

  Prints information about an application component.
| Name| Level-2 Parameter| Description|
| -------- | -------- | -------- |
| -h/--help | - | Help information.|
| -a/--all | - | Application component information in all missions.|
| -l/--mission-list | type (All logs are printed if this parameter is left unspecified.)| For better management, the service side maintains four types of MissionLists, as described below:<br>- **NORMAL**: MissionList that is started normally. For example, if A starts B and C, the corresponding MissionList is A->B->C.<br>- **DEFAULT_STANDARD**: If a MissionList is damaged, missions with the launch type set to **multiton** are removed to this MissionList. The Missions in it are not associated with each other.<br>- **DEFAULT_SINGLE**: If a MissionList is damaged, missions with the launch type set to **singleton** are removed to this MissionList. The Missions in it are not associated with each other.<br>- **LAUNCHER**: MissionList for launcher abilities.|
| -e/--extension | elementName | Extended component information.|
| -u/--userId | UserId | Mission stack information of a specified user ID. This parameter must be used together with other parameters. Example commands: **aa dump -a -u 100** and **aa dump -d -u 100**.|
| -d/--data | - | DataAbility information.|
| -i/--ability | AbilityRecord ID | Detailed information about an application component.|
| -c/--client | - | Detailed information about an application component. This parameter must be used together with other parameters. Example commands: **aa dump -a -c** and **aa dump -i 21 -c**.|
| -p/--pending | - | Pending Want information. This parameter must be used together with other parameters. Example command: **aa dump -a -p**.|
| -r/--process | - | Process information. This parameter must be used together with other parameters. Example command: **aa dump -a -r**.|

  **Method**


  ```bash
  aa dump -a
  ```

  ![aa-dump-a](figures/aa-dump-a.png)


  ```bash
  aa dump -l
  ```

  ![aa-dump-l](figures/aa-dump-l.png)


  ```bash
  aa dump -i 12
  ```

  ![aa-dump-i](figures/aa-dump-i.png)

## force-stop
  Forcibly stops a process based on the bundle name.

  **Return value**

  Returns "force stop process successfully." if the process is forcibly stopped; returns "error: failed to force stop process." otherwise.

  **Method**


  ```bash
  aa force-stop <bundleName>
  ```

## test

  Starts the test framework based on the carried parameters.

  > **NOTE**
  > 
  > For details about parameters such as **class**, **level**, **size**, and **testType**, see <!--RP2-->[Keywords in the aa test Commands](../application-test/arkxtest-guidelines.md)<!--RP2End-->.

| Name| Description|
| -------- | -------- |
| -h/--help | Help information.|
| -b | Bundle name. This parameter is mandatory.|
| -s unittest | Test runner. This parameter is mandatory.|
| -p | Package name of the test runner. This parameter is optional.<br>**NOTE**: This parameter can be used only in the FA model.|
| -m | Module name of the test runner. This parameter is optional.<br>**NOTE**: This parameter can be used only in the stage model.|
| -s class | Test suite or test case to be executed. This parameter is optional.|
| -s level | Level of the test case to be executed. This parameter is optional.|
| -s size | Size of the test case to be executed. This parameter is optional.|
| -s testType | Type of the test case to be executed. This parameter is optional.|
| -s timeout | Timeout interval for executing the test case, in ms. The default value is 5000. This parameter is optional.|
| -s \<any-key> | Any key-value pair. This parameter is optional.|
| -w | Test running time, in ms. This parameter is optional.|
| -D | Debugging mode. This parameter is optional.|

  **Return value**

  Returns "user test started." if the test framework is started; returns "error: failed to start user test." and the corresponding error information otherwise.

  **Method**

  ```bash
  aa test -b <bundleName> [-m <module-name>] [-p <package-name>] [-s class <test-class>] [-s level <test-level>] [-s size <test-size>] [-s testType <test-testType>] [-s timeout <test-timeout>] [-s <any-key> <any-value>] [-w <wait-time>] -s unittest <testRunner>
  ```

## attach
  Attaches an application to enable it to enter the debugging mode.

| Name| Description             |
| -------- |-------------------|
| -h/--help | Help information.            |
| -b | Bundle name. This parameter is mandatory. |


  **Return value**

  Returns "attach app debug successfully." if the application enters the debugging mode; returns "fail: unknown option." and prints the help information if the specified parameter is invalid.

  **Method**


  ```bash
  aa attach -b <bundleName>
  ```

## detach
  Detaches an application to enable it to exit the debugging mode.

| Name| Description             |
| -------- |-------------------|
| -h/--help | Help information.            |
| -b | Bundle name. This parameter is mandatory. |


  **Return value**

  Returns "detach app debug successfully." if the application exits the debugging mode; returns "fail: unknown option." and prints the help information if the specified parameter is invalid.

  **Method**


  ```bash
  aa detach -b <bundleName>
  ```

## appdebug
  Sets or cancels the waiting-for-debugging state of an application, and obtains the bundle name and persistence flag of an application in the waiting-for-debugging state. The waiting-for-debugging state takes effect only for debugging applications. The setting command of **appdebug** takes effect only for a single application. Once the command is executed repeatedly, the bundle name and persistence flag are replaced with the latest settings.

| Name| Level-2 Parameter| Description|
| -------- | -------- | -------- |
| -h/--help | - | Help information.|
| -b/--bundlename | bundleName | Bundle name for which the waiting-for-debugging state is set. The system does not verify the validity of the bundle name.|
| -p/--persist | - | Persistence flag. This parameter is optional. If this parameter is carried, the application is set to the waiting-for-debugging state persistently. That is, the setting takes effect regardless of whether the device is restarted or the application is reinstalled. If this parameter is not carried, the state takes effect only before the device is restarted. This parameter must be used together with the **-b** parameter. Example command: **aa appdebug -b \<bundleName> -p**.|
| -c/--cancel | - | Used to cancel the waiting-for-debugging state.|
| -g/--get | - | Used to obtain the bundle name and persistence flag of an application in the waiting-for-debugging state.|

  **Return value**

  Returns "app debug successfully." if the operation is successful; returns "error: not developer mode." if the operation fails because the application is not in developer mode; returns "error: failed to app debug." if the operation fails due to other reasons.

  **Method**

  ```bash
  # Display the help information.
  aa appdebug -h

  # Set the waiting-for-debugging state for an application.
  aa appdebug -b <bundleName> [-p]

  # Cancel the waiting-for-debugging state.
  aa appdebug -c

  # Obtain the bundle name and persistence flag of an application in the waiting-for-debugging state.
  aa appdebug -g
  # Example of the obtained information: bundle name: com.example.publishsystem, persist: false
  ```

## process
  Debugs or optimizes an application. In DevEco Studio, this command is used to integrate debugging and optimization tools.

| Name| Description|
| -------- | -------- |
| -h/--help | Help information.|
| -b | Bundle name. This parameter is mandatory.|
| -a | Ability name. This parameter is mandatory.|
| -m | Module name. This parameter is optional.|
| -p | Optimization mode. This parameter is optional. Either this parameter or **-D** must be specified. This command can be customized.|
| -D | Debugging mode. This parameter is optional. Either this parameter or **-p** must be specified. This command can be customized.|
| -S | Used to enter the application sandbox. This parameter is optional.|

  **Return value**

  Returns "start native process successfully." if this command is executed successfully; returns "start native process successfully." if this command fails to be executed; returns "start native process successfully." and prints the help information if the specified parameter is invalid.

  **Method**

  ```bash
  # Display the help information.
  aa process -h

  # Debug an application.
  aa process -b <bundleName> -a <abilityName> [-m <moduleName>] [-D <debug-cmd>] [-S]

  # Optimize an application.
  aa process -b <bundleName> -a <abilityName> [-m <moduleName>] [-p <perf-cmd>] [-S]
  ```
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: aa-dump-a.png
###Image description: The image displays a terminal output from a command-line interface, specifically from the `aa dump -a` command. The output is in a text format and appears to be related to the management of mission lists and application records in a system. Below is a detailed description of the content:

### Terminal Output Description

#### Current Mission Lists:
- **MissionList Type**: #LAUNCHER
- **default stand mission list**: #DEFAULT_STANDARD
- **default single mission list**: #DEFAULT_SINGLE
- **launcher mission list**: #LAUNCHER

#### ExtensionRecords:
- **URI**: `/com.ohos.callui/com.ohos.callui.ServiceAbility`
  - **AbilityRecord ID**: #7
  - **state**: #ACTIVE
  - **start time**: [22823]
  - **main name**: [com.ohos.callui.ServiceAbility]
  - **bundle name**: [com.ohos.callui]
  - **ability type**: [SERVICE]
  - **app state**: #FOREGROUND
  - **Connections**: 0

- **URI**: `/com.ohos.launcher/com.ohos.launcher.MainAbility`
  - **AbilityRecord ID**: #6
  - **state**: #ACTIVE
  - **start time**: [17766]
  - **main name**: [com.ohos.launcher.MainAbility]
  - **bundle name**: [com.ohos.launcher]
  - **ability type**: [SERVICE]
  - **app state**: #FOREGROUND
  - **Connections**: 0

- **URI**: `/com.ohos.medialibrary.MediaScannerAbilityA/MediaScannerAbility`
  - **AbilityRecord ID**: #10
  - **state**: #ACTIVE
  - **start time**: [38435]
  - **main name**: [MediaScannerAbility]
  - **bundle name**: [com.ohos.medialibrary]
  - **ability type**: [SERVICE]
  - **app state**: #FOREGROUND
  - **Connections**: 0

- **URI**: `/com.ohos.mms/com.ohos.mms.ServiceAbility`
  - **AbilityRecord ID**: #9
  - **state**: #ACTIVE
  - **start time**: [37973]
  - **main name**: [com.ohos.mms.ServiceAbility]
  - **bundle name**: [com.ohos.mms]
  - **ability type**: [SERVICE]
  - **app state**: #FOREGROUND
  - **Connections**: 0

#### PendingWantRecords:
- **AppRunningRecords**:
  - **AppRunningRecord ID**: #0
    - **process name**: [com.ohos.launcher]
    - **pid**: #1413
    - **uid**: #20010015
    - **state**: #FOREGROUND

  - **AppRunningRecord ID**: #1
    - **process name**: [com.ohos.callui]
    - **pid**: #1504
    - **uid**: #20010008
    - **state**: #FOREGROUND

  - **AppRunningRecord ID**: #2
    - **process name**: [com.ohos.mms]
    - **pid**: #1578
    - **uid**: #20010019
    - **state**: #FOREGROUND

  - **AppRunningRecord ID**: #3
    - **process name**: [com.ohos.medialibrary.MediaScannerAbilityA]
    - **pid**: #1602
    - **uid**: #20010017
    - **state**: #FOREGROUND

  - **AppRunningRecord ID**: #4
    - **process name**: [com.ohos.medialibrary.MediaLibraryDataA]
    - **pid**: #1610
    - **uid**: #20010016
    - **state**: #FOREGROUND

### Analysis and Description

The output is structured to provide detailed information about various mission lists and application records within a system. Here's a breakdown of the key components:

1. **Current Mission Lists**:
   - The system lists different types of mission lists, including a default standard mission list and a default single mission list. The launcher mission list is also specified, indicating that it is related to the launch of applications or services.

2. **ExtensionRecords**:
   - These records detail specific services or abilities within the system. Each record includes the URI (Uniform Resource Identifier) of the service, the ability record ID, state, start time, main and bundle names, ability type, app state, and number of connections. The state
##Image Name: aa-dump-l.png
###Image description: The image shows a terminal output from a command-line interface, specifically displaying the results of the `aa dump -1` command. The output is divided into several sections, each providing information about different mission lists and their associated types. Here is a detailed description of the image:

### Terminal Output Description

#### Header Information
- **User ID**: #100
- **Current mission lists**: 
  - **MissionList Type**: #LAUNCHER

#### Default Stand Mission List
- **MissionList Type**: #DEFAULT_STANDARD

#### Default Single Mission List
- **MissionList Type**: #DEFAULT_SINGLE

#### Launcher Mission List
- **MissionList Type**: #LAUNCHER

### Analysis and Description

1. **User ID**:
   - The output begins with the user ID, which is #100. This indicates the current user or the user associated with the terminal session.

2. **Current Mission Lists**:
   - The first section lists the current mission lists available. The only mission list listed here is of type #LAUNCHER. This suggests that the current user is associated with a mission list specifically designed for launching tasks or operations.

3. **Default Stand Mission List**:
   - The next section provides information about the default stand mission list. This list is of type #DEFAULT_STANDARD, which implies that it is a standard mission list used for general operations or tasks.

4. **Default Single Mission List**:
   - The following section details the default single mission list. This list is also of type #DEFAULT_SINGLE, indicating that it is designed for single-operation tasks or missions.

5. **Launcher Mission List**:
   - The final section lists the launcher mission list, which is of type #LAUNCHER. This list is likely used for initiating or launching specific operations or tasks.

### Relevant Knowledge

- **Mission Lists**: In many command-line interfaces or systems, mission lists are predefined sets of tasks or operations that can be executed. They are often used to organize and manage different types of tasks efficiently.
- **Types of Mission Lists**: The types mentioned (#DEFAULT_STANDARD, #DEFAULT_SINGLE, #LAUNCHER) suggest different categories of mission lists. #DEFAULT_STANDARD might be for general operations, #DEFAULT_SINGLE for single-operation tasks, and #LAUNCHER for initiating tasks or operations.
- **User ID**: The user ID is a unique identifier for the user logged into the system. It helps in tracking and managing access to different resources or mission lists.

### Conclusion

The image provides a clear and structured overview of the current mission lists available to the user with the ID #100. The output is organized into sections, each detailing different types of mission lists, which helps in understanding the available options and their specific purposes. This information is crucial for users managing tasks or operations within a system that utilizes mission lists for organization and efficiency.
##Image Name: aa-dump-i.png
###Image description: The image shows a terminal output from the `aa dump` command with the `-i` and `-l` flags, displaying detailed information about an ability record with an ID of 12. The output is structured in a tabular format with various columns providing specific details about the ability record. Here is a detailed description of the image:

### Terminal Output Description:

#### Header:
- **User ID**: #100
- **AbilityRecord ID**: #12

#### Columns and Values:
1. **app name**: `com.ohos.settings`
2. **main name**: `com.ohos.settings.MainAbility`
3. **bundle name**: `com.ohos.settings`
4. **ability type**: `PAGE`
5. **state**: `#FOREGROUND_NEW`
6. **start time**: `[347199113]`
7. **app state**: `#FOREGROUND`
8. **ready**: `#1`
9. **window attached**: `#0`
10. **launcher**: `#0`
11. **callee connections**: `#0`
12. **can restart num**: `#15`

### Analysis and Description:

1. **User ID**: The user ID associated with this ability record is #100.
2. **AbilityRecord ID**: The specific ability record being displayed has an ID of #12.
3. **app name**: The application name is `com.ohos.settings`, indicating that this ability is part of the settings application.
4. **main name**: The main ability name is `com.ohos.settings.MainAbility`, which is the primary ability within the settings application.
5. **bundle name**: The bundle name is also `com.ohos.settings`, which is consistent with the app name, suggesting that this ability is part of the same bundle.
6. **ability type**: The ability type is `PAGE`, indicating that this ability is a page-based ability.
7. **state**: The state of the ability is `#FOREGROUND_NEW`, which means the ability is in the foreground and is new.
8. **start time**: The start time is `[347199113]`, which is a timestamp indicating when the ability started.
9. **app state**: The app state is `#FOREGROUND`, indicating that the entire application is in the foreground.
10. **ready**: The ability is marked as `#1`, indicating it is ready to be used.
11. **window attached**: The window is attached to the ability, marked as `#0`, indicating no window is attached.
12. **launcher**: The ability is not launched, marked as `#0`.
13. **callee connections**: There are no callee connections, marked as `#0`.
14. **can restart num**: The number of times the ability can be restarted is `#15`.

### Relevant Knowledge:

- **Ability Records**: In the context of the Android App Framework (AA), an ability record is a record of an ability within an application. Abilities are the fundamental building blocks of the AA, and they can be pages, services, or other components.
- **Foreground State**: An ability in the foreground state means it is currently active and visible to the user.
- **Restartability**: The `can restart num` field indicates how many times the ability can be restarted before it is considered for removal from the system.

### Conclusion:

This detailed output provides comprehensive information about the ability record, including its state, type, and various flags that indicate its readiness and lifecycle status. This information is crucial for developers to understand the behavior and lifecycle of an ability within an application.
