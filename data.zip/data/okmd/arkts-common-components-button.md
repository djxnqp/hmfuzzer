# Button


The **Button** component is usually activated by user clicks to perform a specific action. Buttons are classified as capsule, circle, or normal buttons. When used as a container, the **Button** component accepts child components such as text and images. For details, see [Button](../reference/apis-arkui/arkui-ts/ts-basic-components-button.md).


## Creating a Button

You can create a button that contains or does not contain child components.


- Create a button that does not contain child components.

  ```ts
  Button(label?: ResourceStr, options?: { type?: ButtonType, stateEffect?: boolean })
  ```

  In this API, **label** indicates the button text, **type** indicates the button type, and **stateEffect** specifies whether to enable the pressed effect on the click of the button.

  ```ts
  Button('Ok', { type: ButtonType.Normal, stateEffect: true }) 
    .borderRadius(8) 
    .backgroundColor(0x317aff) 
    .width(90)
    .height(40)
  ```

  ![en-us_image_0000001562820757](figures/en-us_image_0000001562820757.png)


- Create a button that contains a single child component.

  ```ts
  Button(options?: {type?: ButtonType, stateEffect?: boolean})
  ```

  The child component contained can either be a basic component or a container component.

  ```ts
  Button({ type: ButtonType.Normal, stateEffect: true }) {
    Row() {
      Image($r('app.media.loading')).width(20).height(40).margin({ left: 12 })
      Text('loading').fontSize(12).fontColor(0xffffff).margin({ left: 5, right: 12 })
    }.alignItems(VerticalAlign.Center)
  }.borderRadius(8).backgroundColor(0x317aff).width(90).height(40)
  ```

  ![en-us_image_0000001511421216](figures/en-us_image_0000001511421216.png)


## Setting the Button Type

Use the **type** parameter to set the button type to **Capsule**, **Circle**, or **Normal**.


- Capsule button (default type)

  Buttons of this type have rounded corners whose radius is automatically set to half of the button height. The rounded corners cannot be reset through the **borderRadius** attribute.

  ```ts
  Button('Disable', { type: ButtonType.Capsule, stateEffect: false }) 
    .backgroundColor(0x317aff) 
    .width(90)
    .height(40)
  ```

  ![en-us_image_0000001511421208](figures/en-us_image_0000001511421208.png)


- Circle button

  Buttons of this type are round. The rounded corners cannot be reset through the **borderRadius** attribute.

  ```ts
  Button('Circle', { type: ButtonType.Circle, stateEffect: false }) 
    .backgroundColor(0x317aff) 
    .width(90) 
    .height(90)
  ```

  ![en-us_image_0000001511740428](figures/en-us_image_0000001511740428.png)

- Normal button

  Buttons of this type have rounded corners set to 0. The rounded corners can be reset through the **borderRadius** attribute.

  ```ts
  Button('Ok', { type: ButtonType.Normal, stateEffect: true }) 
    .borderRadius(8) 
    .backgroundColor(0x317aff) 
    .width(90)
    .height(40)
  ```

  ![en-us_image_0000001563060641](figures/en-us_image_0000001563060641.png)


## Setting Styles

- Set the border radius.

  You can use universal attributes to define the button styles. For example, you can use the **borderRadius** attribute to set the border radius.

  ```ts
  Button('circle border', { type: ButtonType.Normal }) 
    .borderRadius(20)
    .height(40)
  ```

  ![en-us_image_0000001511900392](figures/en-us_image_0000001511900392.png)


- Set the text style.

  Add text style attributes for the button.

  ```ts
  Button('font style', { type: ButtonType.Normal }) 
    .fontSize(20) 
    .fontColor(Color.Pink) 
    .fontWeight(800)
  ```

  ![en-us_image_0000001511580828](figures/en-us_image_0000001511580828.png)


- Set the background color.

  Add the **backgroundColor** attribute for the button.

  ```ts
  Button('background color').backgroundColor(0xF55A42)
  ```

  ![en-us_image_0000001562940477](figures/en-us_image_0000001562940477.png)


- Assign a function to the button.

  In this example, the delete function is assigned to the button.

  ```ts
  let MarLeft: Record<string, number> = { 'left': 20 }
  Button({ type: ButtonType.Circle, stateEffect: true }) {
    Image($r('app.media.ic_public_delete_filled')).width(30).height(30)
  }.width(55).height(55).margin(MarLeft).backgroundColor(0xF55A42)
  ```

  ![en-us_image_0000001511740436](figures/en-us_image_0000001511740436.png)


## Adding Events

The **Button** component is usually used to trigger actions. You can bind the **onClick** event to the button to have it respond with custom behavior after being clicked.

```ts
Button('Ok', { type: ButtonType.Normal, stateEffect: true }) 
  .onClick(()=>{ 
    console.info('Button onClick') 
  })
```


## Example

- Using the button for startup

  You can use the button for any UI element that involves the startup operation. The button triggers the predefined event based on the user's operation. For example, you can use a button in the **List** container to redirect the user to another page.

  ```ts
  // xxx.ets
  @Entry
  @Component
  struct ButtonCase1 {
    pathStack: NavPathStack = new NavPathStack();

    @Builder
    PageMap(name: string) {
      if (name === "first_page") {
        pageOneTmp()
      } else if (name === "second_page") {
        pageTwoTmp()
      } else if (name === "third_page") {
        pageThreeTmp()
      }
    }

    build() {
      Navigation(this.pathStack) {
        List({ space: 4 }) {
          ListItem() {
            Button("First").onClick(() => {
              this.pathStack.pushPath({ name: "first_page"})
            })
              .width('100%')
          }

          ListItem() {
            Button("Second").onClick(() => {
              this.pathStack.pushPath({ name: "second_page"})
            })
              .width('100%')
          }

          ListItem() {
            Button("Third").onClick(() => {
              this.pathStack.pushPath({ name: "third_page"})
            })
              .width('100%')
          }
        }
        .listDirection(Axis.Vertical)
        .backgroundColor(0xDCDCDC).padding(20)
      }
      .mode(NavigationMode.Stack)
      .navDestination(this.PageMap)
    }
  }

  // pageOne
  @Component
  export struct pageOneTmp {
    pathStack: NavPathStack = new NavPathStack();
  
    build() {
      NavDestination() {
        Column() {
          Text("first_page")
        }.width('100%').height('100%')
      }.title("pageOne")
      .onBackPressed(() => {
        const popDestinationInfo = this.pathStack.pop() // Pop the top element out of the navigation stack.
        console.log('pop' + 'Return value' + JSON.stringify(popDestinationInfo))
        return true
      })
      .onReady((context: NavDestinationContext) => {
        this.pathStack = context.pathStack
      })
    }
  }

  // pageTwo
  @Component
  export struct pageTwoTmp {
    pathStack: NavPathStack = new NavPathStack();

    build() {
      NavDestination() {
        Column() {
          Text("second_page")
        }.width('100%').height('100%')
      }.title("pageTwo")
      .onBackPressed(() => {
        const popDestinationInfo = this.pathStack.pop() // Pop the top element out of the navigation stack.
        console.log('pop' + 'Return value' + JSON.stringify(popDestinationInfo))
        return true
      })
      .onReady((context: NavDestinationContext) => {
        this.pathStack = context.pathStack
      })
    }
  }

  // pageThree
  @Component
  export struct pageThreeTmp {
    pathStack: NavPathStack = new NavPathStack();

    build() {
      NavDestination() {
        Column() {
          Text("third_page")
        }.width('100%').height('100%')
      }.title("pageThree")
      .onBackPressed(() => {
        const popDestinationInfo = this.pathStack.pop() // Pop the top element out of the navigation stack.
        console.log('pop' + 'Return value' + JSON.stringify(popDestinationInfo))
        return true
      })
      .onReady((context: NavDestinationContext) => {
        this.pathStack = context.pathStack
      })
    }
  }
  ```

  ![en-us_image_0000001562700393](figures/en-us_image_0000001562700393.png)


- Using the button for submitting forms

  On the user login/registration page, you can use a button to submit a login or registration request.

  ```ts
  // xxx.ets
  @Entry
  @Component
  struct ButtonCase2 {
    build() {
      Column() {
        TextInput({ placeholder: 'input your username' }).margin({ top: 20 })
        TextInput({ placeholder: 'input your password' }).type(InputType.Password).margin({ top: 20 })
        Button('Register').width(300).margin({ top: 20 })
          .onClick(() => {
            // Operation
          })
      }.padding(20)
    }
  }
  ```

  ![en-us_image_0000001562940473](figures/en-us_image_0000001562940473.png)

- Configuring the button to float

  The button can remain floating when the user swipes on the screen.

  ```ts
  // xxx.ets
  @Entry
  @Component
  struct HoverButtonExample {
    private arr: number[] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    build() {
      Stack() {
        List({ space: 20, initialIndex: 0 }) {
          ForEach(this.arr, (item:number) => {
            ListItem() {
              Text('' + item)
                .width('100%').height(100).fontSize(16)
                .textAlign(TextAlign.Center).borderRadius(10).backgroundColor(0xFFFFFF)
            }
          }, (item:number) => item.toString())
        }.width('90%')
        Button() {
          Image($r('app.media.ic_public_add'))
            .width(50)
            .height(50)
        }
        .width(60)
        .height(60)
        .position({x: '80%', y: 600})
        .shadow({radius: 10})
        .onClick(() => {
          // Operation
        })
      }
      .width('100%')
      .height('100%')
      .backgroundColor(0xDCDCDC)
      .padding({ top: 5 })
    }
  }
  ```

  ![floating_button](figures/floating_button.gif)
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: en-us_image_0000001562820757.png
###Image description: The image shows a blue button with the word "Ok" written on it. The button appears to be a simple, flat design with a rounded rectangular shape. The background is a solid blue color, and the text is white, making it stand out against the blue background. The overall design is minimalistic and clean.
##Image Name: en-us_image_0000001511421216.png
###Image description: The image shows a simple, blue square icon with the word "loading" written inside it. The icon is designed to indicate that a process is currently underway and may take some time to complete. The background of the icon is a solid blue color, and the text is white, making it stand out against the blue background. The overall design is minimalistic and straightforward, commonly used in user interfaces to provide feedback on the status of a task.
##Image Name: en-us_image_0000001511421208.png
###Image description: The image shows a button with the word "Disable" written on it. The button has a blue background with a white outline and a white border. The text is in a bold, sans-serif font. The button appears to be a simple, flat design, commonly used in user interfaces to indicate an action that can be turned off or disabled.
##Image Name: en-us_image_0000001511740428.png
###Image description: The image shows a blue circle with the word "Circle" written inside it.
##Image Name: en-us_image_0000001563060641.png
###Image description: The image shows a blue button with the word "Ok" written on it. The button appears to be a simple, flat design with a rounded rectangular shape. The background is a solid blue color, and the text is white, making it stand out against the blue background. The overall design is minimalistic and clean.
##Image Name: en-us_image_0000001511900392.png
###Image description: The image depicts a button with a blue background and a white circle border. The text "circle border" is written in white, uppercase letters inside the circle. The button appears to be a simple, rounded rectangle with a white outline that forms a circle around the text.
##Image Name: en-us_image_0000001511580828.png
###Image description: The image features a rectangular button with a blue background and a pink text. The text on the button reads "font style" in a sans-serif font. The button appears to be a simple interface element, possibly used in a software application or a website to indicate a feature or option related to font styling. The blue background contrasts with the pink text, making the text stand out and easily readable. The overall design is minimalistic and clean, focusing on the text to convey its purpose.
##Image Name: en-us_image_0000001562940477.png
###Image description: The image shows a button with a rounded rectangular shape. The background color of the button is a gradient that transitions from a darker shade at the top to a lighter shade at the bottom. The text "background color" is written in a white, sans-serif font in the center of the button. The overall design is simple and clean, with a focus on the text and the gradient background.
##Image Name: en-us_image_0000001511740436.png
###Image description: The image shows a simple icon consisting of a white trash can with a black outline, set against a solid orange circle. The trash can is positioned in the center of the orange circle. This icon is commonly used to represent the concept of deleting or removing items, typically in the context of digital interfaces such as computer operating systems, file managers, or application interfaces.
##Image Name: en-us_image_0000001562700393.png
###Image description: The image shows three blue rectangular buttons arranged vertically. Each button has a rounded rectangular shape with a slight shadow effect, giving it a three-dimensional appearance. The buttons are labeled with the text "First," "Second," and "Third," respectively, from top to bottom. The background of the image is a light gray color.
##Image Name: en-us_image_0000001562940473.png
###Image description: The image depicts a registration form interface, likely from a mobile application or website. The form consists of two input fields and a button. Here is a detailed description of each element:

1. **Input Your Username**: This is the first input field, which is labeled "input your username." It is a text box where users can enter their desired username. The text box is rectangular and has a placeholder text that reads "input your username."

2. **Input Your Password**: This is the second input field, which is labeled "input your password." It is also a text box, but it has a small icon next to it that resembles an eye with a line through it. This icon typically indicates that the password can be viewed as plain text. The text box is rectangular and has a placeholder text that reads "input your password."

3. **Register**: This is a button located below the two input fields. The button is rectangular and has a blue background with white text that reads "Register." The button is designed to initiate the registration process once the user has entered their username and password.

### Analysis and Description

The registration form is designed to collect essential information from the user to create an account. The two primary fields, "username" and "password," are fundamental components of any registration process. The username field allows users to choose a unique identifier for their account, while the password field is where users enter their chosen password for security purposes.

The presence of the eye icon next to the password field suggests that the application offers a feature to view the password in plain text. This can be useful for users who want to ensure they have entered their password correctly or for those who are concerned about typing errors. However, it is important to note that displaying passwords in plain text can pose security risks, as it might be visible to others if the user is not using a secure connection or if the application is not properly securing the password.

The "Register" button is a critical component of the form, as it initiates the account creation process. When the user clicks this button, the application typically processes the entered username and password, verifies them, and creates a new account for the user.

### Conclusion

In summary, the image shows a simple yet functional registration form with two input fields for the username and password, and a "Register" button to complete the account creation process. The design is user-friendly, with clear labels and a visual cue for password visibility.
