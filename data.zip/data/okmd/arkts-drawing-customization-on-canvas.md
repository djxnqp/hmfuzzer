# Drawing Custom Graphics Using the Canvas (Canvas)


**Canvas** provides a canvas component for drawing custom graphics. You can use the **CanvasRenderingContext2D** and **OffscreenCanvasRenderingContext2D** objects to draw graphics on the **Canvas** component. The drawing objects can be basic shapes, text, and images.


## Drawing Custom Graphics on the Canvas

You can draw custom graphics on the canvas in any of the following ways:


- Use [CanvasRenderingContext2D](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md).

  ```ts
  @Entry
  @Component
  struct CanvasExample1 {
    // Configure the parameters of the CanvasRenderingContext2D object, including whether to enable anti-aliasing. The value true indicates that anti-aliasing is enabled.
    private settings: RenderingContextSettings = new RenderingContextSettings(true)
    // Create a CanvasRenderingContext2D object by calling CanvasRenderingContext2D object in Canvas.
    private context: CanvasRenderingContext2D = new CanvasRenderingContext2D(this.settings)
  
    build() {
      Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
        // Invoke the CanvasRenderingContext2D object in Canvas.
        Canvas(this.context)
          .width('100%')
          .height('100%')
          .backgroundColor('#F5DC62')
          .onReady(() => {
            // You can draw content here.
            this.context.strokeRect(50, 50, 200, 150);
          })
      }
      .width('100%')
      .height('100%')
    }
  }
  
  ```

  ![2023022793003(1)](figures/2023022793003(1).jpg)

- Drawing offscreen onto a canvas is a process where content to draw onto the canvas is first drawn in the buffer, and then converted into a picture, and finally the picture is drawn on the canvas. This process increases the drawing efficiency. Specifically, the implementation is as follows:
  1. Use the **transferToImageBitmap** API to create an **ImageBitmap** object for the image that is recently rendered off the screen canvas.
  2. Use the **transferFromImageBitmap** API of the **CanvasRenderingContext2D** object to display the given **ImageBitmap** object.

    For details, see [OffscreenCanvasRenderingContext2D](../reference/apis-arkui/arkui-ts/ts-offscreencanvasrenderingcontext2d.md).

  ```ts
  @Entry
  @Component
  struct CanvasExample2 {
  // Configure the parameters of the CanvasRenderingContext2D and OffscreenCanvasRenderingContext2D objects, including whether to enable anti-aliasing. The value true indicates that anti-aliasing is enabled.
    private settings: RenderingContextSettings = new RenderingContextSettings(true)
    private context: CanvasRenderingContext2D = new CanvasRenderingContext2D(this.settings)
  // Create an OffscreenCanvas object. width indicates the width of the offscreen canvas, and height indicates the height of the offscreen canvas.
    private offCanvas: OffscreenCanvas = new OffscreenCanvas(600, 600)
   
    build() {
      Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
        Canvas(this.context)
          .width('100%')
          .height('100%')
          .backgroundColor('#F5DC62')
          .onReady(() =>{
            let offContext = this.offCanvas.getContext("2d", this.settings)
            // You can draw content here.
            offContext.strokeRect(50, 50, 200, 150);
            // Display the image rendered by the offscreen drawing value on the common canvas.
            let image = this.offCanvas.transferToImageBitmap();
            this.context.transferFromImageBitmap(image);
          })
      }
      .width('100%')
      .height('100%')
    }
  }

  ```

  ![2023022793003(1)](figures/2023022793003(1).jpg)

  >**NOTE**
  >
  >The APIs called for drawing on the canvas through the **CanvasRenderingContext2D** and **OffscreenCanvasRenderingContext2D** objects are the same. Unless otherwise specified, the value unit of the parameters in these APIs is vp.

- Before loading the Lottie animation on the canvas, download the Lottie as follows:

  ```ts
  import lottie from '@ohos/lottie'
  ```

  For details about the APIs, see [Lottie](https://gitee.com/openharmony-tpc/lottieETS).


## Initializing the Canvas Component

**onReady(event: () =&gt; void)** is the event callback when the **Canvas** component initialization is complete. After this event is called, the determined width and height of the **Canvas** component can be obtained. The **CanvasRenderingContext2D** and **OffscreenCanvasRenderingContext2D** objects can then be used to call related APIs to draw graphics.

```ts
Canvas(this.context)
  .width('100%')
  .height('100%')
  .backgroundColor('#F5DC62')
  .onReady(() => {
    this.context.fillStyle = '#0097D4';
    this.context.fillRect(50, 50, 100, 100);
  })
```

![2023022793350(1)](figures/2023022793350(1).jpg)


## Canvas Component Drawing Modes

After **onReady()** is invoked, you can use the **Canvas** component for drawing. Alternatively, you can separately define the **Path2d** object to build an ideal path without the **Canvas** component and **onReady()** lifecycle callback, and then use the **Canvas** component for drawing after **onReady()** is invoked.

- After the **onReady()** callback of the **Canvas** component is invoked, use the **CanvasRenderingContext2D** and **OffscreenCanvasRenderingContext2D** objects to call related APIs for drawing.

  ```ts
  Canvas(this.context)
    .width('100%')
    .height('100%')
    .backgroundColor('#F5DC62')
    .onReady(() =>{
      this.context.beginPath();
      this.context.moveTo(50, 50);
      this.context.lineTo(280, 160);
      this.context.stroke();
     })
  ```

  ![2023022793719(1)](figures/2023022793719(1).jpg)

- Define an individual **path2d** object to build an ideal path, and then call the **stroke** or **fill** API of the **CanvasRenderingContext2D** and **OffscreenCanvasRenderingContext2D** objects to draw the path. For details, see [Path2D](../reference/apis-arkui/arkui-ts/ts-components-canvas-path2d.md).

  ```ts
  Canvas(this.context)
    .width('100%')
    .height('100%')
    .backgroundColor('#F5DC62')
    .onReady(() =>{
       let region = new Path2D();
       region.arc(100, 75, 50, 0, 6.28);
       this.context.stroke(region);
    })
  ```

  ![2023022794031(1)](figures/2023022794031(1).jpg)


## Common Usage of the Canvas Component

**OffscreenCanvasRenderingContext2D** and **CanvasRenderingContext2D** provide a large number of attributes and methods, which can be used to draw text and graphics and process pixels. They are the core of the **Canvas** component. Common APIs include [fill](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#fill), [clip](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#clip), and [stroke](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#stroke). In addition, attributes such as [fillStyle](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#fillstyle), [globalAlpha](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#globalalpha), and [strokeStyle](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#strokestyle) are provided to spruce up the graphics. This topic describes typical usage of the canvas.

- Draw a basic shape.
  You can draw a basic shape by calling APIs such as [arc](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#arc), [ellipse](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#ellipse), and [rect](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#rect).

  ```ts
  Canvas(this.context)
    .width('100%')
    .height('100%')
    .backgroundColor('#F5DC62')
    .onReady(() =>{
       // Draw a rectangle.
       this.context.beginPath();
       this.context.rect(100, 50, 100, 100);
       this.context.stroke();
       // Draw a circle on the canvas.
       this.context.beginPath();
       this.context.arc(150, 250, 50, 0, 6.28);
       this.context.stroke();
       // Draw an oval on the canvas.
       this.context.beginPath();
       this.context.ellipse(150, 450, 50, 100, Math.PI * 0.25, Math.PI * 0, Math.PI * 2);
       this.context.stroke();
    })
  ```

  ![2023022794521(1)](figures/2023022794521(1).jpg)

- Draw text.

  You can use APIs such as [fillText](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#filltext) and [strokeText](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#stroketext) to draw text.

  ```ts
  Canvas(this.context)
    .width('100%')
    .height('100%')
    .backgroundColor('#F5DC62')
    .onReady(() => {
      // Draw filled text on the canvas.
      this.context.font = '50px bolder sans-serif';
      this.context.fillText("Hello World!", 50, 100);
      // Draw a text stroke on the canvas.
      this.context.strokeStyle = "#ff0000"
      this.context.lineWidth = 2
      this.context.font = '50px bolder sans-serif';
      this.context.strokeText("Hello World!", 50, 150);
    })
  ```

  ![2023022795105(1)](figures/2023022795105(1).jpg)

- Draw text with a custom font.

  You can use the [font](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#font) API to load a custom font, and then use the [fillText](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#filltext) and [strokeText](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#stroketext) APIs to draw text.

  ```ts
  Canvas(this.context)
    .width('100%')
    .height('100%')
    .backgroundColor('#F5DC62')
    .onReady(() =>{
      // Load a custom font.
      this.context.font = '30vp customFont'
      this.context.fillText("Hello World!", 20, 50)
      this.context.strokeText("Hello World!", 20, 100)
    })
  ```

  ![customFont](figures/customFont.jpeg)

- Draw images and processes image pixel information.

  You can draw an image by calling APIs such as [drawImage](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#drawimage) and [putImageData](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#putimagedata). You can also process image pixel information by calling APIs such as [createImageData](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#createimagedata), [getPixelMap](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#getpixelmap), and [getImageData](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#getimagedata).

  ```ts
  @Entry
  @Component
  struct GetImageData {
   private settings: RenderingContextSettings = new RenderingContextSettings(true)
   private context: CanvasRenderingContext2D = new CanvasRenderingContext2D(this.settings)
   private offCanvas: OffscreenCanvas = new OffscreenCanvas(600, 600)
   private img:ImageBitmap = new ImageBitmap("/common/images/1234.png")

    build() {
      Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
        Canvas(this.context)
          .width('100%')
          .height('100%')
          .backgroundColor('#F5DC62')
          .onReady(() =>{
            let offContext = this.offCanvas.getContext("2d", this.settings)
            // Use the drawImage API to draw an image in the area with the width and height of 130 starting from (0, 0).
            offContext.drawImage(this.img,0,0,130,130);
            // Use the getImageData API to obtain the image data with the width and height of 130 starting from (50, 50).
            let imagedata = offContext.getImageData(50,50,130,130);
            // Use the putImageData API to draw the obtained image data in the area starting from (150, 150).
            offContext.putImageData(imagedata,150,150);
            // Draw the offscreen drawing content to the canvas.
            let image = this.offCanvas.transferToImageBitmap();
            this.context.transferFromImageBitmap(image);
          })
      }
      .width('100%')
      .height('100%')
    }
  }
  ```

  ![drawimage](figures/drawimage.PNG)

- Other usage

  **Canvas** also provides other usage. For example, regarding [CanvasGradient](../reference/apis-arkui/arkui-ts/ts-components-canvas-canvasgradient.md), you can create a linear gradient with [createLinearGradient](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#createlineargradient) or create a radial gradient with [createRadialGradient](../reference/apis-arkui/arkui-ts/ts-canvasrenderingcontext2d.md#createradialgradient), among others.

  ```ts
    Canvas(this.context)
    .width('100%')
    .height('100%')
    .backgroundColor('#F5DC62')
    .onReady(() =>{
       // Create a CanvasGradient object with radial gradient colors.
       let grad = this.context.createRadialGradient(200,200,50, 200,200,200)
       // Set the gradient color stop for the CanvasGradient object, including the offset and colors.
       grad.addColorStop(0.0, '#E87361');
       grad.addColorStop(0.5, '#FFFFF0');
       grad.addColorStop(1.0, '#BDDB69');
       // Fill the rectangle with the CanvasGradient object.
       this.context.fillStyle = grad;
       this.context.fillRect(0, 0, 400, 400);
    })
  ```

  ![2023022700701(1)](figures/2023022700701(1).jpg)


## Example Scenario

- Draw a basic shape.

  ```ts
  @Entry
  @Component
  struct ClearRect {
   private settings: RenderingContextSettings = new RenderingContextSettings(true);
   private context: CanvasRenderingContext2D = new CanvasRenderingContext2D(this.settings);

    build() {
      Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
        Canvas(this.context)
          .width('100%')
          .height('100%')
          .backgroundColor('#F5DC62')
          .onReady(() =>{
            // Set the fill color to blue.
            this.context.fillStyle = '#0097D4';
            // Take (50, 50) as the upper left corner and draw a rectangle with the width and height of 200.
            this.context.fillRect(50,50,200,200);
            // Use (70, 70) as the upper left corner and clear the area with the width of 150 and height of 100.
            this.context.clearRect(70,70,150,100);
        })
      }
      .width('100%')
      .height('100%')
    }
  }

  ```

  ![2023022701120(1)](figures/2023022701120(1).jpg)

- Draw an irregular shape.

  ```ts
  @Entry
  @Component
  struct Path2d {
    private settings: RenderingContextSettings = new RenderingContextSettings(true);
    private context: CanvasRenderingContext2D = new CanvasRenderingContext2D(this.settings);
    
    build() {
      Row() {
        Column() {
          Canvas(this.context)
            .width('100%')
            .height('100%')
            .backgroundColor('#F5DC62')
            .onReady(() =>{
              // Use the Path2D API to create a pentagon.
              let path = new Path2D();
              path.moveTo(150, 50);
              path.lineTo(50, 150);
              path.lineTo(100, 250);
              path.lineTo(200, 250);
              path.lineTo(250, 150);
              path.closePath();
              // Set the fill color to blue.
              this.context.fillStyle = '#0097D4';
              // Draw the pentagon described by Path2D in the canvas in fill mode.
              this.context.fill(path);
            })
        }
        .width('100%')
      }
      .height('100%')
    }
  }
  ```

  ![2023032422159](figures/2023032422159.jpg)
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: 2023022793003(1).jpg
###Image description: The image depicts a simple, minimalist design featuring a solid yellow background. At the center of the image, there is a rectangular outline that is also yellow. The rectangle is positioned slightly off-center, leaning towards the upper right quadrant of the image. The outline of the rectangle is thin and appears to be drawn with a light, possibly white or off-white, line. The background and the rectangle share the same color, creating a monochromatic effect. There are no other objects, text, or additional elements present in the image. The overall aesthetic is clean and straightforward, with a focus on the geometric shape and color.
##Image Name: 2023022793003(1).jpg
###Image description: The image depicts a simple, minimalist design featuring a solid yellow background. At the center of the image, there is a rectangular outline that is also yellow. The rectangle is positioned slightly off-center, leaning towards the upper right quadrant of the image. The outline of the rectangle is thin and appears to be drawn with a light, possibly white or off-white, line. The background and the rectangle share the same color, creating a monochromatic effect. There are no other objects, text, or additional elements present in the image. The overall aesthetic is clean and straightforward, with a focus on the geometric shape and color.
##Image Name: 2023022793350(1).jpg
###Image description: The image features a simple composition with two primary colors: yellow and blue. The background is a solid yellow color, providing a bright and cheerful backdrop. In the center of the image, there is a blue square. The blue square is positioned slightly off-center to the left, creating a balanced yet slightly asymmetrical visual effect. The edges of the blue square are sharp and well-defined, contrasting with the smooth, uniform yellow background. The simplicity of the design, with its minimalistic use of color and shape, gives the image a clean and modern aesthetic.
##Image Name: 2023022793719(1).jpg
###Image description: The image depicts a simple, minimalist design featuring a single, straight line against a solid yellow background. The line is thin and appears to be drawn with a light, possibly metallic color, creating a subtle contrast with the bright yellow backdrop. The line extends diagonally from the top left corner of the image to the bottom right corner, suggesting a sense of direction or movement. The simplicity of the design and the use of a single element create a clean and modern aesthetic. There are no other objects, text, or additional elements present in the image. The overall composition is balanced and straightforward, focusing the viewer's attention on the line itself.
##Image Name: 2023022794031(1).jpg
###Image description: The image depicts a simple geometric shape against a solid background. The background is a uniform light yellow color. In the center of the image, there is a single, thin black circle. The circle is perfectly centered and appears to be drawn with a consistent thickness, creating a clear and distinct boundary around the inner area of the circle. The circle itself is a perfect circle, meaning it has no distortions or irregularities.

The simplicity of the image suggests it might be used for various purposes such as a placeholder, a design element, or a part of a larger graphic. The light yellow background provides a high contrast to the black circle, making the circle stand out prominently. There are no other objects, text, or additional elements present in the image.

### Analysis and Description

1. **Shape and Color**:
   - The shape is a circle.
   - The color of the circle is black.
   - The background color is light yellow.

2. **Position and Orientation**:
   - The circle is centered in the image.
   - The circle is oriented horizontally and vertically, meaning it is perfectly aligned with the edges of the image.

3. **Contrast and Visibility**:
   - The black circle contrasts sharply with the light yellow background, making it highly visible.
   - The uniform thickness of the circle's outline ensures that it is easily distinguishable.

4. **Potential Uses**:
   - The image could be used as a placeholder for a larger graphic or design.
   - It might serve as a simple design element in a larger composition.
   - The simplicity of the image makes it versatile for various applications where a clean, minimalistic look is desired.

### Conclusion

The image is a straightforward representation of a black circle centered on a light yellow background. The simplicity and clarity of the design make it a versatile element that can be used in various contexts. The contrast between the black circle and the yellow background ensures that the circle is easily noticeable, making it a useful design component.
##Image Name: 2023022794521(1).jpg
###Image description: The image depicts a simple geometric figure composed of three distinct shapes arranged vertically on a solid yellow background. The shapes are outlined in black and are as follows:

1. **Square**: At the top of the image, there is a square. The square has four equal sides and four right angles. The outline of the square is perfectly symmetrical, with each side measuring the same length.

2. **Circle**: Below the square, there is a circle. The circle is perfectly round, with all points on its boundary equidistant from its center. The circle's outline is smooth and continuous, indicating that it is a perfect circle.

3. **Oval**: At the bottom of the image, there is an oval. The oval is an elongated circle, with one axis being longer than the other. The oval's outline is smooth and continuous, but it is not perfectly symmetrical, as the two axes are not equal in length.

The shapes are arranged in a vertical sequence from top to bottom, with the square at the top, the circle in the middle, and the oval at the bottom. The background is a solid yellow color, which contrasts with the black outlines of the shapes, making them stand out clearly.

### Analysis and Description

The image is a basic representation of three fundamental geometric shapes: a square, a circle, and an oval. Each shape is outlined in black, providing a clear and distinct boundary against the yellow background. The square is a regular polygon with four equal sides and four right angles, demonstrating symmetry and uniformity. The circle is a perfectly round shape with all points on its boundary equidistant from its center, showcasing uniformity in its circumference. The oval, on the other hand, is an elongated circle, which means it has two axes of different lengths, creating an asymmetrical shape.

### Relevant Knowledge

- **Square**: A square is a special type of rectangle where all four sides are of equal length. It is a regular quadrilateral, meaning all its angles are right angles (90 degrees).
- **Circle**: A circle is a simple closed shape in Euclidean geometry. It is the set of all points in a plane that are at a given distance from a given point, the center.
- **Oval**: An oval is a closed curve in a plane which has the property that all points on the curve are equidistant from a single point. It is a generalization of a circle.

### Conclusion

The image effectively demonstrates the basic geometric shapes of a square, circle, and oval. Each shape is clearly outlined and positioned in a vertical sequence, making it easy to distinguish and understand the differences between them. The use of a solid yellow background enhances the visibility of the black outlines, providing a clear and simple visual representation of these fundamental shapes.
##Image Name: 2023022795105(1).jpg
###Image description: The image is a simple, rectangular graphic with a solid yellow background. The text on the image is in a bold, sans-serif font. The text is written in two lines, with the first line being "Hello World!" and the second line being "Hello World!" as well. The text is centered both horizontally and vertically within the image. The font color is black, which contrasts sharply with the yellow background, making the text easily readable. The overall design is minimalistic and straightforward, with no additional graphics or elements present.
##Image Name: customFont.jpeg
###Image description: The image features a yellow background with the text "Hello World!" prominently displayed in two different styles. The first instance of "Hello World!" is written in a bold, black font at the top of the image. The second instance, also in black, is written in a cursive, playful font at the bottom of the image. The text is centered horizontally and vertically within the image. The overall design is simple and eye-catching, with the contrasting fonts and colors making the text stand out.
##Image Name: drawimage.PNG
###Image description: The image consists of two distinct sections placed side by side against a yellow background. The left section features a panoramic view of a landscape, while the right section shows a close-up view of the same landscape.

### Left Section:
- **Landscape View**: The left section displays a panoramic view of a vast, expansive landscape. The terrain appears to be a mix of greenery and open spaces, suggesting a natural environment. The horizon is visible, indicating a vast expanse of land stretching out into the distance.
- **Sky**: The sky is clear and blue, with no visible clouds, suggesting a bright and sunny day.
- **Vegetation**: The landscape is predominantly covered with green vegetation, including trees and possibly fields or meadows. The greenery is dense, indicating a healthy and thriving ecosystem.
- **Foreground**: The foreground is less detailed, but it appears to be a mix of grass and possibly some low-lying vegetation or ground cover.

### Right Section:
- **Close-Up View**: The right section provides a close-up view of the same landscape, focusing on a specific area within the panoramic view on the left. This close-up reveals more detailed features of the vegetation and terrain.
- **Vegetation**: The close-up view shows a variety of trees and possibly bushes or shrubs. The leaves are green, indicating healthy vegetation.
- **Terrain**: The terrain in the close-up view is more varied, with different types of vegetation and possibly some rocky or uneven ground. The details of the landscape are more pronounced, allowing for a better understanding of the texture and composition of the area.

### Analysis:
The image captures a serene and natural landscape, likely a mountainous or hilly region. The clear sky and lush greenery suggest a healthy environment, possibly in a region with ample rainfall and favorable climate conditions. The panoramic view on the left provides a broad perspective of the landscape, while the close-up on the right offers a detailed look at the vegetation and terrain, highlighting the diversity and richness of the ecosystem.

### Conclusion:
This image effectively showcases the beauty and diversity of a natural landscape, emphasizing the importance of preserving such environments for ecological balance and biodiversity. The contrast between the panoramic and close-up views allows for a comprehensive understanding of the landscape's features and the intricate details of the vegetation.
##Image Name: 2023022700701(1).jpg
###Image description: The image depicts a gradient transition between two colors. The left side of the image is a bright green, while the right side is a bright yellow. The transition between these two colors is smooth and gradual, creating a visually appealing gradient effect. The green color is more dominant on the left side, while the yellow color is more prominent on the right side. The gradient is circular, with the center of the circle being a mix of both colors, transitioning smoothly from green to yellow as you move from the center outward. The overall effect is a soft, blended color transition that creates a sense of depth and movement within the image.
##Image Name: 2023022701120(1).jpg
###Image description: The image features a simple geometric design consisting of two squares. The larger square is yellow, and the smaller square is blue. The blue square is positioned in the upper right corner of the yellow square. The background of the image is also yellow, creating a monochromatic color scheme with a strong contrast between the blue and yellow squares.
##Image Name: 2023032422159.jpg
###Image description: The image features a simple geometric shape against a solid background. The shape is a pentagon, which is a five-sided polygon. The pentagon is colored blue and is positioned towards the left side of the image. The background is a solid yellow color, providing a stark contrast to the blue pentagon. The pentagon appears to be centered horizontally within the image, and there are no other objects or elements present in the image. The overall composition is minimalistic and clean, with the focus solely on the blue pentagon and the yellow background.
