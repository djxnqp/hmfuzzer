# Repeat: Reusing Child Components

>**NOTE**
>
>Repeat is supported since API version 12.
>

For details about API parameters, see [Repeat APIs](https://gitee.com/openharmony/docs/blob/master/en/application-dev/reference/apis-arkui/arkui-ts/ts-rendering-control-repeat.md).

In the non-virtualScroll scenario (that is, **virtualScroll** is disabled), **Repeat**, used together with container components, renders repeated components based on the data source. In addition, the component returned by the API must be a child component that can be contained in the **Repeat** parent container component. Compared with ForEach, **Repeat** optimizes the rendering performance in some update scenarios and generates function with the index maintained by the framework.

When virtualScroll is enabled, **Repeat** iterates data from the provided data source as required and creates the corresponding component during each iteration. In this way, **Repeat** must be used together with the scrolling container component. When **Repeat** is used in the scrolling container component, the framework creates components as required based on the visible area of the scrolling container. When a component slides out of the visible area, the framework caches the component and uses it in the next iteration.

> **Note:**
>
> When **virtualScroll** is enabled, **Repeat** is not fully compatible with the decorators of V1. Using them together may throw an exception during rendering.

## Constraints

- Repeat uses key value as identifiers. Therefore, **key()** must generate a unique value for each data.
- **Repeat virtualScroll** must be used in the scrolling container component. Only the [List](../reference/apis-arkui/arkui-ts/ts-container-list.md), [Grid](../reference/apis-arkui/arkui-ts/ts-container-grid.md), [Swiper](../reference/apis-arkui/arkui-ts/ts-container-swiper.md), and [WaterFlow](../reference/apis-arkui/arkui-ts/ts-container-waterflow.md) components support this scenario. In this case, **cachedCount** takes effect. Other container components apply only to the non-virtualScroll scenario.
- After **virtualScroll** is enabled for **Repeat**, only one child component can be created in each iteration. Otherwise, there is no constraint. The generated child components must be allowed in the parent container component of **Repeat**.
- When **Repeat** and **\@Builder** are used together, parameters of the **RepeatItem** type must be passed so that the component can listen for data changes. If only **RepeatItem.item** or **RepeatItem.index** is passed, UI rendering exceptions occur.
- Currently, the template applies to scenarios where **virtualScroll** is enabled. If multiple template types are the same, **Repeat** overrides old **template()** and only the latest **template()** takes effect.
- If the value of **totalCount** is greater than that of **array.length**, when the parent component container is scrolling, the application should ensure that subsequent data is requested when the list is about to slide to the end of the data source until all data sources are loaded. Otherwise, the scrolling effect is abnormal. For details about the solution, see [The totalCount Value Is Greater Than the Length of Data Source](#the-totalcount-value-is-greater-than-the-length-of-data-source).

## Key Generation Rules

The purpose of **key()** is to allow **Repeat** to identify the details of array changes, including addition, deletion, and location (index) of data.

Suggestions:

- Even if there are duplicate data items (or the data source changes), you must ensure that the key is unique .
- Each time **key()** is executed, the same data item is used as the input, and the output must be consistent.
- Using index in **key()** is allowed, but not recommended. The reason is that the index changes when the data item is moved, that is, the key changes. Therefore, Repeat considers that the data item changes and triggers UI re-rendering, which deteriorates the performance.
- You are advised to convert a simple array to a class object array, add a **readonly id** property, and assign a unique value to it in the constructor.

### Non-virtualScroll

**key()** can be left empty. **Repeat** will generate the default key.

![Repeat-NonVS-KeyGen](./figures/Repeat-NonVS-KeyGen.png)

### virtualScroll

The rule is basically the same as that of non-virtualScroll: **key()** can be left empty.

![Repeat-VS-KeyGen](./figures/Repeat-VS-KeyGen.png)

## Component Generation and Reuse Rules

### non-virtualScroll

All child components are created when **Repeat** is rendered for the first time. The original components are reused when data is updated.

When the **Repeat** component updates data, it compares all keys in the last update with those in the latest update. If the current key is the same as the last one, **Repeat** reuses the child component and updates **RepeatItem.index**.

After **Repeat** compares all duplicate keys and reuses them, if the last key is unique and a new key is generated after this update, a child component needs to be created. In this case, **Repeat** will reuse redundant child components, update the **RepeatItem.item** data source and **RepeatItem.index**, and re-render the UI.

If the number of remaining child components is greater than or equal to the number of newly updated components, the components are fully reused and redundant components are released. If the number of remaining child components is less than the number of newly updated components, **Repeat** will create components corresponding to the extra data items after the remaining data items are all reused.

![Repeat-NonVS-FuncGen](./figures/Repeat-NonVS-FuncGen.png)

### virtualScroll

At the first time when **Repeat** renders child components, only the required component is generated. During sliding and data update, nodes on the lower screen are cached. When a new component needs to be generated, the cached component is reused.

#### Slide shortcut

The following figure describes the node state before sliding.

![Repeat-Start](./figures/Repeat-Start.PNG)

Currently, the **Repeat** component has two types of templateId. **templateId a** sets three as its maximum cache value for the corresponding cache pool. **templateId b** sets four as its maximum cache value and preloads one note for its parent components by default. Now swipe right on the screen, and **Repeat** will reuse the nodes in the cache pool.

![Repeat-Slide](./figures/Repeat-Slide.PNG)

The data of **index=18** enters the screen and the preloading range of the parent component, coming up with a result of **templateId b**. In this case, **Repeat** obtains a node from the **type=b** cache pool for reuse and updates its key, index, and data. Other grandchildren notes that use the data and index in the child node are updated based on the state management V2 rules.

The **index=10** note slides out of the screen and the preloading range of the parent component. When the UI main thread is idle, it checks whether the **type=a** cache pool has sufficient space. In this case, there are four nodes in the cache pool, which exceeds the rated three, so **Repeat** will release the last node.

![Repeat-Slide-Done](./figures/Repeat-Slide-Done.PNG)

#### Data Update Scenarios

![Repeat-Start](./figures/Repeat-Start.PNG)

In this case, delete the **index=12** node, update the data of the **index=13** node, change the **templateId b** to **templateId a** of the **index=14** node, and update the key of the **index=15** node.

![Repeat-Update1](./figures/Repeat-Update1.PNG)

Now, **Repeat** notifies the parent component to re-lay out the nodes and compares the keys one by one. If the template ID of the node is the same as that of the original one, the note is reused to update the **key**, **index** and **data**. Otherwise, the node in the cache pool with the same template ID is reused to update the **key**, **index**, and **data**.

![Repeat-Update2](./figures/Repeat-Update2.PNG)

As shown in the preceding figure, node13 updates **data** and **index**; node14 updates the template ID and **index** and reuses a node from the cache pool; node15 reuses its own node and updates the **key**, **index**, and **data** synchronously because of the changed **key** and the unchanged template ID; node 16 and node 17 only update the **index**. The **index=17** node is new and reused from the cache pool.

![Repeat-Update-Done](./figures/Repeat-Update-Done.PNG)

## totalCount

Total length of the data source, which can be greater than the number of loaded data items. Define the data source length as **arr.length**. The processing rules of **totalCount** are as follows:

- When **totalCount** is set to the default value or a non-natural number, the value of **totalCount** is **arr.length**, and the list scrolls normally.
- When **0** <= **totalCount** < **arr.length**, only **totalCount** list items are rendered.
- When **totalCount** is greater than **arr.length**, Repeat renders **totalCount** list items, and the scroll bar style changes based on the value of **totalCount**.

> **Note**<br>If **totalCount** is smaller than **arr.length**, when the parent component container is scrolling, the application needs to ensure that subsequent data is requested when the list is about to slide to the end of the data source. You need to fix the data request error (caused by, for example, network delay) until all data sources are loaded. Otherwise, the scrolling effect is abnormal.

## cachedCount

**cachedCount** indicates the maximum number of subnodes that can be cached in the **Repeat** cache pool of the current template. This parameter is valid only when **virtualScroll** is enabled.

You need to understand the differences between **.cachedCount()** of the scrolling container component and **cachedCount()** of **Repeat**. Both are used to balance performance and memory, but their definitions are different.

- **.cachedCount()** indicates the nodes that are located in the component tree and treated as invisible. Container components such as **List** or **Grid** render these nodes to achieve better performance. But **Repeat** treats these nodes as visible.
- **cachedCount()** of **Repeat** indicates the nodes that are treated as invisible by **Repeat**. These nodes are idle and are temporarily stored in the framework. You can update these nodes as required to implement reuse.

When **cachedCount** is set to the maximum number of nodes that may appear on the screen of the current template, **Repeat** can be reused as much as possible. However, when there is no node of the current template on the screen, the cache pool is not released and the application memory increases. You need to set the configuration based on the actual situation.

- If the default value is used, the framework calculates the value of **cachedCount** for each template based on the number of nodes displayed on the screen and the number of preloaded nodes. If the number increases, the value of **cachedCount** increases accordingly. Note that the value of cachedCount does not decrease.
- Explicitly specify **cachedCount**. It is recommended that the value be the same as the number of nodes on the screen. Yet, setting **cachedCount** to less than 2 is not advised. Doing so may lead to the creation of new nodes during rapid scrolling, which could result in performance degradation.

## Use Scenarios

### Non-virtualScroll

#### Changing the Data Source

```ts
@Entry
@ComponentV2
struct Parent {
  @Local simpleList: Array<string> = ['one', 'two', 'three'];

  build() {
    Row() {
      Column() {
        Text('Click to change the value of the third array item')
          .fontSize(24)
          .fontColor(Color.Red)
          .onClick(() => {
            this.simpleList[2] = 'new three';
          })

        Repeat<string>(this.simpleList)
            .each((obj: RepeatItem<string>)=>{
              ChildItem({ item: obj.item })
                .margin({top: 20})
            })
            .key((item: string) => item)
      }
      .justifyContent(FlexAlign.Center)
      .width('100%')
      .height('100%')
    }
    .height('100%')
    .backgroundColor(0xF1F3F5)
  }
}

@ComponentV2
struct ChildItem {
  @Param @Require item: string;

  build() {
    Text(this.item)
      .fontSize(30)
  }
}
```

![ForEach-Non-Initial-Render-Case-Effect](./figures/ForEach-Non-Initial-Render-Case-Effect.gif)

The component of the third array item is reused when the array item is re-rendered, and only the data is refreshed.

#### Changing the Index Value

In the following example, when array items 1 and 2 are exchanged, if the key is as the same as the last one, **Repeat** reuses the previous component and updates only the data of the component that uses the **index** value.

```ts
@Entry
@ComponentV2
struct Parent {
  @Local simpleList: Array<string> = ['one', 'two', 'three'];

  build() {
    Row() {
      Column() {
        Text ('Exchange array items 1 and 2')
          .fontSize(24)
          .fontColor(Color.Red)
          .onClick(() => {
            let temp: string = this.simpleList[2]
            this.simpleList[2] = this.simpleList[1]
            this.simpleList[1] = temp
          })
          .margin({bottom: 20})

        Repeat<string>(this.simpleList)
          .each((obj: RepeatItem<string>)=>{
            Text("index: " + obj.index)
              .fontSize(30)
            ChildItem({ item: obj.item })
              .margin({bottom: 20})
          })
          .key((item: string) => item)
      }
      .justifyContent(FlexAlign.Center)
      .width('100%')
      .height('100%')
    }
    .height('100%')
    .backgroundColor(0xF1F3F5)
  }
}

@ComponentV2
struct ChildItem {
  @Param @Require item: string;

  build() {
    Text(this.item)
      .fontSize(30)
  }
}
```

![Repeat-Non-Initial-Render-Case-Exchange-Effect](./figures/Repeat-Non-Initial-Render-Case-Exchange-Effect.gif)

### VirtualScroll

This section describes the actual application scenarios of **Repeat** and the reuse of component nodes in the **virtualScroll** scenario. A large number of test scenarios can be derived based on reuse rules. This section only describes typical data changes.

#### One template

The following code designs typical data source operations in the **virtualScroll** scenario of the **Repeat** component, including **inserting, modifying, deleting, and exchanging data**. Select an index value from the drop-down list and click the corresponding button to change the data. You can click two data items in sequence to exchange them.

```ts
@ObservedV2
class Repeat005Clazz {
  @Trace message: string = '';

  constructor(message: string) {
    this.message = message;
  }
}

@Entry
@ComponentV2
struct RepeatVirtualScroll {
  @Local simpleList: Array<Repeat005Clazz> = [];
  private exchange: number[] = [];
  private counter: number = 0;
  @Local selectOptions: SelectOption[] = [];
  @Local selectIdx: number = 0;

  @Monitor("simpleList")
  reloadSelectOptions(): void {
    this.selectOptions = [];
    for (let i = 0; i < this.simpleList.length; ++i) {
      this.selectOptions.push({ value: i.toString() });
    }
    if (this.selectIdx >= this.simpleList.length) {
      this.selectIdx = this.simpleList.length - 1;
    }
  }

  aboutToAppear(): void {
    for (let i = 0; i < 100; i++) {
      this.simpleList.push(new Repeat005Clazz(`item_${i}`));
    }
    this.reloadSelectOptions();
  }

  handleExchange(idx: number): void { // Click to exchange child components.
    this.exchange.push(idx);
    if (this.exchange.length === 2) {
      let _a = this.exchange[0];
      let _b = this.exchange[1];
      let temp: Repeat005Clazz = this.simpleList[_a];
      this.simpleList[_a] = this.simpleList[_b];
      this.simpleList[_b] = temp;
      this.exchange = [];
    }
  }

  build() {
    Column({ space: 10 }) {
      Text('virtualScroll each()&template() 1t')
        .fontSize(15)
        .fontColor(Color.Gray)
      Text('Select an index and press the button to update data.')
        .fontSize(15)
        .fontColor(Color.Gray)

      Select(this.selectOptions)
        .selected(this.selectIdx)
        .value(this.selectIdx.toString())
        .key('selectIdx')
        .onSelect((index: number) => {
          this.selectIdx = index;
        })
      Row({ space: 5 }) {
        Button('Add No.' + this.selectIdx)
          .onClick(() => {
            this.simpleList.splice(this.selectIdx, 0, new Repeat005Clazz(`${this.counter++}_add_item`));
            this.reloadSelectOptions();
          })
        Button('Modify No.' + this.selectIdx)
          .onClick(() => {
            this.simpleList.splice(this.selectIdx, 1, new Repeat005Clazz(`${this.counter++}_modify_item`));
          })
        Button('Del No.' + this.selectIdx)
          .onClick(() => {
            this.simpleList.splice(this.selectIdx, 1);
            this.reloadSelectOptions();
          })
      }
      Button('Update array length to 5.')
        .onClick(() => {
          this.simpleList = this.simpleList.slice(0, 5);
          this.reloadSelectOptions();
        })

      Text('Click on two items to exchange.')
        .fontSize(15)
        .fontColor(Color.Gray)

      List({ space: 10 }) {
        Repeat<Repeat005Clazz>(this.simpleList)
          .each((obj: RepeatItem<Repeat005Clazz>) => {
            ListItem() {
              Text(`[each] index${obj.index}: ${obj.item.message}`)
                .fontSize(25)
                .onClick(() => {
                  this.handleExchange(obj.index);
                })
            }
          })
          .key((item: Repeat005Clazz, index: number) => {
            return item.message;
          })
          .virtualScroll({ totalCount: this.simpleList.length })
          .templateId(() => "a")
          .template('a', (ri) => {
            Text(`[a] index${ri.index}: ${ri.item.message}`)
              .fontSize(25)
              .onClick(() => {
                this.handleExchange(ri.index);
              })
          }, { cachedCount: 3 })
      }
      .cachedCount(2)
      .border({ width: 1 })
      .width('95%')
      .height('40%')
    }
    .justifyContent(FlexAlign.Center)
    .width('100%')
    .height('100%')
  }
}
```
The application list contains 100 **message** properties of the custom class **RepeatClazz**. The value of **cachedCount** of the **List** component is set to **2**, and the cache pool size of the template A is set to **3**. The application screen is shown as bellow.

![Repeat-VirtualScroll-Demo](./figures/Repeat-VirtualScroll-Demo.gif)

#### Multiple templates

```
@ObservedV2
class Repeat006Clazz {
  @Trace message: string = '';

  constructor(message: string) {
    this.message = message;
  }
}

@Entry
@ComponentV2
struct RepeatVirtualScroll2T {
  @Local simpleList: Array<Repeat006Clazz> = [];
  private exchange: number[] = [];
  private counter: number = 0;
  @Local selectOptions: SelectOption[] = [];
  @Local selectIdx: number = 0;

  @Monitor("simpleList")
  reloadSelectOptions(): void {
    this.selectOptions = [];
    for (let i = 0; i < this.simpleList.length; ++i) {
      this.selectOptions.push({ value: i.toString() });
    }
    if (this.selectIdx >= this.simpleList.length) {
      this.selectIdx = this.simpleList.length - 1;
    }
  }

  aboutToAppear(): void {
    for (let i = 0; i < 100; i++) {
      this.simpleList.push(new Repeat006Clazz(`item_${i}`));
    }
    this.reloadSelectOptions();
  }

  handleExchange(idx: number): void { // Click to exchange child components.
    this.exchange.push(idx);
    if (this.exchange.length === 2) {
      let _a = this.exchange[0];
      let _b = this.exchange[1];
      let temp: Repeat006Clazz = this.simpleList[_a];
      this.simpleList[_a] = this.simpleList[_b];
      this.simpleList[_b] = temp;
      this.exchange = [];
    }
  }

  build() {
    Column({ space: 10 }) {
      Text('virtualScroll each()&template() 2t')
        .fontSize(15)
        .fontColor(Color.Gray)
      Text('Select an index and press the button to update data.')
        .fontSize(15)
        .fontColor(Color.Gray)

      Select(this.selectOptions)
        .selected(this.selectIdx)
        .value(this.selectIdx.toString())
        .key('selectIdx')
        .onSelect((index: number) => {
          this.selectIdx = index;
        })
      Row({ space: 5 }) {
        Button('Add No.' + this.selectIdx)
          .onClick(() => {
            this.simpleList.splice(this.selectIdx, 0, new Repeat006Clazz(`${this.counter++}_add_item`));
            this.reloadSelectOptions();
          })
        Button('Modify No.' + this.selectIdx)
          .onClick(() => {
            this.simpleList.splice(this.selectIdx, 1, new Repeat006Clazz(`${this.counter++}_modify_item`));
          })
        Button('Del No.' + this.selectIdx)
          .onClick(() => {
            this.simpleList.splice(this.selectIdx, 1);
            this.reloadSelectOptions();
          })
      }
      Button('Update array length to 5.')
        .onClick(() => {
          this.simpleList = this.simpleList.slice(0, 5);
          this.reloadSelectOptions();
        })

      Text('Click on two items to exchange.')
        .fontSize(15)
        .fontColor(Color.Gray)

      List({ space: 10 }) {
        Repeat<Repeat006Clazz>(this.simpleList)
          .each((obj: RepeatItem<Repeat006Clazz>) => {
            ListItem() {
              Text(`[each] index${obj.index}: ${obj.item.message}`)
                .fontSize(25)
                .onClick(() => {
                  this.handleExchange(obj.index);
                })
            }
          })
          .key((item: Repeat006Clazz, index: number) => {
            return item.message;
          })
          .virtualScroll({ totalCount: this.simpleList.length })
          .templateId((item: Repeat006Clazz, index: number) => {
            return (index % 2 === 0) ? 'odd' : 'even';
          })
          .template('odd', (ri) => {
            Text(`[odd] index${ri.index}: ${ri.item.message}`)
              .fontSize(25)
              .fontColor(Color.Blue)
              .onClick(() => {
                this.handleExchange(ri.index);
              })
          }, { cachedCount: 3 })
          .template('even', (ri) => {
            Text(`[even] index${ri.index}: ${ri.item.message}`)
              .fontSize(25)
              .fontColor(Color.Green)
              .onClick(() => {
                this.handleExchange(ri.index);
              })
          }, { cachedCount: 1 })
      }
      .cachedCount(2)
      .border({ width: 1 })
      .width('95%')
      .height('40%')
    }
    .justifyContent(FlexAlign.Center)
    .width('100%')
    .height('100%')
  }
}
```

![Repeat-VirtualScroll-2T-Demo](./figures/Repeat-VirtualScroll-2T-Demo.gif)

### Using Repeat in a Nesting Manner

 Example:

```ts
// Repeat can be nested in other components.
@Entry
@ComponentV2
struct RepeatNest {
  @Local outerList: string[] = [];
  @Local innerList: number[] = [];

  aboutToAppear(): void {
    for (let i = 0; i < 20; i++) {
      this.outerList.push(i.toString());
      this.innerList.push(i);
    }
  }

  build() {
    Column({ space: 20 }) {
      Text('Using Repeat virtualScroll in a Nesting Manner')
        .fontSize(15)
        .fontColor(Color.Gray)
      List() {
        Repeat<string>(this.outerList)
          .each((obj) => {
            ListItem() {
              Column() {
                Text('outerList item: ' + obj.item)
                  .fontSize(30)
                List() {
                  Repeat<number>(this.innerList)
                    .each((subObj) => {
                      ListItem() {
                        Text('innerList item: ' + subObj.item)
                          .fontSize(20)
                      }
                    })
                    .key((item) => "innerList_" + item)
                }
                .width('80%')
                .border({ width: 1 })
                .backgroundColor(Color.Orange)
              }
              .height('30%')
              .backgroundColor(Color.Pink)
            }
            .border({ width: 1 })
          })
          .key((item) => "outerList_" + item)
      }
      .width('80%')
      .border({ width: 1 })
    }
    .justifyContent(FlexAlign.Center)
    .width('90%')
    .height('80%')
  }
}
```

The figure below shows the effect.

![Repeat-Nest](./figures/Repeat-Nest.png)

## FAQs

### Ensure that the Position of the Scrollbar Remains Unchanged When the List Data Outside the Screen Changes

Declare the **Repeat** component in the **List** component to implement the **key** generation logic and **each** logic (as shown in the following sample code). Click **insert** to insert an element before the first element displayed on the screen, enabling the screen to scroll down.

```ts
// Define a class and mark it as observable.
// Customize an array in the class and mark it as traceable.
@ObservedV2
class ArrayHolder {
  @Trace arr: Array<number> = [];

  // constructor, used to initialize arrays.
  constructor(count: number) {
    for (let i = 0; i < count; i++) {
      this.arr.push(i);
    }
  }
}

@Entry
@ComponentV2
export struct RepeatTemplateSingle {
  @Local arrayHolder: ArrayHolder = new ArrayHolder(100);
  @Local totalCount: number = this.arrayHolder.arr.length;
  scroller: Scroller = new Scroller();

  build() {
    Column({ space: 5 }) {
      List({ space: 20, initialIndex: 19, scroller: this.scroller }) {
        Repeat(this.arrayHolder.arr)
          .virtualScroll({ totalCount: this.totalCount })
          .templateId((item, index) => {
            return 'number';
          })
          .template('number', (r) => {
            ListItem() {
              Text(r.index! + ":" + r.item + "Reuse");
            }
          })
          .each((r) => {
            ListItem() {
              Text(r.index! + ":" + r.item + "eachMessage");
            }
          })
      }
      .height('30%')

      Button(`insert totalCount ${this.totalCount}`)
        .height(60)
        .onClick(() => {
          // Insert an element which locates in the previous position displayed on the screen.
          this.arrayHolder.arr.splice(18, 0, this.totalCount);
          this.totalCount = this.arrayHolder.arr.length;
        })
    }
    .width('100%')
    .margin({ top: 5 })
  }
}
```

The figure below shows the effect.

![Repeat-case1-Error](./figures/Repeat-Case1-Error.gif)

In some scenarios, if you do not want the data source change outside the screen to affect the position where the **Scroller** of the **List** stays on the screen, you can use the [onScrollIndex](https://gitee.com/openharmony/docs/blob/master/en/application-dev/ui/arkts-layout-development-create-list.md#responding-to-the-scrolling-position) of the **List** component to listen for the scrolling action. When the list scrolls, you can obtain the scrolling position of a list. Use the [scrollToIndex](https://gitee.com/openharmony/docs/blob/master/en/application-dev/reference/apis-arkui/arkui-ts/ts-container-scroll.md#scrolltoindex) feature of the **Scroller** component to slide to the specified **index** position. In this way, when data is added to or deleted from the data source outside the screen, the position where the **Scroller** stays remains unchanged.

The following code shows the case of adding data to the data source.

```ts
// The definition of ArrayHolder is the same as that in the demo code.

@Entry
@ComponentV2
export struct RepeatTemplateSingle {
  @Local arrayHolder: ArrayHolder = new ArrayHolder(100);
  @Local totalCount: number = this.arrayHolder.arr.length;
  scroller: Scroller = new Scroller();

  private start: number = 1;
  private end: number = 1;

  build() {
    Column({ space: 5 }) {
      List({ space: 20, initialIndex: 19, scroller: this.scroller }) {
        Repeat(this.arrayHolder.arr)
          .virtualScroll({ totalCount: this.totalCount })
          .templateId((item, index) => {
            return 'number';
          })
          .template('number', (r) => {
            ListItem() {
              Text(r.index! + ":" + r.item + "Reuse");
            }
          })
          .each((r) => {
            ListItem() {
              Text(r.index! + ":" + r.item + "eachMessage");
            }
          })
      }
      .onScrollIndex((start, end) => {
        this.start = start;
        this.end = end;
      })
      .height('30%')

      Button(`insert totalCount ${this.totalCount}`)
        .height(60)
        .onClick(() => {
          // Insert an element which locates in the previous position displayed on the screen.
          this.arrayHolder.arr.splice(18, 0, this.totalCount);
          let rect = this.scroller.getItemRect(this.start); // Obtain the size and position of the child component.
          this.scroller.scrollToIndex(this.start + 1); // Slide to the specified index.
          this.scroller.scrollBy(0, -rect.y); // Slide by a specified distance.
          this.totalCount = this.arrayHolder.arr.length;
        })
    }
    .width('100%')
    .margin({ top: 5 })
  }
}
```

The figure below shows the effect.

![Repeat-case1-Succ](./figures/Repeat-Case1-Succ.gif)

### The totalCount Value Is Greater Than the Length of Data Source

When the total length of the data source is large, the lazy loading is used to load some data first. To enable **Repeat** to display the correct scrollbar style, you need to change the value of **totalCount** to the total length of data. That is, before all data sources are loaded, the value of **totalCount** is greater than that of **array.length**.

If **totalCount** is larger than **array.length**, when the parent component container is scrolling, the application needs to ensure that subsequent data is requested when the list is about to slide to the end of the data source. You need to fix the data request error (caused by, for example, network delay) until all data sources are loaded. Otherwise, the scrolling effect is abnormal.

You can use the callback of [onScrollIndex](https://gitee.com/openharmony/docs/blob/master/en/application-dev/ui/arkts-layout-development-create-list.md#controlling-the-scrolling-position) attribute of the **List** or **Grid** parent component to implement the preceding specification. The sample code is as follows:

```ts
@ObservedV2
class VehicleData {
  @Trace name: string;
  @Trace price: number;

  constructor(name: string, price: number) {
    this.name = name;
    this.price = price;
  }
}

@ObservedV2
class VehicleDB {
  public vehicleItems: VehicleData[] = [];

  constructor() {
    // init data size 20
    for (let i = 1; i <= 20; i++) {
      this.vehicleItems.push(new VehicleData(`Vehicle${i}`, i));
    }
  }
}

@Entry
@ComponentV2
struct entryCompSucc {
  @Local vehicleItems: VehicleData[] = new VehicleDB().vehicleItems;
  @Local listChildrenSize: ChildrenMainSize = new ChildrenMainSize(60);
  @Local totalCount: number = this.vehicleItems.length;
  scroller: Scroller = new Scroller();

  build() {
    Column({ space: 3 }) {
      List({ scroller: this.scroller }) {
        Repeat(this.vehicleItems)
          .virtualScroll({ totalCount: 50 }) // total data size 50
          .templateId(() => 'default')
          .template('default', (ri) => {
            ListItem() {
              Column() {
                Text(`${ri.item.name} + ${ri.index}`)
                  .width('90%')
                  .height(this.listChildrenSize.childDefaultSize)
                  .backgroundColor(0xFFA07A)
                  .textAlign(TextAlign.Center)
                  .fontSize(20)
                  .fontWeight(FontWeight.Bold)
              }
            }.border({ width: 1 })
          }, { cachedCount: 5 })
          .each((ri) => {
            ListItem() {
              Text("Wrong: " + `${ri.item.name} + ${ri.index}`)
                .width('90%')
                .height(this.listChildrenSize.childDefaultSize)
                .backgroundColor(0xFFA07A)
                .textAlign(TextAlign.Center)
                .fontSize(20)
                .fontWeight(FontWeight.Bold)
            }.border({ width: 1 })
          })
          .key((item, index) => `${index}:${item}`)
      }
      .height('50%')
      .margin({ top: 20 })
      .childrenMainSize(this.listChildrenSize)
      .alignListItem(ListItemAlign.Center)
      .onScrollIndex((start, end) => {
        console.log('onScrollIndex', start, end);
        // lazy data loading
        if (this.vehicleItems.length < 50) {
          for (let i = 0; i < 10; i++) {
            if (this.vehicleItems.length < 50) {
              this.vehicleItems.push(new VehicleData("Vehicle_loaded", i));
            }
          }
        }
      })
    }
  }
}
```

The figure below shows the effect.

![Repeat-Case2-Succ](./figures/Repeat-Case2-Succ.gif)

### Constraints on the Mixed Use of Repeat and @Builder

When **Repeat** and \@Builder are used together, parameters of the **RepeatItem** type must be passed so that the component can listen for data changes. If only **RepeatItem.item** or **RepeatItem.index** is passed, UI rendering exceptions occur.

The sample code is as follows:

```ts
@Entry
@ComponentV2
struct RepeatBuilderPage {
  @Local simpleList1: Array<number> = [];
  @Local simpleList2: Array<number> = [];

  aboutToAppear(): void {
    for (let i = 0; i < 100; i++) {
      this.simpleList1.push(i)
      this.simpleList2.push(i)
    }
  }

  build() {
    Column({ space: 20 }) {
      Text('Use Repeat and @Builder together: The abnormal display is on the left, and the normal display is on the right.')
        .fontSize(15)
        .fontColor(Color.Gray)

      Row({ space: 20 }) {
        List({ initialIndex: 5, space: 20 }) {
          Repeat<number>(this.simpleList1)
            .each((ri) => {})
            .virtualScroll({ totalCount: this.simpleList1.length })
            .templateId((item: number, index: number) => "default")
            .template('default', (ri) => {
              ListItem() {
                Column() {
                  Text('Text id = ' + ri.item)
                    .fontSize(20)
                  this.buildItem1 (ri.item) // Change to this.buildItem1(ri).
                }
              }
              .border({ width: 1 })
            }, { cachedCount: 3 })
        }
        .cachedCount(1)
        .border({ width: 1 })
        .width('45%')
        .height('60%')

        List({ initialIndex: 5, space: 20 }) {
          Repeat<number>(this.simpleList2)
            .each((ri) => {})
            .virtualScroll({ totalCount: this.simpleList2.length })
            .templateId((item: number, index: number) => "default")
            .template('default', (ri) => {
              ListItem() {
                Column() {
                  Text('Text id = ' + ri.item)
                    .fontSize(20)
                  this.buildItem2(ri)
                }
              }
              .border({ width: 1 })
            }, { cachedCount: 3 })
        }
        .cachedCount(1)
        .border({ width: 1 })
        .width('45%')
        .height('60%')
      }
    }
    .height('100%')
    .justifyContent(FlexAlign.Center)
  }

  @Builder
  // The @Builder parameter must be of the RepeatItem type for normal rendering.
  buildItem1(item: number) {
    Text('Builder1 id = ' + item)
      .fontSize(20)
      .fontColor(Color.Red)
      .margin({ top: 2 })
  }

  @Builder
  buildItem2(ri: RepeatItem<number>) {
    Text('Builder2 id = ' + ri.item)
      .fontSize(20)
      .fontColor(Color.Red)
      .margin({ top: 2 })
  }
}
```

The following figure shows the display effect. Swipe down the list and you can see the difference.The incorrect usage is on the left, and the correct usage is on the right. (The **Text** component is in black and the **Builder** component is in red). The preceding code shows the error-prone scenario during development. That is, only the value, instead the entire **RepeatItem** class, is passed in the @Builder function.

![Repeat-Builder](./figures/Repeat-Builder.png)
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: Repeat-NonVS-KeyGen.png
###Image description: The image is a flowchart that outlines a process for handling keys in a JSON object. The flowchart starts at the top with a "Start" node and proceeds through a series of decision points and actions until it reaches an "End" node at the bottom. Here is a detailed description of the flowchart:

1. **Start**: The process begins at the top with a "Start" node.
2. **Is key() customized?**: The first decision point asks whether the key() function has been customized. If the answer is "No," the process moves to the next step. If the answer is "Yes," the process moves to the "Use the custom key()" step.
3. **Is the data of the object/symbol type?**: The next decision point checks if the data type of the object or symbol is relevant. If the answer is "No," the process moves to the "Concatenate JSON.stringify(item) with index" step. If the answer is "Yes," the process moves to the "Assign an auto-increment value to each item and concatenate it with index" step.
4. **Concatenate JSON.stringify(item) with index**: This step involves concatenating the JSON stringified version of the item with its index.
5. **Are keys duplicate?**: The final decision point checks if the keys are duplicate. If the answer is "Yes," the process ends. If the answer is "No," the process moves back to the "Start" node to repeat the process.

### Analysis and Description

The flowchart is designed to handle the creation and management of keys in a JSON object, ensuring that keys are unique and properly formatted. Here’s a breakdown of the steps:

1. **Customization Check**: The first step checks if the key() function has been customized. Customization might involve using a specific method or logic to generate keys, which could be necessary for certain applications or requirements.

2. **Data Type Check**: The next step checks if the data type of the object or symbol is relevant. This is important because different data types might require different handling or formatting of keys.

3. **Auto-Increment or Stringification**: Based on the previous steps, the process either assigns an auto-increment value to each item and concatenates it with the index or concatenates the JSON stringified version of the item with its index. This step ensures that keys are unique and follow a specific format.

4. **Duplicate Key Check**: Finally, the process checks if the keys are duplicate. If they are, the process ends, indicating that the keys are already unique and no further action is needed. If the keys are not duplicate, the process repeats from the start, ensuring that the entire process is executed again to maintain the uniqueness of keys.

### Conclusion

This flowchart provides a structured approach to handling keys in a JSON object, ensuring that keys are unique and properly formatted. The decision points and actions are designed to accommodate different scenarios, such as custom key generation and handling of different data types. The process repeats until all keys are unique, ensuring the integrity and usability of the JSON object.
##Image Name: Repeat-VS-KeyGen.png
###Image description: The image is a flowchart that outlines a process for generating unique keys for items in a list. The flowchart starts at the top with a "Start" node and proceeds through a series of decision points and actions until it reaches an "End" node. Here is a detailed description of each step in the flowchart:

1. **Start**: The process begins at the top with a "Start" node.
2. **Is key() customized?**: The first decision point asks whether the key() function is customized. If the answer is "Yes," the process moves to the next step. If the answer is "No," the process continues to the next decision point.
3. **Is the data of the object/symbol type?**: The next decision point checks if the data type of the object or symbol is relevant. If it is, the process moves to the next step. If it is not, the process continues to the next decision point.
4. **Assign an auto-increment value to each item and concatenate it with index**: If the data type is relevant, the process assigns an auto-increment value to each item and concatenates it with the index.
5. **Concatenate JSON.stringify(item) with index**: If the data type is not relevant, the process concatenates the JSON.stringify() of the item with the index.
6. **Are keys duplicate?**: The next decision point checks if the generated keys are duplicates. If they are not, the process moves to the next step. If they are, the process continues to the next decision point.
7. **Concatenate the generated key, index, and Math.random()**: If the keys are not duplicates, the process concatenates the generated key, index, and Math.random() to ensure uniqueness.
8. **End**: The process concludes at the "End" node.

The flowchart uses standard symbols for decision points (diamonds) and actions (rectangles). The arrows indicate the flow of the process, directing the user to the next step based on the outcome of each decision.

### Analysis:
The flowchart is designed to ensure that keys generated for items in a list are unique. It handles different scenarios based on whether the key() function is customized and the data type of the items. By concatenating the item's JSON string with the index and possibly a random number, it aims to create a unique identifier for each item, which can be crucial in scenarios where data integrity and uniqueness are paramount, such as in databases or when generating identifiers for objects in a system.

### Conclusion:
This flowchart provides a clear and structured approach to generating unique keys for items in a list, ensuring that the process is systematic and can handle various data types and customization requirements.
##Image Name: Repeat-NonVS-FuncGen.png
###Image description: The image is a flowchart that outlines a process for handling rendering in a non-VS (Virtual Scroll) context. The flowchart is structured with decision points and actions, leading to different outcomes based on the conditions met. Here is a detailed description of the flowchart:

1. **Initial Rendering**:
   - **Action**: Create all nodes.
   - **Description**: This step is executed during the initial rendering of the component or page. All nodes are created at this stage.

2. **Non-Initial Rendering**:
   - **Action**: Compare the keys before and after rendering.
   - **Description**: This step checks whether the keys of the nodes have changed between the initial rendering and the subsequent non-initial renderings.

3. **Decision Point**:
   - **Condition**: Are keys duplicate?
   - **Flow**:
     - **Yes**: Reuse child component and update index.
     - **No**: Create a node.

4. **Decision Point**:
   - **Condition**: Are there existing keys that are not duplicate?
   - **Flow**:
     - **Yes**: Reuse existing nodes.
     - **No**: Create a node.

### Detailed Breakdown:

1. **Initial Rendering**:
   - This step is executed once during the initial rendering of the component. It involves creating all the nodes required for the initial display.

2. **Non-Initial Rendering**:
   - This step is executed for subsequent renderings after the initial one. It involves comparing the keys of the nodes before and after the rendering process.

3. **Duplicate Keys Check**:
   - If the keys before and after rendering are found to be duplicates, the flow proceeds to the next step.
   - If the keys are not duplicates, a new node is created.

4. **Non-Duplicate Keys Check**:
   - If there are existing keys that are not duplicates, the flow proceeds to reuse the existing nodes.
   - If there are no existing keys that are not duplicates, a new node is created.

### Analysis:

The flowchart is designed to optimize rendering by reusing existing nodes when possible, which can significantly reduce the computational overhead associated with creating new nodes. This approach is particularly useful in scenarios where the number of nodes is large, such as in virtual scrolling applications where the number of visible items changes dynamically.

### Conclusion:

The flowchart provides a clear and structured approach to handling rendering in a non-VS context, ensuring efficient use of resources by reusing existing nodes when keys are not changed and creating new nodes when necessary. This method helps in maintaining performance and reducing the time required for rendering, especially in applications with a large number of nodes.
##Image Name: Repeat-Start.PNG
###Image description: The image appears to be a diagram illustrating the structure and organization of data nodes within a component, likely in the context of a software application or a programming framework. The diagram is divided into two main sections, each explaining different aspects of the data nodes.

### Top Section:
The top section of the diagram shows a sequence of nodes, each with specific attributes. The nodes are arranged in a linear fashion, with each node having a unique identifier (key), a data value, an index, and a type identifier (typeld). The nodes are colored in blue and green, indicating different states or categories.

- **Key**: Each node has a unique key value, which is a numerical identifier.
- **Data**: The data value associated with each node.
- **Index**: The index of the node within the sequence.
- **Typeld**: The type identifier of the node, which could be used to categorize or differentiate between different types of nodes.

### Bottom Section:
The bottom section of the diagram focuses on two specific nodes, labeled as "Repeat cache pool type=a cachedCount=3" and "Repeat cache pool type=b cachedCount=4". These nodes are highlighted in gray and are enclosed within a white frame, indicating they are part of a cache pool.

- **Repeat cache pool type=a cachedCount=3**: This node has a data value of 7, a key of 7, an index of 7, and a typeld of 'a'. It indicates that there are three cached instances of this type of node.
- **Repeat cache pool type=b cachedCount=4**: This node has a data value of 3, a key of 3, an index of 3, and a typeld of 'b'. It indicates that there are four cached instances of this type of node.

### Analysis:
The diagram seems to be illustrating the concept of caching and preloading nodes in a component. The top section shows the nodes that are currently on the screen, while the bottom section highlights the cached nodes that are preloaded for faster access.

- **Preloading**: The preloaded nodes (highlighted in gray) are likely loaded into memory in advance to reduce the time needed to render them on the screen. This is particularly useful in applications where performance is critical, such as mobile applications or games.
- **Cache Pool**: The cache pool is a mechanism for storing frequently accessed nodes. By caching nodes, the application can avoid the overhead of re-creating these nodes every time they are needed, thus improving performance.

### Conclusion:
This diagram effectively demonstrates how nodes are organized and managed within a component, highlighting the importance of caching and preloading in optimizing performance. The use of different colors and labels helps to distinguish between different states and types of nodes, making it easier to understand the structure and functionality of the component.
##Image Name: Repeat-Slide.PNG
###Image description: The image depicts a data structure, specifically a cache pool, which is used to store and manage data efficiently. The cache pool is divided into two main sections: one for type 'a' and another for type 'b'. Each section contains multiple entries, each with a unique key, data, and node index.

### Cache Pool for Type 'a'
- **Key**: 10
- **Data**: 10
- **Index**: 10
- **Node**: 10
- **Type**: a

### Cache Pool for Type 'b'
- **Key**: 7
- **Data**: 7
- **Index**: 7
- **Node**: 7
- **Type**: a
- **Key**: 8
- **Data**: 8
- **Index**: 8
- **Node**: 8
- **Type**: a
- **Key**: 9
- **Data**: 9
- **Index**: 9
- **Node**: 9
- **Type**: a
- **Key**: 3
- **Data**: 3
- **Index**: 3
- **Node**: 3
- **Type**: b
- **Key**: 4
- **Data**: 4
- **Index**: 4
- **Node**: 4
- **Type**: b
- **Key**: 5
- **Data**: 5
- **Index**: 5
- **Node**: 5
- **Type**: b
- **Key**: 6
- **Data**: 6
- **Index**: 6
- **Node**: 6
- **Type**: b

### Key Observations
1. **Reuse**: The image highlights the concept of "reuse" where certain entries are reused for different keys. For example, the entry with key 18 is reused for both type 'a' and type 'b'.
2. **Release**: The image also shows the concept of "release" where certain entries are released back into the pool. For instance, the entry with key 10 is released back into the pool.
3. **Cached Count**: The cached count for type 'a' is 3, and for type 'b' is 4.

### Analysis
The cache pool is designed to optimize memory usage by reusing entries for different keys. This is particularly useful in scenarios where the same data needs to be stored multiple times with different keys. The cached count indicates how many entries of each type are currently in use, helping to manage the pool efficiently.

### Conclusion
The image effectively illustrates the principles of cache pool management, including reuse, release, and cached count, which are crucial for optimizing data storage and retrieval in memory-intensive applications.
##Image Name: Repeat-Slide-Done.PNG
###Image description: The image is a diagram illustrating the structure and organization of data nodes in a caching system, likely related to a user interface or a data management system. The diagram is divided into two main sections: the top section and the bottom section.

### Top Section:
- **Preloaded Node of the Parent Component**: This section contains two nodes, each with the following attributes:
  - `data: 11`
  - `key: 11`
  - `index: 11`
  - `node: 11`
  - `typeld: b`
  - `...` (indicating more nodes are present but not shown)

- **Nodes on the Screen**: This section shows a series of nodes that are displayed on the screen. Each node has the following attributes:
  - `data: 12`
  - `key: 12`
  - `index: 12`
  - `node: 12`
  - `typeld: a`
  - `...` (indicating more nodes are present but not shown)

- **Preloaded Node of the Parent Component**: This section contains two more nodes, each with the following attributes:
  - `data: 18`
  - `key: 18`
  - `index: 18`
  - `node: 18`
  - `typeld: b`
  - `...` (indicating more nodes are present but not shown)

### Bottom Section:
- **Repeat Cache Pool type=a cachedCount=3**: This section contains three nodes, each with the following attributes:
  - `data: 7`
  - `key: 7`
  - `index: 7`
  - `node: 7`
  - `typeld: a`
  - `...` (indicating more nodes are present but not shown)

- **Repeat Cache Pool type=b cachedCount=4**: This section contains four nodes, each with the following attributes:
  - `data: 3`
  - `key: 3`
  - `index: 3`
  - `node: 3`
  - `typeld: b`
  - `...` (indicating more nodes are present but not shown)

### Analysis:
The diagram illustrates how data nodes are preloaded and cached in a system. The preloaded nodes are stored in the parent component's cache, and the nodes on the screen are dynamically loaded based on the current display requirements. The `cachedCount` attribute indicates the number of cached nodes of each type.

- **Preloaded Nodes**: These nodes are loaded into the cache when the component is initialized. They are stored in the parent component's cache and can be reused when needed.
- **Nodes on the Screen**: These nodes are dynamically loaded onto the screen based on the current display requirements. They are loaded from the cache when needed.
- **Repeat Cache Pool**: This section shows how nodes of the same type are cached and reused. The `cachedCount` attribute indicates the number of cached nodes of each type.

### Conclusion:
This diagram provides a clear visualization of how data nodes are preloaded, cached, and dynamically loaded in a system. It helps in understanding the caching mechanism and how it optimizes the loading of data nodes on the screen.
##Image Name: Repeat-Start.PNG
###Image description: The image appears to be a diagram illustrating the structure and organization of data nodes within a component, likely in the context of a software application or a programming framework. The diagram is divided into two main sections, each explaining different aspects of the data nodes.

### Top Section:
The top section of the diagram shows a sequence of nodes, each with specific attributes. The nodes are arranged in a linear fashion, with each node having a unique identifier (key), a data value, an index, and a type identifier (typeld). The nodes are colored in blue and green, indicating different states or categories.

- **Key**: Each node has a unique key value, which is a numerical identifier.
- **Data**: The data value associated with each node.
- **Index**: The index of the node within the sequence.
- **Typeld**: The type identifier of the node, which could be used to categorize or differentiate between different types of nodes.

### Bottom Section:
The bottom section of the diagram focuses on two specific nodes, labeled as "Repeat cache pool type=a cachedCount=3" and "Repeat cache pool type=b cachedCount=4". These nodes are highlighted in gray and are enclosed within a white frame, indicating they are part of a cache pool.

- **Repeat cache pool type=a cachedCount=3**: This node has a data value of 7, a key of 7, an index of 7, and a typeld of 'a'. It indicates that there are three cached instances of this type of node.
- **Repeat cache pool type=b cachedCount=4**: This node has a data value of 3, a key of 3, an index of 3, and a typeld of 'b'. It indicates that there are four cached instances of this type of node.

### Analysis:
The diagram seems to be illustrating the concept of caching and preloading nodes in a component. The top section shows the nodes that are currently on the screen, while the bottom section highlights the cached nodes that are preloaded for faster access.

- **Preloading**: The preloaded nodes (highlighted in gray) are likely loaded into memory in advance to reduce the time needed to render them on the screen. This is particularly useful in applications where performance is critical, such as mobile applications or games.
- **Cache Pool**: The cache pool is a mechanism for storing frequently accessed nodes. By caching nodes, the application can avoid the overhead of re-creating these nodes every time they are needed, thus improving performance.

### Conclusion:
This diagram effectively demonstrates how nodes are organized and managed within a component, highlighting the importance of caching and preloading in optimizing performance. The use of different colors and labels helps to distinguish between different states and types of nodes, making it easier to understand the structure and functionality of the component.
##Image Name: Repeat-Update1.PNG
###Image description: The image appears to be a diagram illustrating the concept of preloading nodes in a parent component and their relationship with cached nodes in a repeat cache pool. Here is a detailed description of the image:

### Top Section:
- **Preloaded Nodes of the Parent Component:**
  - The top section shows a series of nodes that are preloaded into the parent component. These nodes are represented by rectangular boxes with various properties.
  - Each node has the following properties:
    - `data`: This field contains the data associated with the node.
    - `key`: This field is a unique identifier for the node.
    - `index`: This field indicates the index of the node within the parent component.
    - `node`: This field represents the node itself.
    - `typeld`: This field specifies the type of the node.

- **Nodes on the Screen:**
  - The nodes on the screen are highlighted with a red cross, indicating that they are currently being displayed on the screen.
  - The highlighted nodes are:
    - `data: 11`, `key: 11`, `index: 11`, `node: 11`, `typeld: a`
    - `data: 12`, `key: 12`, `index: 12`, `node: 12`, `typeld: b`
    - `data: 13`, `key: 13`, `index: 13`, `node: 13`, `typeld: a`
    - `data: 14`, `key: 14`, `index: 14`, `node: 14`, `typeld: b`
    - `data: 15`, `key: 15`, `index: 15`, `node: 15`, `typeld: a`
    - `data: 16`, `key: 16`, `index: 16`, `node: 16`, `typeld: b`
    - `data: 17`, `key: 17`, `index: 17`, `node: 17`, `typeld: b`

### Bottom Section:
- **Repeat Cache Pool:**
  - The bottom section shows a repeat cache pool with two types of nodes: `a` and `b`.
  - Each type of node has a cached count associated with it.
  - The repeat cache pool contains:
    - **Type `a`:**
      - `data: 7`, `key: 7`, `index: 7`, `node: 7`, `typeld: a`
      - `data: 8`, `key: 8`, `index: 8`, `node: 8`, `typeld: a`
      - `data: 9`, `key: 9`, `index: 9`, `node: 9`, `typeld: a`
    - **Type `b`:**
      - `data: 3`, `key: 3`, `index: 3`, `node: 3`, `typeld: b`
      - `data: 4`, `key: 4`, `index: 4`, `node: 4`, `typeld: b`
      - `data: 5`, `key: 5`, `index: 5`, `node: 5`, `typeld: b`
      - `data: 6`, `key: 6`, `index: 6`, `node: 6`, `typeld: b`

### Analysis:
- The image illustrates how preloaded nodes are used in a parent component and how they are cached in a repeat cache pool.
- The preloaded nodes are initially loaded into the parent component and then displayed on the screen.
- The repeat cache pool stores cached nodes of the same type, allowing for efficient reuse of nodes when they are needed again.
- The cached count indicates how many instances of each type of node are currently cached in the pool.

### Conclusion:
This diagram effectively demonstrates the concept of preloading and caching nodes in a parent component, which is a common practice in user interface development to improve performance by reducing the number of times nodes need to be created and destroyed.
##Image Name: Repeat-Update2.PNG
###Image description: The image depicts a diagram illustrating the structure and organization of nodes in a data structure, likely related to a user interface or a graphical user interface (GUI) component. The diagram is divided into several sections, each representing different components and their relationships.

### Top Section:
- **Preloaded Node of the Parent Component**: This section contains nodes that are preloaded and not currently on the screen.
- **Nodes on the Screen**: These are the nodes that are currently displayed on the screen.
- **Preloaded Node of the Parent Component**: This section contains nodes that are preloaded and not currently on the screen.

### Middle Section:
- **Repeat Cache Pool Type=a cachedCount=3**: This section contains three nodes of type 'a' that are cached and not currently on the screen.
- **Repeat Cache Pool Type=b cachedCount=4**: This section contains four nodes of type 'b' that are cached and not currently on the screen.

### Bottom Section:
- **Nodes on the Screen**: This section contains nodes that are currently displayed on the screen.

### Key Elements:
- **Nodes**: Each node is represented by a box with the following attributes:
  - `data`: The data associated with the node.
  - `key`: The key or identifier for the node.
  - `index`: The index of the node within its parent component.
  - `node`: The node itself.
  - `typeld`: The type of the node.

### Relationships:
- **Preloaded Nodes**: These nodes are preloaded and not currently on the screen. They are stored in the preloaded node sections.
- **Nodes on the Screen**: These nodes are currently displayed on the screen. They are stored in the nodes on the screen section.
- **Cached Nodes**: These nodes are cached and not currently on the screen. They are stored in the repeat cache pools.

### Analysis:
The diagram illustrates a hierarchical structure where nodes are organized and managed efficiently. The preloaded nodes are stored separately from the nodes on the screen to optimize performance and reduce memory usage. The cached nodes are stored in separate pools based on their type, allowing for efficient reuse and management.

### Conclusion:
This diagram is likely used to explain how a GUI component manages its nodes, ensuring that only the necessary nodes are loaded into memory and displayed on the screen. This approach helps in improving the performance and responsiveness of the application by minimizing the memory footprint and reducing the overhead of loading and rendering nodes.
##Image Name: Repeat-Update-Done.PNG
###Image description: The image appears to be a diagram illustrating the structure and organization of data nodes within a component, likely in the context of a software application or a programming framework. The diagram is divided into two main sections, each explaining different aspects of the data nodes.

### Top Section:
The top section of the diagram shows a sequence of nodes, each with specific attributes. The nodes are arranged in a linear fashion, with each node having a unique identifier (key), a data value, an index, and a type identifier (typeld). The nodes are colored in blue, and the data values are displayed in white text. The keys and indices are also shown in white text, while the typelds are in a different color (green).

- **Nodes on the Screen**: These are the nodes that are currently visible on the screen. They are highlighted in blue.
- **Preloaded Nodes of the Parent Component**: These are the nodes that are preloaded but not currently visible on the screen. They are also highlighted in blue.

### Bottom Section:
The bottom section of the diagram shows two separate pools of cached nodes, each with a different type identifier (typeld) and a cached count. The nodes in these pools are represented in gray, and the data values are displayed in white text.

- **Repeat Cache Pool type=a cachedCount=3**: This pool contains three nodes, each with a data value, key, index, and typeld. The nodes are arranged in a linear sequence, and the typeld is labeled as 'a'.
- **Repeat Cache Pool type=b cachedCount=4**: This pool contains four nodes, each with a data value, key, index, and typeld. The nodes are arranged in a linear sequence, and the typeld is labeled as 'b'.

### Explanation:
The diagram seems to be explaining how data nodes are organized and managed within a component. The top section shows the nodes that are currently on the screen, while the bottom section shows the cached nodes that are preloaded but not yet displayed. The cached nodes are organized into separate pools based on their type identifiers, which helps in managing and optimizing the display of data.

### Analysis:
1. **Data Node Structure**: Each node contains a unique key, data value, index, and typeld. This structure allows for efficient retrieval and display of data.
2. **Preloading and Caching**: Preloading nodes ensures that frequently accessed data is available quickly, reducing the need for real-time data retrieval and improving performance.
3. **Type-Based Caching**: Nodes are organized into separate pools based on their typeld, which can help in optimizing memory usage and improving performance by reducing the overhead of switching between different types of data.

### Conclusion:
The diagram effectively illustrates the organization and management of data nodes within a component, highlighting the importance of preloading and caching to optimize performance and efficiency. The use of separate pools based on typelds further enhances this optimization by allowing for more targeted and efficient data management.
##Image Name: Repeat-Nest.png
###Image description: The image depicts a visual representation of a data structure using a nested list format, specifically utilizing a virtual scroll technique. The structure is organized into two main lists: an outer list and an inner list. The outer list is represented by a pink background, while the inner list is represented by an orange background. Each item in the outer list is labeled with "outerList item: X," where X represents the index of the outer list item. The inner list items are labeled with "innerList item: Y," where Y represents the index of the inner list item within its respective outer list item.

Here is a breakdown of the structure:

1. **Outer List:**
   - The outer list has four items, each with a unique index (0, 1, 2, 3).
   - Each outer list item contains an inner list.

2. **Inner List:**
   - Each outer list item contains an inner list with five items, each with a unique index (0, 1, 2, 3, 4, 5).

The visual layout shows the hierarchical structure clearly:
- The outer list items are stacked vertically.
- Each outer list item contains an orange rectangle representing the inner list.
- The inner list items are arranged horizontally within each orange rectangle.

The image also includes a caption at the top that reads, "Using Repeat virtualScroll in a Nesting Manner," indicating that this structure is an example of using a virtual scroll technique to efficiently display nested lists.

### Analysis:
1. **Virtual Scroll:**
   - Virtual scrolling is a technique used in user interfaces to improve performance by only loading and rendering the visible items of a list. This is particularly useful for large datasets where loading all items at once would be impractical or slow.

2. **Nested Lists:**
   - The nested structure suggests that the outer list items are containers for the inner list items. This is common in many applications where data is organized hierarchically, such as file systems, organizational charts, or nested data models.

3. **Performance Implications:**
   - By using virtual scrolling, the application can load and display only the visible items, which can significantly reduce memory usage and improve performance, especially when dealing with large datasets.

### Conclusion:
The image effectively demonstrates how a nested list structure can be efficiently visualized and managed using virtual scrolling. This technique is particularly useful in applications where performance and user experience are critical, such as in mobile applications or large-scale data visualization tools.
##Image Name: Repeat-Builder.png
###Image description: The image presents a comparison between two different display layouts, labeled as "abnormal display" on the left and "normal display" on the right. Both layouts consist of a series of rectangular boxes, each containing text and numerical identifiers. The text within each box is in red, while the numerical identifiers are in black. The identifiers are labeled as "Text id" and "Builder id," with the latter being further divided into "Builder1 id" and "Builder2 id."

### Abnormal Display (Left Side):
1. The first box contains the text "Text id = 12" and the identifiers "Builder1 id = 12" and "Builder2 id = 12."
2. The second box contains the text "Text id = 13" and the identifiers "Builder1 id = 13" and "Builder2 id = 13."
3. The third box contains the text "Text id = 14" and the identifiers "Builder1 id = 4" and "Builder2 id = 14."
4. The fourth box contains the text "Text id = 15" and the identifiers "Builder1 id = 5" and "Builder2 id = 15."
5. The fifth box contains the text "Text id = 16" and the identifiers "Builder1 id = 6" and "Builder2 id = 16."
6. The sixth box contains the text "Text id = 17" and the identifiers "Builder1 id = 7" and "Builder2 id = 17."
7. The seventh box contains the text "Text id = 18" and the identifiers "Builder1 id = 8" and "Builder2 id = 18."

### Normal Display (Right Side):
1. The first box contains the text "Text id = 12" and the identifiers "Builder1 id = 12" and "Builder2 id = 12."
2. The second box contains the text "Text id = 13" and the identifiers "Builder1 id = 13" and "Builder2 id = 13."
3. The third box contains the text "Text id = 14" and the identifiers "Builder1 id = 14" and "Builder2 id = 14."
4. The fourth box contains the text "Text id = 15" and the identifiers "Builder1 id = 15" and "Builder2 id = 15."
5. The fifth box contains the text "Text id = 16" and the identifiers "Builder1 id = 16" and "Builder2 id = 16."
6. The sixth box contains the text "Text id = 17" and the identifiers "Builder1 id = 17" and "Builder2 id = 17."
7. The seventh box contains the text "Text id = 18" and the identifiers "Builder1 id = 18" and "Builder2 id = 18."

### Analysis:
The abnormal display on the left side shows a pattern where the "Builder1 id" and "Builder2 id" values are not consistent with the "Text id" values. For example, the "Builder1 id" for "Text id = 14" is 4, which is not the same as the "Text id" value. This inconsistency is repeated throughout the display.

In contrast, the normal display on the right side shows a consistent pattern where the "Builder1 id" and "Builder2 id" values match the "Text id" values. This consistency suggests that the normal display follows a predefined rule or logic that ensures the identifiers are correctly aligned with the text.

### Conclusion:
The image illustrates the importance of maintaining consistency in data representation, especially when using identifiers like "Builder id" to ensure that the displayed information is accurate and reliable. The abnormal display highlights the need for careful data management and verification to avoid discrepancies and ensure that the data is correctly interpreted by the user.
