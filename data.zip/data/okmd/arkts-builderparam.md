# \@BuilderParam Decorator: @Builder Function Reference


In certain circumstances, you may need to add a specific feature, such as a click-to-jump action, to a custom component. However, embedding an event method directly in a component will add the feature to all places where the component is imported. To solve this problem, ArkUI uses the \@BuilderParam decorator to decorate variables pointing to the [\@Builder](./arkts-builder.md) method (that is, @BuilderParam is used to decorate the @Builder function). When initializing a custom component, you can use different methods (such as modifying parameters, trailing closure, or using arrow function) to change values of the custom builder functions decorated by \@BuilderParam and call the \@BuilderParam in a custom component to add specific features. This decorator can be used to declare an element of any UI description, similar to a slot placeholder.


> **NOTE**
>
> This decorator can be used in ArkTS widgets since API version 9.
>
> This decorator can be used in atomic services since API version 11.


## Rules of Use


### Initializing \@BuilderParam Decorated Methods

An \@BuilderParam decorated method can be initialized only by an \@Builder function reference. If this decorator is used together with [\@Require](arkts-require.md) in API version 11, the parent component must construct input parameters.

- Local initialization with the owning component's custom \@Builder function reference or a global \@Builder function reference

  ```ts
  @Builder function overBuilder() {}

  @Component
  struct Child {
    @Builder doNothingBuilder() {};

    // Use the custom builder function of the custom component for @BuilderParam initialization.
    @BuilderParam customBuilderParam: () => void = this.doNothingBuilder;
    // Use the global custom builder function for @BuilderParam initialization.
    @BuilderParam customOverBuilderParam: () => void = overBuilder;
    build(){}
  }
  ```

- Initialization from the parent component

  ```ts
  @Component
  struct Child {
    @Builder customBuilder() {};
    // Use the @Builder decorated method in the parent component for @BuilderParam initialization.
    @BuilderParam customBuilderParam: () => void = this.customBuilder;

    build() {
      Column() {
        this.customBuilderParam()
      }
    }
  }

  @Entry
  @Component
  struct Parent {
    @Builder componentBuilder() {
      Text(`Parent builder `)
    }

    build() {
      Column() {
        Child({ customBuilderParam: this.componentBuilder })
      }
    }
  }
  ```
  **Figure 1** Example effect

  ![builderparam-demo1](figures/builderparam-demo1.png)


- **this** in the function body must point to the correct object.

Example:

  ```ts
  @Component
  struct Child {
    label: string = `Child`;
    @Builder customBuilder() {};
    @Builder customChangeThisBuilder() {};
    @BuilderParam customBuilderParam: () => void = this.customBuilder;
    @BuilderParam customChangeThisBuilderParam: () => void = this.customChangeThisBuilder;

    build() {
      Column() {
        this.customBuilderParam()
        this.customChangeThisBuilderParam()
      }
    }
  }

  @Entry
  @Component
  struct Parent {
    label: string = `Parent`;

    @Builder componentBuilder() {
      Text(`${this.label}`)
    }

    build() {
      Column() {
        // When this.componentBuilder() is called, this points to the Parent component decorated by the @Entry. That is, the value of the label variable is Parent.
        this.componentBuilder()
        Child({
          // Pass this.componentBuilder to @BuilderParam customBuilderParam of the Child component. this points to the Child, that is, the value of the label variable is Child.
          customBuilderParam: this.componentBuilder,
          // Pass ():void=>{this.componentBuilder()} to @BuilderParam customChangeThisBuilderParam of the Child component.
          // this of the arrow function points to the host object, so the value of the label variable is Parent.
          customChangeThisBuilderParam: (): void => { this.componentBuilder() }
        })
      }
    }
  }
  ```
 **Figure 2** Example effect

 ![builderparam-demo2](figures/builderparam-demo2.png)


## Constraints

- The \@BuilderParam decorated variable receives the \@Builder decorated function from the parent component. In addition, only local \@Builder function can be passed as a parameter.

```ts
@Component
struct Child {
  header: string = '';
  @BuilderParam content: () => void;
  footer: string = '';

  build() {
    Column() {
      Text(this.header)
      this.content();
      Text(this.footer)
    }
  }
}

@Entry
@Component
struct Parent {
  @Builder
  test() {
    Text('Hello')
  }

  build() {
    Column() {
      // Incorrect format. @BuilderParam needs to be initialized.
      Child()
      // Correct format.
      Child({ content: this.test })
    }
  }
}
```

- In the scenario where a custom component trailing closure is used, the child component has only one \@BuilderParam to receive this trailing closure, and the \@BuilderParam cannot contain parameters. For details, see [Component Initialization Through Trailing Closure](#component-initialization-through-trailing-closure).


## Use Scenarios


### Component Initialization Through Parameters

An \@BuilderParam decorated method can be a method with or without parameters. Whether it contains parameters should match that of the assigned \@Builder method. The type of the \@BuilderParam decorated method must also match that of the assigned \@Builder method.

```ts
class Tmp{
  label: string = '';
}

@Builder function overBuilder($$: Tmp) {
  Text($$.label)
    .width(400)
    .height(50)
    .backgroundColor(Color.Green)
}

@Component
struct Child {
  label: string = 'Child';
  @Builder customBuilder() {};
  // Without parameters. The pointed componentBuilder does not carry parameters either.
  @BuilderParam customBuilderParam: () => void = this.customBuilder;
  // With parameters. The pointed overBuilder also carries parameters.
  @BuilderParam customOverBuilderParam: ($$: Tmp) => void = overBuilder;

  build() {
    Column() {
      this.customBuilderParam()
      this.customOverBuilderParam({label: 'global Builder label' } )
    }
  }
}

@Entry
@Component
struct Parent {
  label: string = 'Parent';

  @Builder componentBuilder() {
    Text(`${this.label}`)
  }

  build() {
    Column() {
      this.componentBuilder()
      Child({ customBuilderParam: this.componentBuilder, customOverBuilderParam: overBuilder })
    }
  }
}
```
**Figure 3** Example effect

![builderparam-demo3](figures/builderparam-demo3.png)


### Component Initialization Through Trailing Closure

In a custom component, the \@BuilderParam decorated attribute can be initialized using a trailing closure. During initialization, the component name is followed by a pair of braces ({}) to form a trailing closure.

> **NOTE**
>
>  - In this scenario, the custom component can have only one \@BuilderParam decorated attribute.
> 
>  - In this scenario, custom components do not support universal attributes.

You can pass the content in the trailing closure to \@BuilderParam as an \@Builder decorated method.

Example 1:

```ts
@Component
struct CustomContainer {
  @Prop header: string = '';
  @Builder closerBuilder(){};
  // Use the trailing closure {} (@Builder decorated method) of the parent component for @BuilderParam initialization.
  @BuilderParam closer: () => void = this.closerBuilder;

  build() {
    Column() {
      Text(this.header)
        .fontSize(30)
      this.closer()
    }
  }
}

@Builder function specificParam(label1: string, label2: string) {
  Column() {
    Text(label1)
      .fontSize(30)
    Text(label2)
      .fontSize(30)
  }
}

@Entry
@Component
struct CustomContainerUser {
  @State text: string = 'header';

  build() {
    Column() {
      // Create the CustomContainer component. During initialization, append a pair of braces ({}) to the component name to form a trailing closure.
      // Used as the parameter passed to CustomContainer @BuilderParam closer: () => void.
      CustomContainer({ header: this.text }) {
        Column() {
          specificParam('testA', 'testB')
        }.backgroundColor(Color.Yellow)
        .onClick(() => {
          this.text = 'changeHeader';
        })
      }
    }
  }
}
```
**Figure 4** Example effect

![builderparam-demo4](figures/builderparam-demo4.png)

Use global @Builder and local @Builder to initialize @BuilderParam in the @ComponentV2 decorated custom components through trailing closures.

Example 2:

```ts
@ComponentV2
struct ChildPage {
  @Require @Param message: string = "";
  @Builder customBuilder() {};
  @BuilderParam customBuilderParam: () => void = this.customBuilder;

  build() {
    Column() {
      Text(this.message)
        .fontSize(30)
        .fontWeight(FontWeight.Bold)
      this.customBuilderParam()
    }
  }
}

const builder_value: string = 'Hello World';
@Builder function overBuilder() {
  Row() {
    Text(`Global Builder: ${builder_value}`)
      .fontSize(20)
      .fontWeight(FontWeight.Bold)
  }
}

@Entry
@ComponentV2
struct ParentPage {
  @Local label: string = `Parent Page`;

  @Builder componentBuilder() {
    Row(){
      Text(`Local Builder:${this.label}`)
        .fontSize(20)
        .fontWeight(FontWeight.Bold)
    }
  }

  build() {
    Column() {
      ChildPage({ message: this.label}){
        Column() {  // Use the local @Builder. Column component is followed by braces ({}) to form a trailing closure to initialize the custom component @BuilderParam.
          this.componentBuilder();
        }
      }
      Line()
        .width('100%')
        .height(10)
        .backgroundColor('#000000').margin(10)
      ChildPage({ message: this.label}){  // Use global @Builder. ChildPage component is followed by braces ({}) to form a trailing closure to initialize the custom component @BuilderParam.
        Column() {
          overBuilder();
        }
      }
    }
  }
}
```

### \@BuilderParam Initialization Through Global and Local \@Builder

In a custom component, the \@BuilderParam decorated variable is used to receive the content passed by the parent component through \@Builder for initialization. The \@Builder of the parent component can use the arrow function to change the object that this points to, therefore, when a \@BuilderParam decorated variable is used, different content is displayed.

```ts
@Component
struct ChildPage {
  label: string = `Child Page`;
  @Builder customBuilder() {};
  @BuilderParam customBuilderParam: () => void = this.customBuilder;
  @BuilderParam customChangeThisBuilderParam: () => void = this.customBuilder;

  build() {
    Column() {
      this.customBuilderParam()
      this.customChangeThisBuilderParam()
    }
  }
}

const builder_value: string = 'Hello World';
@Builder function overBuilder() {
  Row() {
    Text(`Global Builder: ${builder_value}`)
      .fontSize(20)
      .fontWeight(FontWeight.Bold)
  }
}

@Entry
@Component
struct ParentPage {
  label: string = `Parent Page`;

  @Builder componentBuilder() {
    Row(){
      Text(`Local Builder:${this.label}`)
        .fontSize(20)
        .fontWeight(FontWeight.Bold)
    }
  }

  build() {
    Column() {
      // When this.componentBuilder() is called, this points to the **ParentPage** component decorated by the @Entry. Therefore, the value of the label variable is Parent Page.
      this.componentBuilder()
      ChildPage({
        // Pass this.componentBuilder to @BuilderParam customBuilderParam of the ChildPage component. this points to ChildPage, that is, the value of the label variable is Child Page.
        customBuilderParam: this.componentBuilder,
        // Pass ():void=>{this.componentBuilder()} to @BuilderParam customChangeThisBuilderParam of the ChildPage component.
        // this of the arrow function points to the host object, so the value of the label variable is Parent Page.
        customChangeThisBuilderParam: (): void => { this.componentBuilder() }
      })
      Line()
        .width('100%')
        .height(10)
        .backgroundColor('#000000').margin(10)
      // When the global overBuilder() is called, this points to the entire current page. Therefore, the displayed content is Hello World.
      overBuilder()
      ChildPage({
        // Pass the global overBuilder to @BuilderParam customBuilderParam of the ChildPage component. this points to the entire current page, that is, the displayed content is Hello World.
        customBuilderParam: overBuilder,
        // Pass the global overBuilder to @BuilderParam customChangeThisBuilderParam of the ChildPage component. this points to the entire current page, that is, the displayed content is Hello World.
        customChangeThisBuilderParam: overBuilder
      })
    }
  }
}
```
**Figure 5** Example effect

![builderparam-demo5](figures/builderparam-demo5.png)

### Using @BuilderParam in a @ComponentV2 Decorated Custom Component

Use global @Builder and local @Builder to initialize the @BuilderParam attribute of the @CompoentV2 decorated custom component.

```ts
@ComponentV2
struct ChildPage {
  @Param label: string = `Child Page`;
  @Builder customBuilder() {};
  @BuilderParam customBuilderParam: () => void = this.customBuilder;
  @BuilderParam customChangeThisBuilderParam: () => void = this.customBuilder;

  build() {
    Column() {
      this.customBuilderParam()
      this.customChangeThisBuilderParam()
    }
  }
}

const builder_value: string = 'Hello World';
@Builder function overBuilder() {
  Row() {
    Text(`Global Builder: ${builder_value}`)
      .fontSize(20)
      .fontWeight(FontWeight.Bold)
  }
}

@Entry
@ComponentV2
struct ParentPage {
  @Local label: string = `Parent Page`;

  @Builder componentBuilder() {
    Row(){
      Text(`Local Builder:${this.label}`)
        .fontSize(20)
        .fontWeight(FontWeight.Bold)
    }
  }

  build() {
    Column() {
      // When this.componentBuilder() is called, this points to the **ParentPage** component decorated by the @Entry. Therefore, the value of the label variable is Parent Page.
      this.componentBuilder()
      ChildPage({
        // Pass this.componentBuilder to @BuilderParam customBuilderParam of the ChildPage component. this points to ChildPage, that is, the value of the label variable is Child Page.
        customBuilderParam: this.componentBuilder,
        // Pass ():void=>{this.componentBuilder()} to @BuilderParam customChangeThisBuilderPara of the ChildPage component.
        // this of the arrow function points to the host object, so the value of the label variable is Parent Page.
        customChangeThisBuilderParam: (): void => { this.componentBuilder() }
      })
      Line()
        .width('100%')
        .height(5)
        .backgroundColor('#000000').margin(10)
      // When the global overBuilder() is called, this points to the entire current page. Therefore, the displayed content is Hello World.
      overBuilder()
      ChildPage({
        // Pass the global overBuilder to @BuilderParam customBuilderParam of the ChildPage component. this points to the entire current page, that is, the displayed content is Hello World.
        customBuilderParam: overBuilder,
        // Pass the global overBuilder to @BuilderParam customChangeThisBuilderParam of the ChildPage component. this points to the entire current page, that is, the displayed content is Hello World.
        customChangeThisBuilderParam: overBuilder
      })
    }
  }
}
```
**Figure 6** Example effect

![builderparam-demo6](figures/builderparam-demo6.png)


## FAQs

### UI Re-rendering Fails When Content Is Changed

When the custom component **ChildPage** is called, \@Builder is passed as a parameter through **this.componentBuilder**. Currently, this points to the custom component. Therefore, if the **label** value is changed inside the parent component, the custom component **ChildPage** cannot detect the change.

[Incorrect Example]

```ts
@Component
struct ChildPage {
  @State label: string = `Child Page`;
  @Builder customBuilder() {};
  @BuilderParam customChangeThisBuilderParam: () => void = this.customBuilder;

  build() {
    Column() {
      this.customChangeThisBuilderParam()
    }
  }
}

@Entry
@Component
struct ParentPage {
  @State label: string = `Parent Page`;

  @Builder componentBuilder() {
    Row(){
      Text(`Builder :${this.label}`)
        .fontSize(20)
        .fontWeight(FontWeight.Bold)
    }
  }

  build() {
    Column() {
      ChildPage({
        // this points to the ChildPage component.
        customChangeThisBuilderParam: this.componentBuilder
      })
      Button('Click to change label')
        .onClick(() => {
          this.label = 'Hello World';
        })
    }
  }
}
```

Use the arrow function to pass the \@Builder to the custom component **ChildPage** and this points to the parent component **ParentPage**. Therefore, if the value of label is changed in the parent component, the **ChildPage** detects the change and renders the UI again.
The dynamic UI rendering can also be implemented by changing @Builder to @LocalBuilder.

[Correct Example]

```ts
@Component
struct ChildPage {
  @State label: string = `Child Page`;
  @Builder customBuilder() {};
  @BuilderParam customChangeThisBuilderParam: () => void = this.customBuilder;

  build() {
    Column() {
      this.customChangeThisBuilderParam()
    }
  }
}

@Entry
@Component
struct ParentPage {
  @State label: string = `Parent Page`;

  @Builder componentBuilder() {
    Row(){
      Text(`Builder :${this.label}`)
        .fontSize(20)
        .fontWeight(FontWeight.Bold)
    }
  }

  build() {
    Column() {
      ChildPage({
        customChangeThisBuilderParam: () => { this.componentBuilder() }
      })
      Button('Click to change label')
        .onClick(() => {
          this.label = 'Hello World';
        })
    }
  }
}
```
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: builderparam-demo1.png
###Image description: The image displays the text "Parent builder" in a simple, sans-serif font. The text is aligned centrally and appears to be in a light gray or white color on a dark background. The font size is relatively large, making the text easily readable. The overall design is minimalistic and straightforward, with no additional graphics or embellishments.
##Image Name: builderparam-demo2.png
###Image description: The image contains three lines of text, each line consisting of the words "Parent" and "Child." The text is arranged in a vertical format, with each word on a separate line. The words are evenly spaced and appear to be in a sans-serif font, which is commonly used for clarity and readability. The text color is a dark gray or black, and the background is white, making the text stand out clearly. The overall layout is simple and straightforward, with no additional graphics or elements present.
##Image Name: builderparam-demo3.png
###Image description: The image contains a simple, two-part structure with text elements. The top part of the image is white and contains two words: "Parent" and "Child," which are aligned horizontally and separated by a space. The text is in a bold, sans-serif font, making it easily readable.

Below this white section, there is a green rectangular area. This green section contains the text "global Builder label" in a white, sans-serif font. The text is centered within the green rectangle, and the font size is smaller compared to the bold text in the white section above.

### Analysis and Description

1. **Top Section:**
   - **Text:** "Parent" and "Child"
   - **Font:** Bold, sans-serif
   - **Color:** White
   - **Alignment:** Horizontally aligned
   - **Purpose:** This section likely represents a header or a title, indicating a relationship or hierarchy between two entities, "Parent" and "Child."

2. **Bottom Section:**
   - **Text:** "global Builder label"
   - **Font:** White, sans-serif
   - **Color:** Green
   - **Alignment:** Centered
   - **Purpose:** This section seems to be a label or descriptor, possibly indicating a specific category or type related to the "global Builder" concept mentioned in the top section.

### Relevant Knowledge Integration

The terms "Parent" and "Child" are commonly used in various contexts, such as family relationships, computer programming (where a parent-child relationship exists between classes or modules), and database structures. The "global Builder label" suggests that this image might be part of a user interface or a documentation related to a software or system that uses a builder pattern. The builder pattern is a design pattern used in software engineering to construct complex objects step by step.

### Conclusion

The image appears to be part of a user interface or documentation, possibly related to a software or system that uses a builder pattern. The "global Builder label" suggests that the "Parent" and "Child" relationship is a fundamental concept within this system. The use of bold and colored text helps to distinguish and emphasize the different sections, making the information more accessible and easier to understand.
##Image Name: builderparam-demo4.png
###Image description: The image contains a combination of text and a background element. Here is a detailed description:

1. **Text Elements:**
   - At the top of the image, there is a word "header" written in a bold, sans-serif font. The text is black and appears to be in uppercase.
   - Below the word "header," there are two lines of text labeled "testA" and "testB." These lines are also in uppercase and written in a bold, sans-serif font. The text color is black, and the background of these lines is a solid yellow color.

2. **Background Element:**
   - The background of the image is a solid yellow color. This yellow background encompasses the entire image, providing a contrasting backdrop for the text elements.

### Analysis and Description:

The image appears to be a simple design, likely used for testing or demonstrating text formatting. The use of bold, sans-serif fonts and the contrast between the black text and the yellow background make the text highly visible and easy to read. The word "header" at the top suggests that this image might be part of a template or a layout design where "header" is the title or label for the section below it.

The lines "testA" and "testB" are likely placeholders for actual content that would be used in a real-world application. These lines are formatted consistently with the "header" text, indicating a uniform design approach.

### Relevant Knowledge:

- **Typography:** The use of bold, sans-serif fonts is common in digital design for headings and titles due to their readability and clarity.
- **Color Contrast:** The contrast between the black text and the yellow background is significant. High contrast is essential in design to ensure that text is easily readable, especially in digital interfaces.
- **Design Principles:** The layout follows basic design principles such as alignment (the text is centered), contrast (the yellow background makes the black text stand out), and simplicity (the design is straightforward without unnecessary elements).

### Conclusion:

This image is a simple design template with a header and two test lines. The use of bold, sans-serif fonts and high contrast between text and background makes it easy to read and understand. This type of design is often used in digital interfaces to test text formatting and layout.
##Image Name: builderparam-demo5.png
###Image description: The image appears to be a comparison between two different types of builder functionalities in a software development context, specifically focusing on "Local Builder" and "Global Builder." The image is divided into two sections, each representing a different builder type.

### Local Builder: Parent Page
- **Top Section**: The top section contains the text "Local Builder: Parent Page" repeated three times. This suggests that the Local Builder is associated with a parent page in the application or project structure.
- **Appearance**: The text is aligned centrally and appears to be in a bold font, making it stand out clearly against the background.
- **Repetition**: The repetition of the text indicates that this might be a common or frequently used feature in the application.

### Global Builder: Hello World
- **Bottom Section**: The bottom section contains the text "Global Builder: Hello World" repeated three times. This suggests that the Global Builder is associated with a "Hello World" functionality, which is a common introductory example in programming.
- **Appearance**: Similar to the Local Builder, the text is centrally aligned and bold, ensuring it is easily noticeable.
- **Repetition**: The repetition of the text implies that this is also a frequently used feature, possibly a standard or default feature in the application.

### Analysis
- **Comparison**: The image seems to be highlighting the differences or similarities between the Local Builder and the Global Builder. The repeated text in both sections suggests that these are two distinct functionalities within the same application or project.
- **Functionality**: The Local Builder is associated with a parent page, which might imply that it is used for creating or managing pages within a larger application structure. The Global Builder, on the other hand, is associated with a "Hello World" functionality, which is typically used for testing or demonstrating basic functionality.
- **Usage**: The repetition of the text in both sections indicates that these functionalities are likely to be used frequently, suggesting their importance or commonality in the application.

### Conclusion
The image effectively contrasts two different builder functionalities within a software development context. The Local Builder is associated with a parent page, indicating its role in managing or creating pages within a larger application structure. The Global Builder, on the other hand, is associated with a "Hello World" functionality, suggesting its role in testing or demonstrating basic functionality. The repetition of the text in both sections emphasizes the importance and frequent use of these functionalities.
##Image Name: builderparam-demo6.png
###Image description: The image contains two sections of text, each with a different set of words and formatting. The text is presented in a simple, clean font, with a white background. Here is a detailed description of each section:

### Top Section:
- The text in this section is formatted in a bold, uppercase font.
- The words are arranged in a single line.
- The text reads: "LocalBuilder :Parent Page LocalBuilder :Child Page LocalBuilder :Parent Page"

### Bottom Section:
- The text in this section is also formatted in a bold, uppercase font.
- The words are arranged in a single line.
- The text reads: "GlobalBuilder: Hello World GlobalBuilder: Hello World GlobalBuilder: Hello World"

### Analysis:
1. **Top Section:**
   - The text "LocalBuilder :Parent Page" suggests that it is related to a local builder and a parent page.
   - The term "LocalBuilder" is repeated twice, indicating that it might be a key term or identifier.
   - The phrase "Parent Page" is repeated twice, suggesting that it is a recurring element in the context.

2. **Bottom Section:**
   - The text "GlobalBuilder: Hello World" suggests that it is related to a global builder and a message "Hello World".
   - The term "GlobalBuilder" is repeated twice, indicating that it might be a key term or identifier.
   - The phrase "Hello World" is repeated twice, suggesting that it is a recurring element in the context.

### Relevant Knowledge:
- **Local Builder vs. Global Builder:**
  - In software development, a local builder typically refers to a builder that is specific to a particular component or module within a project. It is used to construct or assemble components in a localized manner.
  - A global builder, on the other hand, is used to construct or assemble components across the entire project or application. It is more comprehensive and can handle a broader scope of components.

- **Parent Page vs. Child Page:**
  - In web development, a parent page is the main or primary page that contains links to other pages (child pages). It is the starting point for navigating through the website.
  - A child page is a page that is linked from a parent page. It is a secondary page that provides additional information or content.

### Conclusion:
The image appears to be a comparison or demonstration of different builder concepts in a software development context. The top section seems to illustrate local builder usage with parent and child pages, while the bottom section illustrates global builder usage with a repeated "Hello World" message. This could be used to explain how different builders handle different aspects of a project or application.
