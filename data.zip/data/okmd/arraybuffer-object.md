# ArrayBuffer Object

The ArrayBuffer contains a native memory. Similar to common objects, JS object shells need to be copied and transferred through serialization and deserialization. However, the native memory has two transmission modes: copy and transfer.

If copy is used during transmission, deep copy (recursive traversal) is required. After transmission, the two threads can independently access the ArrayBuffer. The following figure shows the communication process.

![copy_transfer](figures/copy_transfer.png)

If the transfer mode is used, the original thread cannot use the ArrayBuffer object. In cross-thread scenarios, only the JS shell needs to be rebuilt, and the native memory does not need to be copied, improving efficiency. The following figure shows the communication process.

![transfer](figures/transfer.png)

ArrayBuffer can be used to represent resources such as images. During application development, image processing is required (for example, the brightness, saturation, and size of an image need to be adjusted). To avoid blocking the UI main thread, you can transfer the image to a subthread to perform these operations. The transfer mode has higher performance. However, the original thread cannot access the ArrayBuffer object. If both threads need to access the ArrayBuffer object, the copy mode must be used. Otherwise, the transfer mode is recommended to improve performance.

The following describes how to transfer an image to a subthread by copying and transferring the image.

## ArrayBuffer copy transfer mode

In ArkTS, when the TaskPool transfers ArrayBuffer data, the transfer mode is used by default. You can call the setTransferList () API to specify the transfer mode as the transfer mode for some data and switch the copy mode for other data.

First, implement an interface that needs to be executed in a task to process ArrayBuffer.

Then, the ArrayBuffer data is transferred to the task in copy mode, and the ArrayBuffer is processed in the task.

Finally, the UI main thread receives the ArrayBuffer data returned after the task is executed and combines the data for display.

```ts
// Index.ets
import { taskpool } from '@kit.ArkTS';
import { BusinessError } from '@kit.BasicServicesKit';

@Concurrent
function adjustImageValue(arrayBuffer: ArrayBuffer): ArrayBuffer {
  // Perform operations on arrayBuffer.
  return arrayBuffer; // The return value is transferred by default.
}

function createImageTask(arrayBuffer: ArrayBuffer, isParamsByTransfer: boolean): taskpool.Task {
  let task: taskpool.Task = new taskpool.Task(adjustImageValue, arrayBuffer);
  if (!isParamsByTransfer) {// Whether to use the transfer mode
    // Transfer an empty array []. All arrayBuffer parameters are transferred in copy mode.
    task.setTransferList([]);
  }
  return task;
}

@Entry
@Component
struct Index {
  @State message: string = 'Hello World';

  build() {
    RelativeContainer() {
      Text(this.message)
        .id('HelloWorld')
        .fontSize(50)
        .fontWeight(FontWeight.Bold)
        .alignRules({
          center: { anchor: '__container__', align: VerticalAlign.Center },
          middle: { anchor: '__container__', align: HorizontalAlign.Center }
        })
        .onClick(() => {
          let taskNum = 4;
          let arrayBuffer = new ArrayBuffer(1024 * 1024);
          let taskPoolGroup = new taskpool.TaskGroup();
          // Create a certain number of tasks based on the input taskNum.
          for (let i: number = 0; i < taskNum; i++) {
            let arrayBufferSlice: ArrayBuffer = arrayBuffer.slice(arrayBuffer.byteLength / taskNum * i, arrayBuffer.byteLength / taskNum * (i + 1));
            // Use the copy method to transmit the ArrayBuffer object. Therefore, isParamsByTransfer is false.
            taskPoolGroup.addTask(createImageTask(arrayBufferSlice, false));
          }
          // Execute the task.
          taskpool.execute(taskPoolGroup).then((data) => {
            // Return the result. Combine the arrays to obtain the final result.
          }).catch((e: BusinessError) => {
            console.error(e.message);
          })
        })
    }
    .height('100%')
    .width('100%')
  }
}
```

## ArrayBuffer transfer mode

In the TaskPool, the transfer mode is used by default when the ArrayBuffer data is transferred. The original thread cannot use the ArrayBuffer data transferred to the subthread. Therefore, based on the preceding example, you can remove the task.setTransferList interface, that is, set the second parameter of createImageTask to true.
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: copy_transfer.png
###Image description: This image illustrates the process of copying a JavaScript (JS) ArrayBuffer wrapper between two different JS threads. The diagram is divided into two sections by a vertical dashed line, representing the boundary between the two threads.

1. **JS ArrayBuffer wrapper in the first thread:**
   - The first section on the left side of the image represents the first JS thread.
   - Inside this section, there is a JS ArrayBuffer wrapper labeled "buffer".
   - The "buffer" is indicated with a green checkmark, suggesting that it is a valid ArrayBuffer wrapper in this thread.

2. **JS ArrayBuffer wrapper in the second thread:**
   - The second section on the right side of the image represents the second JS thread.
   - Inside this section, there is another JS ArrayBuffer wrapper labeled "buffer'".
   - The "buffer'" is also indicated with a green checkmark, suggesting that it is a valid ArrayBuffer wrapper in this thread.

3. **Copy transfer:**
   - There is an arrow pointing from the "buffer" in the first thread to the "buffer'" in the second thread.
   - This arrow represents the copy transfer of the ArrayBuffer wrapper from the first thread to the second thread.
   - The copy transfer is labeled "Copy transfer," indicating that the data is being copied from one thread to another.

4. **Cross-JS thread:**
   - The vertical dashed line in the middle of the image separates the two threads, indicating that the copy transfer is occurring between different JS threads.
   - The label "Cross-JS thread" above the dashed line emphasizes that this is a cross-thread operation.

In summary, the image shows a scenario where a JS ArrayBuffer wrapper is copied from one JS thread to another, demonstrating the capability of transferring data between different threads in a JavaScript environment.
##Image Name: transfer.png
###Image description: This image illustrates the process of transferring a JavaScript `ArrayBuffer` wrapper object between two JavaScript threads. The diagram is divided into two sections, representing the two threads.

1. **Left Section (Blue Box):**
   - The blue box represents the first JavaScript thread.
   - Inside the blue box, there is a JavaScript `ArrayBuffer` wrapper object labeled "buffer" with a red "×" symbol, indicating that it is not transferable between threads.

2. **Right Section (Orange Box):**
   - The orange box represents the second JavaScript thread.
   - Inside the orange box, there is a JavaScript `ArrayBuffer` wrapper object labeled "buffer" with a green checkmark, indicating that it is transferable between threads.

3. **Transfer Process:**
   - A dashed line labeled "Transfer" connects the two sections, indicating the transfer of the `ArrayBuffer` object.
   - The transfer process is shown from the left section to the right section, with the "buffer" object being transferred from the blue box to the orange box.

4. **Cross-JS Thread:**
   - The dashed line labeled "Cross-JS thread" separates the two sections, indicating that the transfer is occurring between two different JavaScript threads.

The image highlights the difference in transferability of `ArrayBuffer` objects between threads, with the object being transferable in one direction but not in the other.
