# Component Navigation (Navigation) (Recommended)

Component navigation, implemented using the [Navigation](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md) component, is instrumental for managing transitions between pages and within components. It allows for the passing of redirection parameters across various components and offers various stack operations to simplify access to and reuse of diverse pages. This documentation delves into the display modes, routing operations, subpage management, cross-package navigation, and the effects of navigation transitions.

The [Navigation](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md) component serves as the root view container for route navigation and is commonly used as the root container for pages decorated with @Entry. It supports three display modes: Stack, Split, and Auto. This component is designed for both intra-module and cross-module routing, leveraging component-level routing to provide a more natural and seamless transition between pages. It also offers multiple title bar styles to enhance the cascading between titles and content. In one-time development for multi-device deployment scenarios, the **Navigation** component can automatically adapt to the window size. When the window is large enough, it automatically displays content in columns.

The **Navigation** component consists of a navigation page and subpages. The navigation page consists of the title bar (with the menu bar), content area, and toolbar, and can be hidden through the [hideNavBar](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#hidenavbar9) attribute. Unlike other pages, the navigation page does not reside in the page stack. Routing is used to manage transitions between the navigation page and its subpages, as well as between subpages themselves.

In API version 9, the **Navigation** component must be used together with the [NavRouter](../reference/apis-arkui/arkui-ts/ts-basic-components-navrouter.md) component for page routing. Since API version 10, whenever possible, use [NavPathStack](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#navpathstack10) instead to implement page routing.


## Setting the Page Display Mode

The **Navigation** component uses the **mode** attribute to set the page display mode.

- Adaptive Mode

  By default, the **Navigation** component is in adaptive mode. In this case, the **mode** attribute is **NavigationMode.Auto**. In adaptive mode, when the device width is greater than or equal to the threshold (520 vp for API version 9 and earlier and 600 vp for API version 10 and later), the **Navigation** component uses the column mode. Otherwise, the **Navigation** component uses the single-page mode.


  ```
  Navigation() {
    // ...
  }
  .mode(NavigationMode.Auto)
  ```

- Single-page mode

    **Figure 1** Single-page mode 

  ![en-us_image_0000001511740532](figures/en-us_image_0000001511740532.png)

  Set **mode** to **NavigationMode.Stack** so that the **Navigation** component is displayed on a single page.


  ```ts
  Navigation() {
    // ...
  }
  .mode(NavigationMode.Stack)
  ```

  ![Navigation in stack mode](figures/navigation-mode-stack.jpg)

- Column mode

  **Figure 2** Column mode

  ![en-us_image_0000001562820845](figures/en-us_image_0000001562820845.png)

  Set **mode** to **NavigationMode.Split** so that the **Navigation** component is displayed in columns.


  ```ts
  @Entry
  @Component
  struct NavigationExample {
    @State TooTmp: ToolbarItem = {'value': "func", 'icon': "./image/ic_public_highlights.svg", 'action': ()=> {}}
    @Provide('pageInfos') pageInfos: NavPathStack = new NavPathStack()
    private arr: number[] = [1, 2, 3];

    @Builder
    PageMap(name: string) {
      if (name === "NavDestinationTitle1") {
        pageOneTmp()
      } else if (name === "NavDestinationTitle2") {
        pageTwoTmp()
      } else if (name === "NavDestinationTitle3") {
        pageThreeTmp()
      }
    }
  
    build() {
      Column() {
        Navigation(this.pageInfos) {
          TextInput({ placeholder: 'Search...' })
            .width("90%")
            .height(40)
            .backgroundColor('#FFFFFF')
  
          List({ space: 12 }) {
            ForEach(this.arr, (item:number) => {
              ListItem() {
                Text("Page" + item)
                  .width("100%")
                  .height(72)
                  .backgroundColor('#FFFFFF')
                  .borderRadius(24)
                  .fontSize(16)
                  .fontWeight(500)
                  .textAlign(TextAlign.Center)
                  .onClick(()=>{
                    this.pageInfos.pushPath({ name: "NavDestinationTitle" + item})
                  })
              }
            }, (item:number) => item.toString())
          }
          .width("90%")
          .margin({ top: 12 })
        }
        .title("Main Title")
        .mode(NavigationMode.Split)
        .navDestination(this.PageMap)
        .menus([
          {value: "", icon: "./image/ic_public_search.svg", action: ()=> {}},
          {value: "", icon: "./image/ic_public_add.svg", action: ()=> {}},
          {value: "", icon: "./image/ic_public_add.svg", action: ()=> {}},
          {value: "", icon: "./image/ic_public_add.svg", action: ()=> {}},
          {value: "", icon: "./image/ic_public_add.svg", action: ()=> {}}
        ])
        .toolbarConfiguration([this.TooTmp, this.TooTmp, this.TooTmp])
      }
      .height('100%')
      .width('100%')
      .backgroundColor('#F1F3F5')
    }
  }

  // PageOne.ets
  @Component
  export struct pageOneTmp {
    @Consume('pageInfos') pageInfos: NavPathStack;
    build() {
      NavDestination() {
        Column() {
          Text("NavDestinationContent1")
        }.width('100%').height('100%')
      }.title("NavDestinationTitle1")
      .onBackPressed(() => {
        const popDestinationInfo = this.pageInfos.pop() // Pop the top element out of the navigation stack.
        console.log('pop' + 'Return value' + JSON.stringify(popDestinationInfo))
        return true
      })
    }
  }

  // PageTwo.ets
  @Component
  export struct pageTwoTmp {
    @Consume('pageInfos') pageInfos: NavPathStack;
    build() {
      NavDestination() {
        Column() {
          Text("NavDestinationContent2")
        }.width('100%').height('100%')
      }.title("NavDestinationTitle2")
      .onBackPressed(() => {
        const popDestinationInfo = this.pageInfos.pop() // Pop the top element out of the navigation stack.
        console.log('pop' + 'Return value' + JSON.stringify(popDestinationInfo))
        return true
      })
    }
  }

  // PageThree.ets
  @Component
  export struct pageThreeTmp {
    @Consume('pageInfos') pageInfos: NavPathStack;
    build() {
      NavDestination() {
        Column() {
          Text("NavDestinationContent3")
        }.width('100%').height('100%')
      }.title("NavDestinationTitle3")
      .onBackPressed(() => {
        const popDestinationInfo = this.pageInfos.pop() // Pop the top element out of the navigation stack.
        console.log('pop' + 'Return value' + JSON.stringify(popDestinationInfo))
        return true
      })
    }
  }
  ```

  ![Navigation in split mode](figures/navigation-mode-split.jpg)


## Setting the Title Bar Mode

The title bar is on the top of the page and is used to display the page name and operation entry. The **Navigation** component uses the **titleMode** attribute to set the title bar mode.

> **NOTE**
>
> If no main title or subtitle is set for **Navigation** or **NavDestination** and there is no back button, the title bar is not displayed.

- Mini mode

  Applicable when the title of a level-1 page does not need to be highlighted.

  **Figure 3** Title bar in Mini mode 

  ![mini](figures/mini.jpg)


  ```ts
  Navigation() {
    // ...
  }
  .titleMode(NavigationTitleMode.Mini)
  ```


- Full mode

  Applicable when the title of a level-1 page needs to be highlighted.

    **Figure 4** Title bar in Full mode 

  ![free1](figures/free1.jpg)


  ```ts
  Navigation() {
    // ...
  }
  .titleMode(NavigationTitleMode.Full)
  ```


## Setting the Menu Bar

The menu bar is in the upper right corner of the **Navigation** component. You can set the menu bar through the **menus** attribute, which supports two parameter types: Array&lt;[NavigationMenuItem](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#navigationmenuitem)&gt; and [CustomBuilder](../reference/apis-arkui/arkui-ts/ts-types.md#custombuilder8). When the Array\<NavigationMenuItem> type is used, a maximum of three icons can be displayed in portrait mode and a maximum of five icons can be displayed in landscape mode. Extra icons will be placed in the automatically generated More icons.

**Figure 5** Menu bar with three icons 

![menu-bar-2](figures/menu-bar-2.jpg)

```ts
let TooTmp: NavigationMenuItem = {'value': "", 'icon': "./image/ic_public_highlights.svg", 'action': ()=> {}}
Navigation() {
  // ...
}
.menus([TooTmp,
  TooTmp,
  TooTmp])
```

You can also reference images in the **resources** folder.

```ts
let TooTmp: NavigationMenuItem = {'value': "", 'icon': "resources/base/media/ic_public_highlights.svg", 'action': ()=> {}}
Navigation() {
  // ...
}
.menus([TooTmp,
  TooTmp,
  TooTmp])
```

**Figure 6** Menu bar with four icons 

![menu-bar](figures/menu-bar.jpg)

```ts
let TooTmp: NavigationMenuItem = {'value': "", 'icon': "./image/ic_public_highlights.svg", 'action': ()=> {}}
Navigation() {
  // ...
}
// In portrait mode, the toolbar shows a maximum of five icons, with any additional icons placed under an automatically generated More icon.
.menus([TooTmp,
  TooTmp,
  TooTmp,
  TooTmp])
```


## Setting the Toolbar

Use the [toolbarConfiguration](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#toolbarconfiguration10) attribute to customize the toolbar, which is located at the bottom of the **Navigation** component.


  **Figure 7** Toolbar 

![free3](figures/free3.jpg)

```ts
let TooTmp: ToolbarItem = {'value': "func", 'icon': "./image/ic_public_highlights.svg", 'action': ()=> {}}
let TooBar: ToolbarItem[] = [TooTmp,TooTmp,TooTmp]
Navigation() {
  // ...
}
.toolbarConfiguration(TooBar)
```

## Routing Operations

Navigation-related routing operations are all based on the APIs provided by [NavPathStack](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#navpathstack10). For each **Navigation** component, a **NavPathStack** object must be created and passed in to manage pages. The router operations mainly involve page navigation, page return, page replacement, page deletion, parameter acquisition, and route interception.

**NavPathStack** can be inherited since API version 12. You can customize attributes and methods in derived classes or override methods of the parent class. Derived class objects can be used in place of the base class **NavPathStack** objects. For details about the sample code, see [Example 10: Defining a Derived Class of NavPathStack](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#example-10-defining-a-derived-class-of-navpathstack).

> **NOTE**
>
> Avoid relying on lifecycle event listeners as a means to manage the navigation stack.

```ts
@Entry
@Component
struct Index {
  // Create a NavPathStack object and pass it to Navigation.
  pageStack: NavPathStack = new NavPathStack()

  build() {
    Navigation(this.pageStack) {
    }
    .title('Main')
  }
}
```

### Page Navigation

**NavPathStack** implements the following types of page navigation through **Push** related APIs:

1. Normal navigation: Navigation is conducted by page name and allows for passing of **param**.

    ```ts
    this.pageStack.pushPath({ name: "PageOne", param: "PageOne Param" })
    this.pageStack.pushPathByName("PageOne", "PageOne Param")
    ```

2. Navigation with a return callback: An **onPop** callback is added during navigation to obtain return information and process it upon page popping.

    ```ts
    this.pageStack.pushPathByName('PageOne', "PageOne Param", (popInfo) => {
      console.log('Pop page name is: ' + popInfo.info.name + ', result: ' + JSON.stringify(popInfo.result))
    });
    ```

3. Navigation with an error code: Upon failure, an asynchronous callback is triggered to provide the error code information.

    ```ts
    this.pageStack.pushDestination({name: "PageOne", param: "PageOne Param"})
      .catch((error: BusinessError) => {
        console.error(`Push destination failed, error code = ${error.code}, error.message = ${error.message}.`);
      }).then(() => {
        console.info('Push destination succeed.');
      });
    this.pageStack.pushDestinationByName("PageOne", "PageOne Param")
      .catch((error: BusinessError) => {
        console.error(`Push destination failed, error code = ${error.code}, error.message = ${error.message}.`);
      }).then(() => {
        console.info('Push destination succeed.');
      });
    ```

### Page Return

**NavPathStack** implements the page return feature through **Pop** related APIs.

```ts
// Return to the previous page.
this.pageStack.pop()
// Return to the previous PageOne page.
this.pageStack.popToName("PageOne")
// Return to the page whose index is 1.
this.pageStack.popToIndex(1)
// Return to the root home page (clear all pages in the stack).
this.pageStack.clear()
```

### Page Replacement

**NavPathStack** implements the page replacement feature through **Replace** related APIs.

```ts
// Replace the top page of the stack with PageOne.
this.pageStack.replacePath({ name: "PageOne", param: "PageOne Param" })
this.pageStack.replacePathByName("PageOne", "PageOne Param")
// Replacement with an error code: Upon failure, an asynchronous callback is triggered to provide the error code information.
this.pageStack.replaceDestination({name: "PageOne", param: "PageOne Param"})
  .catch((error: BusinessError) => {
    console.error(`Replace destination failed, error code = ${error.code}, error.message = ${error.message}.`);
  }).then(() => {
    console.info('Replace destination succeed.');
  })
```

### Page Deletion

**NavPathStack** implements the page deletion feature through **Remove** related APIs.

```ts
// Remove all pages whose name is PageOne from the stack.
this.pageStack.removeByName("PageOne")
// Remove the page with the specified index.
this.pageStack.removeByIndexes([1,3,5])
// Remove the page with the specified ID.
this.pageStack.removeByNavDestinationId("1");
```

### Page Moving

**NavPathStack** implements the page moving feature through **Move** related APIs.

```ts
// Move the page named PageOne to the top of the stack.
this.pageStack.moveToTop("PageOne");
// Move the page at index 1 to the top of the stack.
this.pageStack.moveIndexToTop(1);
```

### Parameter Acquisition

**NavPathStack** obtains parameters of the page through **Get** related APIs.

```ts
// Obtain all page names in the stack.
this.pageStack.getAllPathName()
// Obtain the parameters of the page whose index is 1.
this.pageStack.getParamByIndex(1)
// Obtain the parameters of the PageOne page.
this.pageStack.getParamByName("PageOne")
// Obtain the index set of the PageOne page.
this.pageStack.getIndexByName("PageOne")
```

### Route Interception

**NavPathStack** provides the [setInterception](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#setinterception12) API to set callbacks for page navigation interception of **Navigation**. This API requires passing in a **NavigationInterception** object, which contains three callback functions described below.

| Name      | Description                                                |
| ------------ | ------------------------------------------------------ |
| willShow   | Callback invoked when the page is about to be navigated, allowing for stack operations, which are effective in the current navigation.      |
| didShow    | Callback invoked after the page is navigated. Stack operations in this callback are effective in the next navigation.|
| modeChange | Callback invoked when the display mode of the **Navigation** component switches between single-column and dual-column. |

> **NOTE**
>
> The navigation stack has already changed when any of the preceding callbacks is invoked.

You can implement the capability to intercept and redirect in the **willShow** callback by modifying the route stack.

```ts
this.pageStack.setInterception({
  willShow: (from: NavDestinationContext | "navBar", to: NavDestinationContext | "navBar",
    operation: NavigationOperation, animated: boolean) => {
    if (typeof to === "string") {
      console.log("target page is navigation home page.");
      return;
    }
    // Redirect navigation to PageTwo to PageOne.
    let target: NavDestinationContext = to as NavDestinationContext;
    if (target.pathInfo.name === 'PageTwo') {
      target.pathStack.pop();
      target.pathStack.pushPathByName('PageOne', null);
    }
  }
})
```

## Subpage

[NavDestination](../reference/apis-arkui/arkui-ts/ts-basic-components-navdestination.md) is the root container for **Navigation** subpages, used to hold some special attributes as well as lifecycles of subpages. You can set separate attributes such as the title bar and menu bar for **NavDestination**, in the same way you set attributes for **Navigation**. You can also set different display modes for **NavDestination** through the **mode** attribute to meet different page requirements.

### Page Display Mode

- Standard mode

  By default, subpages in the **NavDestination** component are in standard mode, which corresponds to the **NavDestinationMode.STANDARD** value of the **mode** attribute. The lifecycle of a standard type **NavDestination** follows the changes in its position in the **NavPathStack**.

- Dialog mode
  
  With **mode** set to **NavDestinationMode.DIALOG**, a **NavDestination** The appearance and disappearance of the dialog-type **NavDestination** will not affect the display and lifecycle of the underlying standard-type **NavDestination**, and the two can be displayed at the same time.
  
  ```ts
  // Dialog NavDestination
  @Entry
  @Component
   struct Index {
     @Provide('NavPathStack') pageStack: NavPathStack = new NavPathStack()
  
     @Builder
     PagesMap(name: string) {
       if (name == 'DialogPage') {
         DialogPage()
       }
     }
  
     build() {
       Navigation(this.pageStack) {
         Button('Push DialogPage')
           .margin(20)
           .width('80%')
           .onClick(() => {
             this.pageStack.pushPathByName('DialogPage', '');
           })
       }
       .mode(NavigationMode.Stack)
       .title('Main')
       .navDestination(this.PagesMap)
     }
   }
  
   @Component
   export struct DialogPage {
     @Consume('NavPathStack') pageStack: NavPathStack;
  
     build() {
       NavDestination() {
         Stack({ alignContent: Alignment.Center }) {
           Column() {
             Text("Dialog NavDestination")
               .fontSize(20)
               .margin({ bottom: 100 })
             Button("Close").onClick(() => {
               this.pageStack.pop()
             }).width('30%')
           }
           .justifyContent(FlexAlign.Center)
           .backgroundColor(Color.White)
           .borderRadius(10)
           .height('30%')
           .width('80%')
         }.height("100%").width('100%')
       }
       .backgroundColor('rgba(0,0,0,0.5)')
       .hideTitleBar(true)
       .mode(NavDestinationMode.DIALOG)
     }
   }
  ```
  ![dialog_navdestination](figures/dialog_navdestination.png)

### Page Lifecycle

**Navigation**, as a routing container, hosts its lifecycle within the **NavDestination** component and exposes lifecycle events as component events.

The lifecycle of **Navigation** can be divided into three categories: custom component lifecycle, universal component lifecycle, and its own exclusive lifecycle. [aboutToAppear](../reference/apis-arkui/arkui-ts/ts-custom-component-lifecycle.md#abouttoappear) and [aboutToDisappear](../reference/apis-arkui/arkui-ts/ts-custom-component-lifecycle.md#abouttodisappear) are the lifecycle callbacks of custom components (custom components contained in the outer layer of **NavDestination**); [OnAppear](../reference/apis-arkui/arkui-ts/ts-universal-events-show-hide.md#onappear) and [OnDisappear](../reference/apis-arkui/arkui-ts/ts-universal-events-show-hide.md#ondisappear) are universal component lifecycle callbacks. The remaining six lifecycle events are unique to **NavDestination**.

The sequence of these lifecycle events is illustrated in the figure below.

![navigation_lifecycle](figures/navigation_lifecycle.png)

- **aboutToAppear**: Invoked when the custom component is about to appear. Specifically, it is invoked after a new instance of the custom component is created and before its **build()** function is executed (before the creation of **NavDestination**). You can change state variables in this callback, and the changes take effect in the subsequent execution of **build()**.
- **onWillAppear**: invoked after the **NavDestination** component is created and before it is mounted to the component tree. Changing the state variable in this callback takes effect in the current frame.
- **onAppear**: invoked when the **NavDestination** component is mounted to the component tree. It is a universal lifecycle event.
- **onWillShow**: invoked before the **NavDestination** component layout is displayed. In this case, the page is invisible. (This callback is not invoked when the application is switched to the foreground.)
- **onShown**: invoked after the **NavDestination** component layout is displayed. At this time, the page layout is complete.
- **onWillHide**: invoked when the **NavDestination** component is about to be hidden (it is not invoked when the application is switched to the background).
- **onHidden**: invoked after the **NavDestination** component is hidden (when a non-top page is pushed into the stack, the top page pops out of the stack, or the application is switched to the background).
- **onWillDisappear**: invoked before the **NavDestination** component is about to be destroyed. If there is a transition animation, this callback is invoked before the animation (when the top page of the stack pops out of the stack).
- **onDisappear**: invoked when the **NavDestination** component is unloaded and destroyed from the component tree. It is a universal lifecycle event.
- **aboutToDisappear**: invoked before the custom component is destroyed. The state variable cannot be changed in this callback.

### Page Listening and Query

To facilitate the decoupling of components from pages, custom components within **NavDestination** subpages can listen for or query some page status information through global APIs.

- Page information query

  Custom components provide the [queryNavDestinationInfo](../reference/apis-arkui/arkui-ts/ts-custom-component-api.md#querynavdestinationinfo) API, which can be used to query the information of the current page within **NavDestination**. The return value is [NavDestinationInfo](../reference/apis-arkui/js-apis-arkui-observer.md#navdestinationinfo). If the query fails, the return value is **undefined**.
  
  ```ts
   import { uiObserver } from '@kit.ArkUI';
  
   // Custom components within NavDestination
   @Component
   struct MyComponent {
     navDesInfo: uiObserver.NavDestinationInfo | undefined
  
     aboutToAppear(): void {
       this.navDesInfo = this.queryNavDestinationInfo();
     }
  
     build() {
         Column() {
           Text("Page name: " + this.navDesInfo?.name)
         }.width('100%').height('100%')
     }
   }
  ```
- Page status listening
  
  You can register a listener for **NavDestination** lifecycle changes using the [observer.on('navDestinationUpdate')](../reference/apis-arkui/js-apis-arkui-observer.md#observeronnavdestinationupdate) API.
  
  ```ts
  uiObserver.on('navDestinationUpdate', (info) => {
       console.info('NavDestination state update', JSON.stringify(info));
   });
  ```
  
  You can also register a callback for page transition states to obtain page information during route changes using [NavDestinationSwitchInfo](../reference/apis-arkui/js-apis-arkui-observer.md#navdestinationswitchinfo12). This registration supports different scopes: UIAbilityContext and UIContext.
  
  ```ts
   // Used in UIAbility
   import { UIContext, uiObserver } from '@kit.ArkUI';
  
   // callBackFunc is a callback defined by you.
   function callBackFunc(info: uiObserver.NavDestinationSwitchInfo) {}
   uiObserver.on('navDestinationSwitch', this.context, callBackFunc);
  
   // The getUIContext() API of the window can be used to obtain the corresponding UIContent.
   uiContext: UIContext | null = null;
   uiObserver.on('navDestinationSwitch', this.uiContext, callBackFunc);
  ```

## Page Transition

The **Navigation** component provides default transition animations for switching between pages. These animations are activated when operations are performed on the navigation stack, producing different transition effects. Note that for dialog box pages, the default transition animations are available only since API version 13. The **Navigation** component also offers advanced features such as disabling the default transitions and implementing custom transitions as well as shared element transitions.

### Disabling Transitions

- On a Global Basis
  
  To enable or disable all transition animations in the current **Navigation** component, you can use the [disableAnimation](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#disableanimation11) API provided in **NavPathStack**.
  ```ts
  pageStack: NavPathStack = new NavPathStack()
  
  aboutToAppear(): void {
    this.pageStack.disableAnimation(true)
  }
  ```
- On a One-time Basis
  
  To disable the transition animation for a single operation (implemented by APIs provided by **NavPathStack**, such as **Push**, **Pop**, and **Replace**), set the **animated** parameter in the API to **false**. This setting does not affect the next transition.
  ```ts
  pageStack: NavPathStack = new NavPathStack()
  
  this.pageStack.pushPath({ name: "PageOne" }, false)
  this.pageStack.pop(false)
  ```

### Customizing a Transition

You can customize transition animations through the [customNavContentTransition](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#customnavcontenttransition11) event. Specifically, you can define a custom transition animation in the following steps:

1. Build a custom transition animation utility class **CustomNavigationUtils**, which manages custom transition animation **CustomTransition** objects for each page through a Map. A page registers its **CustomTransition** object when created and unregisters it when destroyed.
2. Implement a transition protocol object [NavigationAnimatedTransition](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#navigationanimatedtransition11). The **timeout** property indicates the transition timeout duration, with a default value of 1000 ms. The **transition** property is where you implement your custom transition animation logic; it is the method that the system calls when the transition starts. The **onTransitionEnd** is the callback for when the transition ends.
3. Call the **customNavContentTransition** API to return the **NavigationAnimatedTransition** object. If **undefined** is returned, the system default transition is used.

For details about the sample code, see [Example 3: Setting an Interactive Transition Animation](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#example-3-setting-an-interactive-transition-animation).

### Defining a Shared Element Transition

You can implement shared element transitions between navigation destination pages using [geometryTransition](../reference/apis-arkui/arkui-ts/ts-transition-animation-geometrytransition.md#geometrytransition). Ensure that the default transition animations are disabled for pages configured with shared element transitions.
1. Add the **geometryTransition** attribute to the components that need to implement shared element transitions, ensuring that the **id** parameter is consistent between the two **NavDestination** components.

    ```ts
    // Set id of the source page.
    NavDestination() {
      Column() {
        // ...
        Image($r('app.media.startIcon'))
        .geometryTransition('sharedId')
        .width(100)
        .height(100)
      }
    }
    .title('FromPage')

    // Set id of the destination page.
    NavDestination() {
      Column() {
        // ...
        Image($r('app.media.startIcon'))
        .geometryTransition('sharedId')
        .width(200)
        .height(200)
      }
    }
    .title('ToPage')
    ```

2. Place the page routing operation in the **animateTo** animation closure, set the corresponding animation parameters, and disable the default transition.

    ```ts
    NavDestination() {
      Column() {
        Button('Go to Destination Page')
        .width('80%')
        .height(40)
        .margin(20)
        .onClick(() => {
            this.getUIContext()?.animateTo({ duration: 1000 }, () => {
              this.pageStack.pushPath({ name: 'ToPage' }, false)
            })
        })
      }
    }
    .title('FromPage')
    ```

## Cross-Package Dynamic Routing

Using static imports for page routing can lead to coupling between different modules and prolonged home page loading times.

The purpose of dynamic routing is to allow multiple modules (HARs/HSPs) to reuse the same business logic, with decoupling between different modules and integration of routing functionality.

**Advantages of dynamic routing**

- In addition to the URL for navigation, you can configure various information, such as the default orientation (landscape or portrait) and whether authentication is required. The configuration is processed in a unified manner during routing
- You can assign a name to each routing page and navigate by name instead of file path.
- Dynamic imports (on-demand loading) can be used to load pages to prevent the first page from loading a large amount of code, which can cause stuttering.

Dynamic routing provides two modes: [System Routing Table](#system-routing-table) and [Custom Routing Table](#custom-routing-table).

- The system routing table is easier to use than the custom routing table. It only requires adding the corresponding page navigation configuration items to implement page navigation.

- The custom route table is more complex to use, but can be customized to meet specific service requirements.

The custom route table and system route table can be used together.

### System Routing Table

**Navigation** supports the system routing table for dynamic routing since API version 12. Each service module ([HSP](../quick-start/in-app-hsp.md) or [HAR](../quick-start/har-package.md)) requires an individual **route_map.json** file. When routing is triggered, the application only needs to pass the name of the page that needs to be routed through the routing API provided by **NavPathStack**. The system then automatically completes the dynamic loading of the target module, page component construction, and route redirection. This way, module decoupling is achieved at the development level. Note that the system routing table does not work with DevEco Studio Previewer, cross-platform functionality, or emulators. The main steps are as follows:

1. Add the route table configuration to the **module.json5** file of the redirection target module.
   
   ```json
     {
       "module" : {
         "routerMap": "$profile:route_map"
       }
     }
   ```
2. Create the **route_map.json** file in **resources/base/profile** of the project directory. Add the following configuration information:
   
   ```json
     {
       "routerMap": [
         {
           "name": "PageOne",
           "pageSourceFile": "src/main/ets/pages/PageOne.ets",
           "buildFunction": "PageOneBuilder",
           "data": {
             "description" : "this is PageOne"
           }
         }
       ]
     }
   ```

    The configuration is described as follows.

   | Item| Description|
   |---|---|
   | name | Name of the target page to be redirected to.|
   | pageSourceFile | Path of the target page in the package, relative to the **src** directory.|
   | buildFunction | Name of the entry point function for redirection to the target page, which must be decorated by @Builder.|
   | data | Custom data. You can obtain the value through the **getConfigInRouteMap** API.|

3. On the target page, configure the @Builder decorated entry point function. The function name must be the same as the value of **buildFunction** in the **route_map.json** file. Otherwise, an error is reported at compile time.
   
   ```ts
     // Entry point function for redirection to the target page
     @Builder
     export function PageOneBuilder() {
       PageOne()
     }
   
     @Component
     struct PageOne {
       pathStack: NavPathStack = new NavPathStack()
   
       build() {
         NavDestination() {
         }
         .title('PageOne')
         .onReady((context: NavDestinationContext) => {
            this.pathStack = context.pathStack
         })
       }
     }
   ```
4. Use routing APIs such as **pushPathByName** to navigate to the target page. (Note: In this case, you do not need to configure the **navDestination** attribute in **Navigation**.)
   
   ```ts
     @Entry
     @Component
     struct Index {
       pageStack : NavPathStack = new NavPathStack();
   
       build() {
         Navigation(this.pageStack){
         }.onAppear(() => {
           this.pageStack.pushPathByName("PageOne", null, false);
         })
         .hideNavBar(true)
       }
     }
   ```

### Custom Routing Table

You can implement cross-package dynamic routing through a custom routing table.

**Implementation:**

1. Define page navigation configuration items.
   - Use resource files for definitions and use the [@ohos.resourceManager](../reference/apis-localization-kit/js-apis-resource-manager.md) module to parse the resource files at runtime.
   - Configure the route loading options in the .ets file, including the route page name (that is, the alias of the page in APIs like **pushPath**), name of the module where the file is located (name of the HSP/HAR module), and path to the target page in the module (relative to the **src** directory).
2. Use [dynamic import](../arkts-utils/arkts-dynamic-import.md) to load the module containing the target page at runtime. Once the module is loaded, call a method within the module that uses **import** to load and display the target page, then return the **Builder** function defined after the page has finished loading.
3. Execute the **Builder** function loaded in step 2 on the [navDestination](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#navdestination10) attribute of the **Navigation** component to navigate to the target page.
<!--RP2--><!--RP2End-->
<!--no_check-->
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: en-us_image_0000001511740532.png
###Image description: The image depicts a comparison between two different user interface (UI) layouts, likely from a mobile application or a web application. The layouts are presented side by side, with the left side showing a traditional UI layout and the right side showing a more modern or updated UI layout.

### Left Side (Traditional Layout):
1. **Title Bar**: At the top of the layout, there is a title bar with the text "Title bar" and a menu bar with the text "Menu bar."
2. **Content Area**: Below the title bar, there is a large rectangular area labeled "Content area."
3. **Navigation Bar**: Within the content area, there is a smaller rectangular area labeled "Navigation bar (Implemented by <NavRouter>)."

### Right Side (Modern Layout):
1. **Title Bar**: Similar to the left side, there is a title bar with the text "Title bar" and a menu bar with the text "Menu bar."
2. **Content Area**: Below the title bar, there is a large rectangular area labeled "Content area (Content in <NavDestination>)."
3. **Navigation Bar**: The navigation bar is not explicitly shown in this layout, but it is implied that the content in the "Content area" is managed by a navigation router, similar to the left side.

### Key Differences:
- **Navigation Bar**: The left side explicitly shows a navigation bar within the content area, while the right side implies that the navigation is handled by a navigation router.
- **Content Area**: The right side's content area is labeled with a more specific term, "Content area (Content in <NavDestination>)," indicating a more dynamic or context-specific content management.

### Analysis:
- The traditional layout on the left side is more straightforward, with a clear separation between the title bar, menu bar, content area, and navigation bar.
- The modern layout on the right side suggests a more flexible and dynamic approach to content management, where the navigation is handled by a navigation router, potentially allowing for more complex navigation structures and dynamic content loading.

### Conclusion:
The image illustrates the evolution from a traditional UI layout to a more modern, flexible UI layout, emphasizing the shift towards more dynamic content management and navigation through the use of navigation routers.
##Image Name: navigation-mode-stack.jpg
###Image description: The image depicts a simple user interface layout, likely from a mobile application. The layout is minimalistic and consists of several key elements:

1. **Main Title**: At the top of the screen, there is a section labeled "Main Title." This section contains a placeholder text that reads "Search..." indicating that it is meant for a search bar.

2. **Search Bar**: Below the main title, there is a search bar with the placeholder text "Search...". This bar is designed for users to enter search queries.

3. **Navigation Buttons**: Below the search bar, there are three buttons labeled "Page1", "Page2", and "Page3". These buttons likely serve as navigation links to different sections or pages within the application.

4. **Footer**: At the bottom of the screen, there are three icons. Each icon is represented by a star symbol and is labeled with the word "func". These icons might be shortcuts to different functionalities or settings within the app.

The overall design is clean and modern, with a focus on simplicity and ease of use. The use of a search bar and navigation buttons suggests that the app is designed to allow users to quickly find and access different sections or features.
##Image Name: en-us_image_0000001562820845.png
###Image description: The image depicts a comparison between two different user interface (UI) layouts, likely for a mobile application. The layout on the left is labeled as "Title bar Menu bar Content area Navigation bar (Implemented by <NavRouter>) Toolbar," while the layout on the right is labeled as "<NavDestination> title bar Menu bar Content area (Content in <NavDestination>) Navigation bar (Implemented by <NavRouter>) Toolbar."

### Left Layout Description:
1. **Title bar**: Located at the top of the layout, this section typically displays the title or name of the application or the current screen.
2. **Menu bar**: Positioned below the title bar, this section contains a set of menu options or actions that the user can interact with.
3. **Content area**: This is the main area where the application's content is displayed. It is the largest section in the layout.
4. **Navigation bar**: Located below the content area, this section is used for navigation within the application. It is implemented by `<NavRouter>`, which suggests that it is a navigation component that manages the transitions between different screens or destinations.
5. **Toolbar**: Positioned at the bottom of the layout, this section contains additional tools or options that the user can interact with.

### Right Layout Description:
1. **<NavDestination> title bar**: This section is labeled as "<NavDestination> title bar," indicating that it is a title bar for a specific navigation destination within the application.
2. **Menu bar**: Positioned below the title bar, this section contains a set of menu options or actions.
3. **Content area**: This section is labeled as "Content area (Content in <NavDestination>)," indicating that it displays the content associated with the specific navigation destination.
4. **Navigation bar**: Located below the content area, this section is implemented by `<NavRouter>`, similar to the left layout.
5. **Toolbar**: Positioned at the bottom of the layout, this section contains additional tools or options.

### Analysis:
- Both layouts share a similar structure with a title bar, menu bar, content area, navigation bar, and toolbar.
- The main difference lies in the specific labels and components used. The left layout uses generic terms like "Content area" and "Navigation bar," while the right layout uses "<NavDestination> title bar" and "Content area (Content in <NavDestination>)," indicating a more specific navigation context.
- The navigation bar in both layouts is implemented by `<NavRouter>`, suggesting a common navigation framework or library used in both designs.

### Conclusion:
The image illustrates two UI layouts for a mobile application, highlighting the similarities and differences in their structure and labeling. The left layout is more generic, while the right layout is more specific to a navigation context within the application.
##Image Name: navigation-mode-split.jpg
###Image description: The image depicts a user interface layout, likely from a mobile application or a website. The layout is divided into two main sections: a sidebar on the left and a content area on the right.

### Sidebar (Left Section)
- **Title**: The top section of the sidebar contains a title labeled "Main Title."
- **Search Bar**: Below the title, there is a search bar with the placeholder text "Search..." indicating that users can search for content within the application.
- **Navigation Buttons**: Below the search bar, there are three buttons labeled "Page1," "Page2," and "Page3." These buttons likely serve as navigation links to different sections or pages within the application.

### Content Area (Right Section)
- **Title**: The top section of the content area contains a title labeled "NavDestinationTitle1."
- **Content Area**: Below the title, there is a placeholder text "NavDestinationContent1," indicating that this section is meant to display content related to the title.

### Additional Elements
- **Bottom Section**: At the bottom of the sidebar, there are three icons with star symbols, each labeled "func." These icons might represent different functionalities or features within the application.

### Analysis
The layout suggests a user-friendly interface designed for easy navigation and search functionality. The sidebar provides quick access to different sections of the application, while the content area is where the main content is displayed. The presence of a search bar indicates that the application supports user-driven content discovery, allowing users to find specific information or pages within the app.

### Conclusion
This image represents a typical mobile application or website layout with a focus on navigation and search capabilities. The sidebar provides a clear and organized way to access different sections, while the content area is designed to display detailed information or content related to the selected section. The bottom icons suggest additional functionalities that users can access, enhancing the overall user experience.
##Image Name: mini.jpg
###Image description: The image depicts a minimalist interface, likely from a mobile application or a website. The layout is simple and clean, with a light background. At the top of the screen, there is a navigation bar with the text "Main Title" centered in the middle. Below the navigation bar, there is a search bar with the placeholder text "search..." indicating that users can type in their search queries here.

To the right of the search bar, there are three icons:
1. A magnifying glass icon, typically used for search functionality.
2. A plus sign, which is commonly used to add new items or content.
3. Three vertical dots, which usually represent a menu or more options.

Below the search bar, there is a large, empty space that appears to be a placeholder for content. This space is likely where search results or other relevant information would be displayed.

At the bottom of the screen, there are three icons arranged horizontally:
1. The first icon is a star with a line through it, which is often used to indicate a favorite or favorite list feature.
2. The second icon is a star, which is commonly used to represent a rating or favorite feature.
3. The third icon is another star, similar to the second one, indicating another rating or favorite feature.

The overall design is very minimalistic, with a focus on simplicity and ease of use. The interface is likely designed to be user-friendly, with clear indicators for search, adding new items, and accessing additional options or features.
##Image Name: free1.jpg
###Image description: The image depicts a minimalist user interface, likely from a mobile application or a website. The layout is clean and modern, featuring a simple design with a focus on functionality.

### Description:

1. **Header Section:**
   - **Main Title:** At the top of the screen, there is a prominent title labeled "Main Title." This title is centered and appears to be the primary heading for the content displayed below.
   - **Search Bar:** Below the main title, there is a search bar with the placeholder text "search..." indicating that users can type in their queries to search for specific content within the application or website.

2. **Content Area:**
   - **Blank Space:** The central part of the screen is a large, empty space with a light gray background. This area is designed to display content such as articles, images, videos, or other types of information. Currently, it is blank, suggesting that there is no content loaded or that the user has not yet interacted with the search function.

3. **Footer Section:**
   - **Function Icons:** At the bottom of the screen, there are three icons arranged horizontally. Each icon is represented by a star symbol followed by the word "func." The icons are likely shortcuts to different functionalities within the application. The exact purpose of these icons is not specified in the image, but they are commonly used to provide quick access to frequently used features.

### Analysis:

- **User Interface Design:** The design is minimalistic, focusing on simplicity and ease of use. The clean layout with a single search bar and a large content area suggests that the application or website is designed to be user-friendly and straightforward.
- **Function Icons:** The presence of function icons at the bottom indicates that the application or website offers additional functionalities that can be accessed quickly. This is a common feature in many mobile applications, allowing users to navigate to different sections or perform specific actions without having to exit the current screen.

### Conclusion:

The image represents a simple and clean user interface with a search bar at the top and a large, empty content area in the middle. The bottom of the screen features function icons, suggesting additional functionalities for the user. This design is typical of modern applications that prioritize ease of use and quick access to various features.
##Image Name: menu-bar-2.jpg
###Image description: The image appears to be a simple graphic with three identical icons arranged in a horizontal line. Each icon is a small, circular shape with a plus sign (+) in the center. The background of the image is plain white, and the icons are evenly spaced. The plus signs are black, which contrasts with the white background, making them easily noticeable. 

Given the simplicity and uniformity of the design, these icons likely represent an increase or addition, commonly used in user interfaces to indicate the option to add more items, increase a quantity, or expand a section. This type of iconography is often used in applications, websites, and digital interfaces to provide users with a clear and intuitive way to perform actions related to adding or increasing something.

### Analysis and Description

1. **Icons and Symbols**:
   - **Shape**: Each icon is a circle.
   - **Color**: The background of the icons is white, and the plus signs are black.
   - **Content**: Each icon contains a plus sign (+) in the center.

2. **Arrangement**:
   - **Orientation**: The icons are arranged horizontally.
   - **Spacing**: The icons are evenly spaced.

3. **Functionality**:
   - **Purpose**: These icons are likely used to indicate the option to add more items, increase a quantity, or expand a section in a user interface.

4. **Context**:
   - **Common Use**: Such icons are commonly found in applications and websites where users need to add more items, increase quantities, or expand sections.

### Conclusion

The image is a simple, clear representation of three identical icons, each featuring a plus sign in a white circle. These icons are designed to convey the concept of addition or increase, typically used in user interfaces to allow users to add more items, increase quantities, or expand sections. The uniformity and simplicity of the design ensure that the icons are easily recognizable and intuitive for users.
##Image Name: menu-bar.jpg
###Image description: The image contains three distinct icons arranged horizontally. Each icon is a simple, geometric shape with a specific function or meaning.

1. The first icon on the left is a plus sign (+). This symbol is universally recognized as an addition sign in mathematics, indicating the operation of adding two or more numbers together. It is often used in various contexts such as calculations, equations, and data aggregation.

2. The second icon is another plus sign (+), identical in appearance to the first one. This repetition suggests that it might be used to indicate a similar function or operation, possibly in a different context or as a part of a larger set of symbols.

3. The third icon is a colon (:) followed by a double colon (::). This combination is not a standard mathematical or arithmetic symbol. However, in some contexts, it can be used to denote a ratio or proportion. For example, in programming or data representation, it might be used to separate keys and values in a dictionary or to indicate a specific relationship between two entities.

In summary, the image presents three icons: a plus sign, another plus sign, and a colon followed by a double colon. These icons are likely used to represent mathematical operations or relationships in a specific context.
##Image Name: free3.jpg
###Image description: The image consists of three identical icons arranged in a horizontal line. Each icon is a stylized representation of a star, commonly used to denote ratings, preferences, or importance. The stars are outlined in black against a white background, giving them a simple and clean appearance. Below each star, there is a word "func" written in lowercase letters. The font is sans-serif, which contributes to the modern and minimalistic aesthetic of the image. The overall design is straightforward and uncluttered, focusing on the icons and the text beneath them.
##Image Name: dialog_navdestination.png
###Image description: The image shows a mobile application interface with a simple design. The background color is a dark gray, and the main content area is a white rectangle. At the top of the interface, there is a blue button labeled "Push DialogPage." Below this button, there is a larger white rectangle with a blue button inside it. The blue button has the text "Close" on it. The text inside the white rectangle reads "Dialog NavDestination." The overall layout is clean and minimalistic, with a focus on the dialog box and the button to close it.
##Image Name: navigation_lifecycle.png
###Image description: The image is a flowchart that illustrates the lifecycle of a `NavDestination` in an Android navigation system. This lifecycle is triggered by the `aboutToAppear()` method, which initiates a sequence of callback methods that are called at specific stages of the navigation process. The flowchart is structured as follows:

1. **aboutToAppear()**:
   - This method is called when the navigation system is about to show the destination.

2. **onWillAppear()**:
   - This method is called just before the destination is shown.

3. **onAppear()**:
   - This method is called when the destination is fully visible and in the foreground.

4. **onWillShow()**:
   - This method is called just before the destination is shown in the foreground.

5. **onShown()**:
   - This method is called when the destination is shown in the foreground and is fully visible.

6. **onWillHide()**:
   - This method is called just before the destination is hidden from the foreground.

7. **onHidden()**:
   - This method is called when the destination is hidden from the foreground.

8. **onWillDisappear()**:
   - This method is called just before the destination is removed from the navigation stack.

9. **onDisappear()**:
   - This method is called when the destination is removed from the navigation stack and is no longer visible.

10. **aboutToDisappear()**:
    - This method is called when the navigation system is about to remove the destination from the stack.

The flowchart also includes two additional states:
- **Page switched to background**: This indicates that the destination is being switched to the background.
- **Page switched to foreground**: This indicates that the destination is being switched to the foreground.

The flowchart is enclosed within a dashed box labeled "NavDestination," which signifies that these lifecycle methods are specific to the navigation system's handling of destinations. The arrows between the methods indicate the sequence in which they are called, and the dashed lines with text annotations show the conditions under which the methods are triggered.
