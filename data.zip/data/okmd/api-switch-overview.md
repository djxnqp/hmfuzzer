# API Switching Overview


Due to the differences in the thread model and process model, certain APIs can be used only in the FA model. They are marked with **FAModelOnly** in the SDK. When switching an application from the FA model to the stage model, replace the APIs marked with **FAModelOnly** in the application with the APIs supported in the stage model. This topic uses the switching of **startAbility()** as an example.

![api-switch-overview](figures/api-switch-overview.png)

 

- Sample code of **startAbility()** in the FA model:

  ```ts
  import featureAbility from '@ohos.ability.featureAbility';
  import Want from '@ohos.app.ability.Want';
  import hilog from '@ohos.hilog';
  
  const TAG: string = 'PagePageAbilityFirst';
  const domain: number = 0xFF00;
  
  @Entry
  @Component
  struct PagePageAbilityFirst {
    
    build() {
      Column() {
        List({ initialIndex: 0 }) {
          ListItem() {
            Flex({ justifyContent: FlexAlign.SpaceBetween, alignContent: FlexAlign.Center }) {
              //...
            }
            .onClick(() => {
              (async (): Promise<void> => {
                try {
                  hilog.info(domain, TAG, 'Begin to start ability');
                  let want: Want = {
                    bundleName: 'com.samples.famodelabilitydevelop',
                    moduleName: 'entry',
                    abilityName: 'com.samples.famodelabilitydevelop.PageAbilitySingleton'
                  };
                  await featureAbility.startAbility({ want: want });
                  hilog.info(domain, TAG, `Start ability succeed`);
                }
                catch (error) {
                  hilog.error(domain, TAG, 'Start ability failed with ' + error);
                }
              })()
            })
          }
          //...
        }
        //...
      }
      //...
    }
  }

  ```

- Sample code of **startAbility()** in the stage model:

  ```ts
  import hilog from '@ohos.hilog';
  import Want from '@ohos.app.ability.Want';
  import common from '@ohos.app.ability.common';
  import { BusinessError } from '@ohos.base';
  import { Caller } from '@ohos.app.ability.UIAbility';

  const TAG: string = '[Page_UIAbilityComponentsInteractive]';
  const DOMAIN_NUMBER: number = 0xFF00;
  
  @Entry
  @Component
  struct Page_UIAbilityComponentsInteractive {
    private context = getContext(this) as common.UIAbilityContext;
    caller: Caller | undefined = undefined;
    build() {
      Column() {
        //...
        List({ initialIndex: 0 }) {
          ListItem() {
            Row() {
              //...
            }
            .onClick(() => {
              // Context is a member of the ability object and is required for invoking inside a non-ability object.
              // Pass in the Context object.
              let wantInfo: Want = {
                deviceId: '', // An empty deviceId indicates the local device.
                bundleName: 'com.samples.stagemodelabilitydevelop',
                moduleName: 'entry', // moduleName is optional.
                abilityName: 'FuncAbilityA',
                parameters: { // Custom information.
                  info: 'From the UIAbilityComponentsInteractive page of EntryAbility',
                },
              };
              // context is the UIAbilityContext of the initiator UIAbility.
              this.context.startAbility(wantInfo).then(() => {
                hilog.info(DOMAIN_NUMBER, TAG, 'startAbility success.');
              }).catch((error: BusinessError) => {
                hilog.error(DOMAIN_NUMBER, TAG, 'startAbility failed.');
              });
            })
          }
          //...
        }
        //...
      }
      //...
    }
  }
  ```
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: api-switch-overview.png
###Image description: The image shows a code snippet written in a syntax that appears to be a mix of JavaScript and TypeScript, with some annotations and comments in Chinese. The code snippet is part of a function definition, specifically for a function named `startAbility`. The function is designed to start a new ability within a system capability framework.

Here is a detailed description of the image:

### Code Snippet Breakdown:

1. **Function Definition:**
   - The function is named `startAbility`.
   - It takes two parameters:
     - `parameter`: of type `StartAbilityParameter`.
     - `callback`: of type `AsyncCallback<number>` or `Promise<number>`.

2. **Annotations and Comments:**
   - The function is marked with a comment block at the beginning, which includes several annotations and a brief description of the function's purpose.
   - The comment block is written in Chinese and provides the following information:
     - The function starts a new ability.
     - It has been available since version 6.
     - It uses the `SystemCapability.Ability.AbilityRuntime.FAModel` system capability.
     - It takes a parameter indicating the ability to start.
     - It returns a value, which is annotated with `@FAModelOnly`.

3. **Annotations:**
   - `@since 6`: Indicates that the function was introduced in version 6.
   - `@syscap SystemCapability.Ability.AbilityRuntime.FAModel`: Specifies the system capability used by the function.
   - `@param parameter Indicates the ability to start`: Describes the purpose of the `parameter` parameter.
   - `@return - @FAModelOnly`: Indicates that the return value is related to the `FAModelOnly` system capability.

4. **Function Signatures:**
   - The function has two signatures:
     - The first signature uses an `AsyncCallback<number>` as the callback parameter.
     - The second signature uses a `Promise<number>` as the callback parameter.

### Analysis:

The `startAbility` function is part of a system capability framework, likely for managing and starting abilities within an application. The use of `SystemCapability.Ability.AbilityRuntime.FAModel` suggests that it is related to the runtime management of abilities within a system.

The annotations provide important information about the function's usage and dependencies. The `@since 6` annotation indicates that the function was introduced in version 6, which is useful for developers who need to understand the version history of the function.

The `@param` annotation clarifies that the `parameter` parameter is used to indicate the ability to start, which is essential for developers to understand how to use the function correctly.

The `@return` annotation with `@FAModelOnly` suggests that the return value is specific to the `FAModelOnly` system capability, which might be related to a particular model or state within the system.

The presence of both `AsyncCallback<number>` and `Promise<number>` signatures indicates that the function can be used in both synchronous and asynchronous contexts, providing flexibility to developers.

### Conclusion:

This code snippet is part of a system capability framework for managing abilities within an application. The `startAbility` function is designed to start a new ability and takes a parameter indicating the ability to start. It returns a value related to the `FAModelOnly` system capability. The annotations provide important information about the function's usage and dependencies, making it easier for developers to understand and use the function effectively.
