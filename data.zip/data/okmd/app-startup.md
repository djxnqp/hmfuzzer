# AppStartup


## Overview

During application initialization, a series of startup tasks are triggered. If these tasks are concentratedly placed within the [onCreate](../reference/apis-ability-kit/js-apis-app-ability-uiAbility.md#uiabilityoncreate) lifecycle of the [UIAbility](../reference/apis-ability-kit/js-apis-app-ability-uiAbility.md) of the application's main module ([module](../quick-start/application-package-overview.md#module-types) of the entry type), they must be executed sequentially on the main thread, which significantly affects the application launch speed. In addition, when there are too many tasks, complex dependencies between them make the code difficult to maintain.

AppStartup offers an efficient approach to application initialization. By enabling the asynchronous initiation of startup tasks, it ensures a smoother startup process. The centralized configuration of task execution order and interdependencies in a single file simplifies and clarifies the startup codebase, enhancing maintainability.

AppStartup supports startup tasks in automatic or manual mode. By default, the automatic mode is used. During the creation of an [AbilityStage](../reference/apis-ability-kit/js-apis-app-ability-abilityStage.md), the configured startup tasks are loaded and executed in automatic mode. You can also call [startupManager.run](../reference/apis-ability-kit/js-apis-app-appstartup-startupManager.md#startupmanagerrun) to execute the startup tasks in manual mode after a UIAbility is created.

**Figure 1** Startup procedure

![app-startup-procedure](figures/app-startup-procedure.png)

## Constraints

- AppStartup can be used only in the UIAbility of an entry [module](../quick-start/application-package-overview.md#module-types).

- Circular dependencies are not allowed between startup tasks.

## Development Process

1. [Defining an AppStartup Configuration File](#defining-an-appstartup-configuration-file): Create an AppStartup configuration file in the resource file directory, add the configuration about startup tasks, and reference the configuration file in [module.json5](../quick-start/module-configuration-file.md).
2. [Setting Startup Parameters](#setting-startup-parameters): In the startup parameter file, set parameters such as the timeout interval and startup task listener.
3. [Adding a Startup Task for Each Component to Be Initialized](#adding-a-startup-task-for-each-component-to-be-initialized): Implement the [StartupTask](../reference/apis-ability-kit/js-apis-app-appstartup-startupTask.md) interface.

## How to Develop

### Defining an AppStartup Configuration File

1. Create a AppStartup configuration file in the **resources/base/profile** directory of the application's main module ([module](../quick-start/application-package-overview.md#module-types) of the entry type). The file name can be customized. The following uses **startup_config.json** as an example.

2. In the **startup_config.json** file, add the configuration for each startup task in sequence.

    It is assumed that the application has six startup tasks. The dependencies between the tasks are shown in the figure below. To facilitate concurrent execution of startup tasks, a startup task file should contain only one startup task. In this example, each startup task corresponds to a startup task file.

    **Figure 2** Dependencies between startup tasks
    
    ![app-startup](figures/app-startup.png) 
    
    1. In the **ets/startup** directory, create six startup task files and a common startup parameter file. The file names must be unique.
    
        1. Create six startup task files. In this example, the six files are named from **StartupTask_001.ets** to **StartupTask_006.ets**.
        2. Create a startup parameter file. In this example, the file name is **StartupConfig.ets**.
        
    2. Add the information about the startup task files and startup parameter file to the **startup_config.json** file.
    
        The following is an example of the **startup_config.json** file:
        
        ```json
        {
          "startupTasks": [
            {
              "name": "StartupTask_001",
              "srcEntry": "./ets/startup/StartupTask_001.ets",
              "dependencies": [
                "StartupTask_002",
                "StartupTask_003"
              ],
              "runOnThread": "taskPool",
              "waitOnMainThread": false
            },
            {
              "name": "StartupTask_002",
              "srcEntry": "./ets/startup/StartupTask_002.ets",
              "dependencies": [
                "StartupTask_004"
              ],
              "runOnThread": "taskPool",
              "waitOnMainThread": false
            },
            {
              "name": "StartupTask_003",
              "srcEntry": "./ets/startup/StartupTask_003.ets",
              "dependencies": [
                "StartupTask_004"
              ],
              "runOnThread": "taskPool",
              "waitOnMainThread": false
            },
            {
              "name": "StartupTask_004",
              "srcEntry": "./ets/startup/StartupTask_004.ets",
              "runOnThread": "taskPool",
              "waitOnMainThread": false
            },
            {
              "name": "StartupTask_005",
              "srcEntry": "./ets/startup/StartupTask_005.ets",
              "dependencies": [
                "StartupTask_006"
              ],
              "runOnThread": "mainThread",
              "waitOnMainThread": true,
              "excludeFromAutoStart": true
            },
            {
              "name": "StartupTask_006",
              "srcEntry": "./ets/startup/StartupTask_006.ets",
              "runOnThread": "mainThread",
              "waitOnMainThread": false,
              "excludeFromAutoStart": true
            }
          ],
          "configEntry": "./ets/startup/StartupConfig.ets"
        }
        ```
    
        **Table 1** Fields in the startup_config.json file

        | Field| Description| Data Type| Default Value Allowed|
        | -------- | -------- | -------- | -------- |
        | startupTasks | Configuration about the startup tasks. For details, see the following table.| Object array| No|
        | configEntry | Path of the startup parameter file.| String| No|
        
        
        **Table 2** Description of startupTasks

        | Field| Description| Data Type| Default Value Allowed|
        | -------- | -------- | -------- | -------- |
        | name | Class name of the startup task.| String| No|
        | srcEntry | Path of the file corresponding to the startup task.| String| No|
        | dependencies | Array holding the class names of other startup tasks on which the startup task depends.| Object array| Yes (initial value: left empty)|
        | excludeFromAutoStart | Whether to exclude the automatic mode. For details, see [Changing the Startup Mode](#optional-changing-the-startup-mode).<br>- **true**: manual mode.<br>- **false**: automatic mode.| Boolean| Yes (initial value: **false**)|
        | runOnThread | Thread where the startup task is executed.<br>- **mainThread**: executed in the main thread.<br>- **taskPool**: executed in an asynchronous thread.| String| Yes (initial value: **mainThread**)|
        | waitOnMainThread | Whether the main thread needs to wait until the startup task finishes execution. This parameter is valid only when **runOnThread** is set to **taskPool**.<br>- **true**: The main thread loads the application home page only the startup task finishes execution.<br>- **false**: The main thread does not wait for the startup task to finish execution.| Boolean| Yes (initial value: **true**)|
        

3. Add the index of the AppStartup configuration file to the **appStartup** tag in the [module.json5 file](../quick-start/module-configuration-file.md).

    The following is an example of the **module.json5** file:

    ```json
    {
    "module": {
    "name": "entry",
    "type": "entry",
    // ...
    "appStartup": "$profile:startup_config," // AppStartup configuration file
    // ...
    }
    }
    ```

### Setting Startup Parameters

In the startup parameter file (**ets/startup/StartupConfig.ets** in this example), call [StartupConfigEntry](../reference/apis-ability-kit/js-apis-app-appstartup-startupConfigEntry.md) to set the common AppStartup parameters, including the timeout interval and listener.

- [StartupConfig](../reference/apis-ability-kit/js-apis-app-appstartup-startupConfig.md): sets the task timeout interval and AppStartup listener.
- [StartupListener](../reference/apis-ability-kit/js-apis-app-appstartup-startupListener.md): listens for the execution result of the startup task.

```ts
import { StartupConfig, StartupConfigEntry, StartupListener } from '@kit.AbilityKit';
import { hilog } from '@kit.PerformanceAnalysisKit';
import { BusinessError } from '@kit.BasicServicesKit';

export default class MyStartupConfigEntry extends StartupConfigEntry {
  onConfig() {
    hilog.info(0x0000, 'testTag', `onConfig`);
    let onCompletedCallback = (error: BusinessError<void>) => {
      hilog.info(0x0000, 'testTag', `onCompletedCallback`);
      if (error) {
        hilog.info(0x0000, 'testTag', 'onCompletedCallback: %{public}d, message: %{public}s', error.code, error.message);
      } else {
        hilog.info(0x0000, 'testTag', `onCompletedCallback: success.`);
      }
    };
    let startupListener: StartupListener = {
      'onCompleted': onCompletedCallback
    };
    let config: StartupConfig = {
      'timeoutMs': 10000,
      'startupListener': startupListener
    };
    return config;
  }
}
```

### Adding a Startup Task for Each Component to Be Initialized

Through the preceding operations, you have configured the AppStartup configuration file and startup parameters. Now you need to implement [StartupTask](../reference/apis-ability-kit/js-apis-app-appstartup-startupTask.md) in each startup task file by calling the following two APIs:

- [init](../reference/apis-ability-kit/js-apis-app-appstartup-startupTask.md#startuptaskinit): starts task initialization. Call **init** to initialize a task only after all startup tasks on which the task depends are executed, that is, after **onDependencyCompleted** is invoked.
- [onDependencyCompleted](../reference/apis-ability-kit/js-apis-app-appstartup-startupTask.md#startuptaskondependencycompleted): invoked when the startup task on which the current task depends is complete.


The following uses the **StartupTask_001.ets** file in [startup_config.json](#defining-an-appstartup-configuration-file) as an example. You must add a startup task for each component to be initialized.

> **NOTE**
> 
> **StartupTask** follows the [Sendable protocol](../arkts-utils/arkts-sendable.md#sendable-protocol). Therefore, the Sendable annotation must be added when this API is inherited.

```ts
import { StartupTask, common } from '@kit.AbilityKit';
import { hilog } from '@kit.PerformanceAnalysisKit';

@Sendable
export default class StartupTask_001 extends StartupTask {
  constructor() {
    super();
  }

  async init(context: common.AbilityStageContext) {
    hilog.info(0x0000, 'testTag', 'StartupTask_001 init.');
    return 'StartupTask_001';
  }

  onDependencyCompleted(dependence: string, result: Object): void {
    hilog.info(0x0000, 'testTag', 'StartupTask_001 onDependencyCompleted, dependence: %{public}s, result: %{public}s',
      dependence, JSON.stringify(result));
  }
}
```

### (Optional) Changing the Startup Mode

AppStartup provides automatic and manual mode. By default, the automatic mode is used. However, you can change the mode to manual as required.

- Automatic mode: After an AbilityStage is created, the startup task is automatically executed.
- Manual mode: After a UIAbility is created, you need to manually call the API to execute the startup task. Modules that are infrequently used do not need to be initialized when the application is started. You can change the startup mode of these modules to manual. After the application is started, you can call [startupManager.run](../reference/apis-ability-kit/js-apis-app-appstartup-startupManager.md#startupmanagerrun) to execute the startup task.

The following uses the **onCreate** lifecycle of the UIAbility as an example to describe how to manually trigger a startup task. The sample code is as follows:

```ts
import { AbilityConstant, UIAbility, Want, startupManager } from '@kit.AbilityKit';
import { hilog } from '@kit.PerformanceAnalysisKit';
import { BusinessError } from '@kit.BasicServicesKit';

export default class EntryAbility extends UIAbility {
  onCreate(want: Want, launchParam: AbilityConstant.LaunchParam): void {
    hilog.info(0x0000, 'testTag', '%{public}s', 'Ability onCreate');
    let startParams = ['StartupTask_005', 'StartupTask_006'];
    try {
      startupManager.run(startParams).then(() => {
        console.log('StartupTest startupManager run then, startParams = ');
      }).catch((error: BusinessError) => {
        console.info("StartupTest promise catch error, error = " + JSON.stringify(error));
        console.info("StartupTest promise catch error, startParams = "
          + JSON.stringify(startParams));
      })
    } catch (error) {
      let errMsg = JSON.stringify(error);
      let errCode: number = error.code;
      console.log('Startup catch error , errCode= ' + errCode);
      console.log('Startup catch error ,error= ' + errMsg);
    }
  }

  // ...
}
```

You can also call the API to trigger the manual mode after a page is loaded. The sample code is as follows:

```ts
import { startupManager } from '@kit.AbilityKit';

@Entry
@Component
struct Index {
  @State message: string = 'Manual Mode'
  @State startParams: Array<string> = ['StartupTask_006'];

  build() {
    RelativeContainer() {
      Button(this.message)
        .id('AppStartup')
        .fontSize(20)
        .fontWeight(FontWeight.Bold)
        .onClick(() => {
          if (!startupManager.isStartupTaskInitialized("StartupTask_006")) { // Check whether the startup task finishes execution.
            startupManager.run(this.startParams)
          }
        })
        .alignRules({
          center: {anchor: '__container__', align: VerticalAlign.Center},
          middle: {anchor: '__container__', align: HorizontalAlign.Center}
        })
    }
    .height('100%')
    .width('100%')
  }
}
```

#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: app-startup-procedure.png
###Image description: The image is a flowchart that outlines the process of creating a process, application, and ability stage, followed by a decision-making process to determine whether the application should be executed in automatic or manual mode. Here is a detailed description of the flowchart:

1. **Start**: The process begins with the start node, indicating the beginning of the flowchart.

2. **Create process**: The next step is to create a process. This involves setting up the basic structure or framework for the application.

3. **Create application**: Following the creation of the process, the next step is to create an application. This involves defining the application's functionality and features.

4. **Create AbilityStage**: After creating the application, the next step is to create an AbilityStage. This stage is likely where the application's user interface is defined and where the application's functionality is executed.

5. **Read AppStartup configuration file**: The flowchart then moves to reading the AppStartup configuration file. This file likely contains settings and configurations necessary for the application's startup process.

6. **Perform topological sort on all startup tasks**: The next step involves performing a topological sort on all startup tasks. This is a process used to determine the order in which tasks should be executed, ensuring that dependencies are met.

7. **Is automatic mode used?**: The flowchart then branches into two paths based on whether automatic mode is used. This decision is crucial as it determines how the application will be executed.

8. **Automatic mode**: If automatic mode is used, the tasks will run automatically. This means that the application will start and execute tasks without user intervention. The flowchart then proceeds to describe how the tasks will be executed in automatic mode.

9. **Manual mode**: If automatic mode is not used, the tasks will be executed in manual mode. This means that the application will start and execute tasks after a UIAbility is created and the startup API is called. The flowchart then proceeds to describe how the tasks will be executed in manual mode.

10. **End**: The final step in the flowchart is to end the process, indicating the completion of the application's startup and execution.

### Analysis and Description

The flowchart is a structured representation of the steps involved in creating and executing an application. It begins with the creation of a process, followed by an application and an AbilityStage. The next step involves reading configuration files to ensure that the application starts correctly. The topological sort is performed to determine the order of task execution, which is crucial for ensuring that dependencies are met.

The decision to execute the application in automatic or manual mode is a significant point in the flowchart. Automatic mode allows the application to start and execute tasks without user intervention, which can be useful for applications that need to start immediately upon launch. Manual mode, on the other hand, requires user interaction to start the application and execute tasks, which can be beneficial for applications that need user input before starting.

Overall, the flowchart provides a clear and logical sequence of steps for creating and executing an application, with a decision point that allows for flexibility in how the application is started and executed.
##Image Name: app-startup.png
###Image description: The image depicts a directed graph representing a sequence of startup tasks, each with a specified number of dependencies. The tasks are represented as green rectangles, and the dependencies are indicated by arrows pointing from one task to another. The tasks are labeled as "StartupTask_001" through "StartupTask_006," and each task has a label indicating the number of dependencies it has. The dependencies size is shown in parentheses next to each task label.

Here is a detailed description of the graph:

1. **StartupTask_001**:
   - Dependencies size: 2
   - This task has two dependencies, which are not explicitly shown in the image.

2. **StartupTask_002**:
   - Dependencies size: 2
   - This task also has two dependencies, which are not shown in the image.

3. **StartupTask_003**:
   - Dependencies size: 1
   - This task has one dependency, which is not shown in the image.

4. **StartupTask_004**:
   - Dependencies size: 0
   - This task has no dependencies, indicating it is the starting point of the sequence.

5. **StartupTask_005**:
   - Dependencies size: 1
   - This task has one dependency, which is not shown in the image.

6. **StartupTask_006**:
   - Dependencies size: 0
   - This task has no dependencies, indicating it is the final task in the sequence.

The arrows in the graph indicate the order in which the tasks should be executed. The sequence starts with "StartupTask_004" and ends with "StartupTask_006." The tasks "StartupTask_001" and "StartupTask_002" both have two dependencies, while "StartupTask_003" has one dependency. "StartupTask_005" has one dependency, and "StartupTask_006" has no dependencies.

This graph represents a dependency-based sequence where each task must be completed before proceeding to the next task in the sequence.
