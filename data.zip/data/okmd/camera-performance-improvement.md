# Using Performance Improvement Features (for System Applications Only) (ArkTS)

Before developing a camera application, request permissions by following the instructions provided in [Camera Development Preparations](camera-preparation.md).

The camera startup performance is affected by time-consuming operations such as power-on of underlying components and initialization of the process pipeline. To improve the camera startup speed and thumbnail display speed, OpenHarmony introduces some features. The capabilities of these features are related to underlying components. You need to check whether your underlying components support these capabilities before using the capabilities.

​These features are involved in the processes of starting the camera device, configuring streams, and taking photos. This topic describes the three scenarios.

## Deferred Stream Configuration

A typical camera startup process includes starting the camera device, configuring a data stream, and starting the data stream. Before configuring the data stream, you need to obtain the surface ID of the **XComponent**.

The deferred stream configuration feature decouples stream configuration and start from the surface. Before the **XComponent** provides the surface for the camera application, the system configures and starts the stream. This way, the surface only needs to be available before the stream is started. This improves the startup speed and prevents the implementation of other startup optimization schemas from being affected.

![deferred-surface-scene](figures/deferred-surface-scene.png)

Before optimization: Stream configuration depends on a **Surface** object, which is available after UI loading is complete. In other words, you can create a session, configure input and output streams, and start the session only after the UI is loaded. The camera HDI is responsible for stream configuration.

After optimization: Stream configuration does not depend on the **Surface** object. UI loading and stream configuration are executed concurrently. After the parameters are prepared, you can create a session.

### Available APIs

Read [Camera](../../reference/apis-camera-kit/js-apis-camera.md) for the API reference.

| API| Description|
| ---- | ---- |
| createDeferredPreviewOutput(profile: Profile): Promise\<PreviewOutput> | Creates a deferred **PreviewOutput** instance and adds it, instead of a common **PreviewOutput** instance, to the data stream during stream configuration.|
| addDeferredSurface(surfaceId: string): Promise\<void> | Adds a surface for delayed preview. This API can run after [session.commitConfig](../../reference/apis-camera-kit/js-apis-camera.md#commitconfig11) or [session.start](../../reference/apis-camera-kit/js-apis-camera.md#start11) is called.|

### Development Example

The figure below shows the recommended API call process.

![](figures/deferred-surface-sequence-diagram.png)

For details about how to obtain the context, see [Obtaining the Context of UIAbility](../../application-models/uiability-usage.md#obtaining-the-context-of-uiability).

```ts
import { camera } from '@kit.CameraKit';
import { common } from '@kit.AbilityKit';

async function preview(baseContext: common.BaseContext, cameraInfo: camera.CameraDevice, previewProfile: camera.Profile, photoProfile: camera.Profile, previewSurfaceId: string): Promise<void> {
  const cameraManager: camera.CameraManager = camera.getCameraManager(baseContext);
  const cameraInput: camera.CameraInput = cameraManager.createCameraInput(cameraInfo);
  const previewOutput: camera.PreviewOutput = cameraManager.createDeferredPreviewOutput(previewProfile);
  const photoOutput: camera.PhotoOutput = cameraManager.createPhotoOutput(photoProfile);
  const session: camera.PhotoSession = cameraManager.createSession(camera.SceneMode.NORMAL_PHOTO) as camera.PhotoSession;
  session.beginConfig();
  session.addInput(cameraInput);
  session.addOutput(previewOutput);
  session.addOutput(photoOutput);
  await session.commitConfig();
  await session.start();
  previewOutput.addDeferredSurface(previewSurfaceId);
}
```

## Quick Thumbnail

The photo capture performance depends on the algorithm processing speed. A complex algorithm chain provides better image effect while requiring longer processing time.

To improve the photo capture speed perceived by end users, the quick thumbnail feature is introduced. When the user takes a photo, a thumbnail is output and reported to the camera application for display before a real image is reported.

In this way, the photo capture process is optimized, which fulfills the processing requirements of the post-processing algorithm without blocking the photo capture speed of the foreground.

### Available APIs

Read [Camera](../../reference/apis-camera-kit/js-apis-camera.md) for the API reference.

| API| Description|
| ---- | ---- |
| isQuickThumbnailSupported() : boolean | Checks whether the quick thumbnail feature is supported.|
| enableQuickThumbnail(enabled:bool): void | Enables or disables the quick thumbnail feature.|
| on(type: 'quickThumbnail', callback: AsyncCallback\<image.PixelMap>): void | Listens for camera thumbnails.|

> **NOTE**
>
> - [isQuickThumbnailSupported](../../reference/apis-camera-kit/js-apis-camera-sys.md#isquickthumbnailsupported) and [enableQuickThumbnail](../../reference/apis-camera-kit/js-apis-camera-sys.md#enablequickthumbnail) must be called after [addOutput](../../reference/apis-camera-kit/js-apis-camera.md#addoutput11) and [addInput](../../reference/apis-camera-kit/js-apis-camera.md#addinput11) but before [commitConfig](../../reference/apis-camera-kit/js-apis-camera.md#commitconfig11).
> - The **on** API takes effect after [enableQuickThumbnail(true)](../../reference/apis-camera-kit/js-apis-camera-sys.md#enablequickthumbnail) is called.

### Development Example

The figure below shows the recommended API call process.

![](figures/quick-thumbnail-sequence-diagram.png)

For details about how to obtain the context, see [Obtaining the Context of UIAbility](../../application-models/uiability-usage.md#obtaining-the-context-of-uiability).
```ts
import { camera } from '@kit.CameraKit';
import { BusinessError } from '@kit.BasicServicesKit';
import { image } from '@kit.ImageKit';
import { common } from '@kit.AbilityKit';

async function enableQuickThumbnail(baseContext: common.BaseContext, photoProfile: camera.Profile): Promise<void> {
  let cameraManager: camera.CameraManager = camera.getCameraManager(baseContext);
  let cameras: Array<camera.CameraDevice> = cameraManager.getSupportedCameras();
  // Create a PhotoSession instance.
  let photoSession: camera.PhotoSession = cameraManager.createSession(camera.SceneMode.NORMAL_PHOTO) as camera.PhotoSession;
  // Start configuration for the session.
  photoSession.beginConfig();
  // Add a CameraInput instance to the session.
  let cameraInput: camera.CameraInput = cameraManager.createCameraInput(cameras[0]);
  cameraInput.open();
  photoSession.addInput(cameraInput);
  // Add a PhotoOutput instance to the session.
  let photoOutPut: camera.PhotoOutput = cameraManager.createPhotoOutput(photoProfile);
  photoSession.addOutput(photoOutPut);
  let isSupported: boolean = photoOutPut.isQuickThumbnailSupported();
  if (isSupported) {
    // Enable the quick thumbnail feature.
    photoOutPut.enableQuickThumbnail(true);
    photoOutPut.on('quickThumbnail', (err: BusinessError, pixelMap: image.PixelMap) => {
      if (err || pixelMap === undefined) {
        console.error('photoOutPut on thumbnail failed');
        return;
      }
      // Display or save the PixelMap instance.
      showOrSavePicture(pixelMap);
    });
  }
}

function showOrSavePicture(pixelMap: image.PixelMap): void {
  //do something
}
```

## Prelaunch

Generally, the startup of the camera application is triggered when the user touches the camera icon on the home screen. The home screen senses the touch event and instructs the application manager to start the camera application. This takes a relatively long time. After the camera application is started, the camera startup process starts. A typical camera startup process includes starting the camera device, configuring a data stream, and starting the data stream, which is also time-consuming.

​The prelaunch feature triggers the action of starting the camera device before the camera application is started. In other words, when the user touches the camera icon on the home screen, the system starts the camera device. At this time, the camera application is not started yet. The figure below shows the camera application process before and after the prelaunch feature is introduced.

![prelaunch-scene](figures/prelaunch-scene.png)

### Available APIs

Read [Camera](../../reference/apis-camera-kit/js-apis-camera.md) for the API reference.

| API| Description|
| ---- | ---- |
| isPrelaunchSupported(camera: CameraDevice) : boolean |  Checks whether the camera supports prelaunch.|
| setPrelaunchConfig(prelaunchConfig: PrelaunchConfig) : void | Sets the prelaunch parameters.|
| prelaunch() : void | Prelaunches the camera. This API is called when a user touches the system camera icon to start the camera application.|

### Development Example

The figure below shows the recommended API call process.

![](figures/prelaunch-sequence-diagram.png)

For details about how to obtain the context, see [Obtaining the Context of UIAbility](../../application-models/uiability-usage.md#obtaining-the-context-of-uiability).

- **Home screen**

  ```ts
  import { camera } from '@kit.CameraKit';
  import { BusinessError } from '@kit.BasicServicesKit';
  import { common } from '@kit.AbilityKit';

  function preLaunch(baseContext: common.BaseContext): void {
    let cameraManager: camera.CameraManager = camera.getCameraManager(baseContext);
    try {
      cameraManager.prelaunch();
    } catch (error) {
      let err = error as BusinessError;
      console.error(`catch error: Code: ${err.code}, message: ${err.message}`);
    }
  }
  ```

- **Camera application**

  To use the prelaunch feature, the camera application must configure the **ohos.permission.CAMERA** permission.

  For details about how to request and verify the permissions, see [Requesting User Authorization](../../security/AccessToken/request-user-authorization.md).

  ```ts
  import { camera } from '@kit.CameraKit';
  import { BusinessError } from '@kit.BasicServicesKit';
  import { common } from '@kit.AbilityKit';

  function setPreLaunchConfig(baseContext: common.BaseContext): void {
    let cameraManager: camera.CameraManager = camera.getCameraManager(baseContext);
    let cameras: Array<camera.CameraDevice> = [];
    try {
      cameras = cameraManager.getSupportedCameras();
    } catch (error) {
      let err = error as BusinessError;
      console.error(`getSupportedCameras catch error: Code: ${err.code}, message: ${err.message}`);
    }
    if (cameras.length <= 0) {
      return;
    }
    if(cameraManager.isPrelaunchSupported(cameras[0])) {
      try {
        cameraManager.setPrelaunchConfig({cameraDevice: cameras[0]});
      } catch (error) {
        let err = error as BusinessError;
        console.error(`setPrelaunchConfig catch error: Code: ${err.code}, message: ${err.message}`);
      }
    }
  }
  ```
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: deferred-surface-scene.png
###Image description: The image is a flowchart that illustrates the process of a camera application starting and capturing a first frame. The flowchart is divided into three main sections: Camera app, Camera service, and Camera HDI (High Definition Imaging). The process is depicted as a series of steps and interactions between these components.

### Camera App
1. **User Touches Camera Icon**: The user initiates the process by touching the camera icon.
2. **inputEvent**: An input event is generated.
3. **onCreate**: The onCreate method is called.
4. **onWindowStageCreate**: The onWindowStageCreate method is called.
5. **aboutToAppear**: The aboutToAppear method is called.
6. **XComponent.onLoad**: The XComponent.onLoad method is called.
7. **Camera Service**: The CameraService.getInstance is called to initialize the camera.
8. **setUIContent**: The setUIContent method is called to set the device form page.
9. **Prepare Parameters**: Parameters are prepared for the camera session.
10. **Create Session**: A session is created.
11. **Configure Input Stream**: The input stream is configured.
12. **Configure Output Stream**: The output stream is configured.
13. **Start Session**: The session is started.
14. **Start Preview**: The preview starts.
15. **XComponent**: The XComponent receives the first frame.

### Camera Service
1. **Before Optimization**: The process before optimization is shown.
2. **After Optimization**: The process after optimization is shown.
3. **Create Session**: A session is created.
4. **Configure Input Stream**: The input stream is configured.
5. **Configure Output Stream**: The output stream is configured.
6. **Start Session**: The session is started.
7. **Start Preview**: The preview starts.
8. **XComponent**: The XComponent receives the first frame.

### Camera HDI
1. **Configure Stream & Allocate Buffer**: The stream is configured, and a buffer is allocated.
2. **Deliver Request to Open Device**: A request is delivered to open the device.
3. **Output**: The output is received.
4. **Receive First Frame**: The first frame is received.

### Analysis
The flowchart shows the sequential steps involved in starting a camera application and capturing a first frame. The process begins with the user touching the camera icon, which triggers a series of events and methods in the Camera app. These methods include initializing the camera, setting the device form page, preparing parameters, creating a session, configuring input and output streams, starting the session, and finally starting the preview.

The Camera service then takes over, with steps including creating a session, configuring input and output streams, starting the session, and delivering a request to open the device. The Camera HDI component is responsible for configuring the stream, allocating a buffer, delivering a request to open the device, and outputting the first frame.

### Conclusion
The flowchart effectively illustrates the complex interactions between the user, the camera app, the camera service, and the Camera HDI to capture a first frame. This detailed breakdown helps in understanding the underlying processes and the sequence of events involved in the camera application's functionality.
##Image Name: deferred-surface-sequence-diagram.png
###Image description: The image is a sequence diagram illustrating the process of camera application development using JavaScript APIs. The diagram is divided into two main sections: the left side represents the user interaction and the right side represents the JavaScript APIs for camera application development.

### Left Side: User Interaction
1. **Open Application (Cold Start)**: The user opens the camera application.
2. **SurfaceReady Event**: The camera application receives a SurfaceReady event, indicating that the camera is ready for use.

### Right Side: JavaScript APIs for Camera Application Development
1. **createSession(sceneMode)**: The application creates a session with a specified scene mode.
2. **createCameraInput()**: The application creates a camera input.
3. **createDeferredPreviewOutput(profile)**: The application creates a deferred preview output with a specified profile.
4. **addInput/addOutput() commitConfig()**: The application adds inputs and outputs and commits the configuration.
5. **addDeferredSurface(surfaceId)**: The application adds a deferred surface with a specified surface ID.
6. **start()**: The application starts the camera session.

### Explanation
The sequence diagram outlines the steps involved in developing a camera application using JavaScript APIs. Here's a detailed breakdown:

1. **Open Application (Cold Start)**: The user initiates the camera application, which is the starting point for the application's execution.

2. **SurfaceReady Event**: Once the application is opened, it receives a SurfaceReady event, indicating that the camera is ready for use. This event is crucial as it signifies that the camera hardware is initialized and ready to capture images or videos.

3. **createSession(sceneMode)**: The application creates a session with a specified scene mode. This step involves setting up the camera session with a predefined mode, such as portrait, landscape, or night mode, which determines the camera's behavior and settings.

4. **createCameraInput()**: The application creates a camera input. This involves setting up the camera's input parameters, such as resolution, frame rate, and other settings that define how the camera captures images or videos.

5. **createDeferredPreviewOutput(profile)**: The application creates a deferred preview output with a specified profile. This step involves configuring the output format and quality of the preview images or videos. The profile can include settings like resolution, compression, and frame rate.

6. **addInput/addOutput() commitConfig()**: The application adds inputs and outputs and commits the configuration. This step involves integrating the camera input and output configurations into the application's overall setup. The commitConfig() function ensures that all configurations are finalized and ready for use.

7. **addDeferredSurface(surfaceId)**: The application adds a deferred surface with a specified surface ID. This step involves associating the camera output with a specific surface, which is typically a graphical surface where the camera preview or captured images are displayed.

8. **start()**: The application starts the camera session. This final step initiates the camera capture process, allowing the application to start capturing images or videos based on the configured settings.

### Conclusion
The sequence diagram provides a clear and structured overview of the steps involved in developing a camera application using JavaScript APIs. Each step is crucial for ensuring that the camera application is properly configured and ready for use. Understanding these steps is essential for developers working on camera applications to ensure optimal performance and functionality.
##Image Name: quick-thumbnail-sequence-diagram.png
###Image description: The image is a sequence diagram illustrating the process of developing a camera application. The diagram is divided into two main sections: the left side represents the user interaction, and the right side represents the development process of the camera application.

### Left Side: User Interaction
1. **Open Application**: The user opens the camera application.
2. **Capture Photo**: The user takes a photo.

### Right Side: Camera Application Development
The right side of the diagram is divided into three main components: **CaptureSession**, **CameraManager**, and **PhotoOutput**.

#### 1. CaptureSession
1. **createSession(sceneMode)**: Creates a session with a specified scene mode.
2. **createCameraInput()**: Creates a camera input.
3. **createPhotoOutput()**: Creates a photo output.
4. **beginConfig()**: Begins the configuration process.
5. **addInput()**: Adds the camera input to the configuration.
6. **addOutput()**: Adds the photo output to the configuration.
7. **isQuickThumbnailSupported()**: Checks if quick thumbnail support is enabled.
8. **enableQuickThumbnail(true)**: Enables quick thumbnail support.
9. **commitConfig()**: Commits the configuration.
10. **start()**: Starts the camera session.

#### 11. PhotoOutput
11. **capture(setting)**: Captures a photo with the specified settings.

#### 12. Return State
12. **Return state**: Returns the state of the camera session.

#### 13. QuickThumbnail
13. **quickThumbnail(thumbnail: PixelMap)**: Generates a quick thumbnail from the captured photo.

#### 14. Return Real Image
14. **Return real image**: Returns the real image of the captured photo.

### Summary
The sequence diagram outlines the steps involved in developing a camera application, from the user opening the application to capturing a photo and generating a quick thumbnail. The diagram emphasizes the interaction between the user and the application, as well as the internal processes involved in capturing and processing the photo.
##Image Name: prelaunch-scene.png
###Image description: The image consists of two diagrams labeled "Typical camera start" and "Camera prelaunch," each illustrating the process flow of a camera application from a software layer to a hardware layer. Both diagrams are structured in a flowchart format, with arrows indicating the sequence of steps.

### Typical Camera Start
1. **Software Layer:**
   - **Touch camera icon:** The user interacts with the camera icon.
   - **Open camera app:** The camera application is launched.
   - **Start camera device:** The camera device is initialized.
   - **Configure data stream:** The data stream is set up.
   - **Request output:** The camera requests output.
   - **Refresh preview:** The preview is refreshed.
   - **Output image:** The image is outputted.

2. **Hardware Layer:**
   - **Power on components:** Components are powered on.
   - **Configure pipeline:** The pipeline is configured.
   - **Start stream:** The stream is started.
   - **Output image:** The image is outputted.

### Camera Prelaunch
1. **Software Layer:**
   - **Touch camera icon:** The user interacts with the camera icon.
   - **Open camera app:** The camera application is launched.
   - **Configure data stream:** The data stream is set up.
   - **Request output:** The camera requests output.
   - **Refresh preview:** The preview is refreshed.
   - **Output image:** The image is outputted.

2. **Hardware Layer:**
   - **Power on components:** Components are powered on.
   - **Configure pipeline:** The pipeline is configured.
   - **Start stream:** The stream is started.
   - **Output image:** The image is outputted.

### Analysis
The diagrams highlight the differences in the camera start process between a typical scenario and a prelaunch scenario. In the typical camera start, the camera device is initialized after the camera app is opened, whereas in the camera prelaunch, the camera device is preinitialized before the camera app is opened. This preinitialization allows for faster camera startup and improved performance.

### Chain of Thought (CoT)
1. **Understanding the Process Flow:**
   - Both diagrams follow a similar flow from software to hardware.
   - The software layer involves user interaction, application launch, and configuration of the data stream.
   - The hardware layer involves powering on components, configuring the pipeline, starting the stream, and outputting the image.

2. **Identifying Differences:**
   - In the typical camera start, the camera device is initialized after the camera app is opened.
   - In the camera prelaunch, the camera device is preinitialized before the camera app is opened.

3. **Implications:**
   - Preinitialization can lead to faster camera startup times.
   - It may also improve the overall performance and user experience by reducing latency.

By understanding these diagrams, one can appreciate the importance of preinitialization in camera applications and how it can enhance the user experience.
##Image Name: prelaunch-sequence-diagram.png
###Image description: The image is a sequence diagram illustrating the process of system app development, specifically focusing on the interaction between the user, system app development, and JavaScript APIs for app development. The diagram is divided into two main sections: "System app development" and "JS APIs for app development."

### System App Development Section
1. **User**: The user interacts with the system app.
2. **Home screen**: The user is on the home screen.
3. **System camera app**: The user opens the system camera app.
4. **Foreground app opened**: The system camera app is opened in the foreground.
5. **App enters background**: The system camera app enters the background.
6. **Touch camera icon on home screen**: The user touches the camera icon on the home screen.
7. **Identify system camera**: The system app identifies the system camera.
8. **Prelaunch available only for system camera**: The system app checks if prelaunch is available only for the system camera.
9. **[System camera] preLaunch()**: The system camera app performs prelaunch.
10. **Start prelaunch**: The prelaunch process starts.

### JS APIs for App Development Section
1. **CameraManager**: The CameraManager API is used for app development.
2. **Enter prelaunch logic, e.g. prelaunch background**: The app enters prelaunch logic, such as prelaunch background.
3. **isPreLaunchSupported (background)**: The app checks if prelaunch is supported in the background.
4. **Return: prelaunch support status**: The app returns the prelaunch support status.
5. **[Prelaunch supported]**: If prelaunch is supported, the app proceeds with prelaunch.
6. **setPreLaunchConfig (background)**: The app sets prelaunch configuration in the background.
7. **Start prelaunch**: The prelaunch process starts.

### Summary
The diagram outlines the steps involved in system app development, particularly focusing on the prelaunch process for the system camera app. The user interacts with the system app, which then checks for prelaunch support and configuration before starting the prelaunch process. The JS APIs for app development are utilized to manage the prelaunch logic and configuration.
