# Creating a Grid (Grid/GridItem)


## Overview

The grid layout consists of cells formed by rows and columns. You can specify the cells where items are located to create various layouts. The grid layout excels at dividing a page into regions and defining the proportion of child components. It is a key adaptive layout and applies to scenarios such as photo gallery, calendar, and calculator.

ArkUI provides the [Grid](../reference/apis-arkui/arkui-ts/ts-container-grid.md) and [GridItem](../reference/apis-arkui/arkui-ts/ts-container-griditem.md) components for building grid layouts. **Grid** is a container for defining the grid layout, while **GridItem** is a child component in the container. The **Grid** component allows creation of child components using methods such as [if/else](../quick-start/arkts-rendering-control-ifelse.md), [ForEach](../quick-start/arkts-rendering-control-foreach.md), and [LazyForEach](../quick-start/arkts-rendering-control-lazyforeach.md).


## Layout and Constraints

Each item in the **Grid** container corresponds to a **GridItem** component, as shown below.

**Figure 1** Relationship between Grid and GridItem components

![en-us_image_0000001511900472](figures/en-us_image_0000001511900472.png)

>**NOTE**
>
>The **Grid** component accepts only **GridItem** as its child.

The grid layout is a two-dimensional layout. The **Grid** component allows you to define the number of rows and columns, proportion of each row and column, number of rows or columns that child components span, and the horizontal and vertical alignment. When it has its size changed, its child components and spacing are adjusted proportionally. By leveraging these layout capabilities, you can build grid layouts of different styles, as shown below.

**Figure 2** Grid layout

![en-us_image_0000001562700473](figures/en-us_image_0000001562700473.png)

The size of the **Grid** component follows its width and height settings (if configured) or adapts to the size of its parent component.

Depending on the settings of the quantity and proportion of rows and columns, the **Grid** component behaves as follows:

- If both the quantity and proportion are set for rows or columns, the **Grid** component displays elements only in the set number of rows or columns, and it cannot be scrolled. (This layout mode is recommended.)

- If only the quantity or proportion is set for rows or columns, the **Grid** component lays out elements in the specified direction, and it can be scrolled to display excess elements.

- If neither the quantity nor the proportion is set for rows or columns, the **Grid** component lays out elements in the layout direction. The number of rows and columns is determined by the layout direction and the width and height of the grid. Elements that exceed the range of rows and columns are not displayed, and the **Grid** component cannot be scrolled.


## Setting the Arrangement Mode


### Setting the Number and Proportion of Rows and Columns

You can set the number and proportion of rows and columns to determine the overall arrangement mode of the grid layout. To do so, use the **rowsTemplate** and **columnsTemplate** attributes of the **Grid** component.

The values of **rowsTemplate** and **columnsTemplate** are a string consisting of 'number+fr' segments, separated by spaces. Wherein **fr** indicates the number of rows or columns in the grid layout, and the number in front of **fr** is used to calculate the proportion of the row or column in the grid width, thereby determining the width of the row or column.

**Figure 3** Example of the proportion of rows and columns

![en-us_image_0000001562820833](figures/en-us_image_0000001562820833.png)

The preceding figure shows a grid layout with three rows and three columns. The grid layout is divided into three parts in the vertical direction with each row taking up 1/3, and four parts in the horizontal direction with the first column taking up 1/4, the second column 2/4, and the third column 1/4.

This layout can be implemented by setting **rowsTemplate** to **'1fr 1fr 1fr'** and **columnsTemplate** to **'1fr 2fr 1fr'**.


```ts
Grid() {
  ...
}
.rowsTemplate('1fr 1fr 1fr')
.columnsTemplate('1fr 2fr 1fr')
```

>**NOTE**
>
>When **rowsTemplate** or **columnsTemplate** is set for the **Grid** component, its **layoutDirection**, **maxCount**, **minCount**, and **cellLength** attributes do not take effect. For details about the attributes, see [Grid Attributes](../reference/apis-arkui/arkui-ts/ts-container-grid.md#attributes).


### Setting the Number of Rows and Columns Occupied by a Child Component

In real-world applications, an uneven grid layout, where grid cells span a varying number of cells and rows, is as common as its even counterpart. To allow a single grid cell in a grid to span multiple rows or columns, passing appropriate [GridLayoutOptions](../reference/apis-arkui/arkui-ts/ts-container-grid.md#gridlayoutoptions10) when creating the grid. Use **irregularIndexes** and **onGetIrregularSizeByIndex** for grids with only **rowsTemplate** or **columnsTemplate**, and **onGetRectByIndex** for grids with both.

**Figure 4** Uneven grid layout

![en-us_image_0000001511900480](figures/en-us_image_0000001511900480.png)

A common application with an uneven grid layout is the calculator. As shown in the following figure, the **0** key spans the first and second columns, and the **=** key spans the fifth and sixth rows. For a grid layout created using the **Grid** component, the row and column numbers start from 0 and increase incrementally.

**Figure 5** Calculator 

![en-us_image_0000001511421292](figures/en-us_image_0000001511421292.png)

In the grid, use the **onGetRectByIndex** callback to return the array [rowStart, columnStart, rowSpan, columnSpan] to achieve a layout that spans rows and columns, wherein **rowStart** and **rowEnd** indicate the start and end row numbers of the current element, and **columnStart** and **columnEnd** indicate the start and end column numbers of the current element.

To make the **0** key span across the first and second columns, and the **=** key span across the fifth and sixth rows, set **onGetRectByIndex** for **0** and **=** as follows: for **0**, set **rowStart** and **columnStart** at **5** and **0**, and **rowSpan** and **columnSpan** at **1** and **2**; for **=**, set **rowStart** and **columnStart** at **4** and **3**, and **rowSpan** and **columnSpan** at **2** and **1**.


```ts
layoutOptions: GridLayoutOptions = {
  regularSize: [1, 1],
  onGetRectByIndex: (index: number) => {
    if (index = = key1) { // key1 is the index of the 0 key.
      return [5, 0, 1, 2]
    } else if (index == key2) { // key2 is the index of the = key.
      return [4, 3, 2, 1]
    }
    // ...
    // Here, you need to return the positions of other items based on the specific layout.
  }
}

Grid(undefined, this.layoutOptions) {
  // ...
}
.columnsTemplate('1fr 1fr 1fr 1fr')
.rowsTemplate('2fr 1fr 1fr 1fr 1fr 1fr')
```


### Setting the Main Axis Direction

When neither the number nor proportion is set for rows and columns in a grid layout, you can use the **layoutDirection** attribute to set the main axis direction and thereby specify the arrangement mode of child components. In addition, you can use the **minCount** and **maxCount** attributes to restrict the number of grid cells along the main axis.

**Figure 6** Main axis direction 

![en-us_image_0000001562700469](figures/en-us_image_0000001562700469.png)

When **layoutDirection** is set to **Row**, child components are arranged from left to right. When a row is full, a new row is added. When **layoutDirection** is set to **Column**, child components are arranged from top to bottom. When a column is full, a new column is added. In this example, the **maxCount** attribute is set to **3**, indicating that the maximum number of grid cells displayed along the main axis is 3.


```ts
Grid() {
  ...
}
.maxCount(3)
.layoutDirection(GridDirection.Row)
```

>**NOTE**
>
>- The **layoutDirection** attribute takes effect only when **rowsTemplate** and **columnsTemplate** are not set. In this case, child components are arranged in the direction set by **layoutDirection**.
>- When only **rowsTemplate** is set, the main axis of the grid runs in the horizontal direction, and the cross axis runs in the vertical direction.
>- When only **columnsTemplate** is set, the main axis of the grid runs in the vertical direction, and the cross axis runs in the horizontal direction.


## Displaying Data in a Grid Layout

The grid layout organizes its internal elements in two-dimensional layout mode, as shown in the following figure.

**Figure 7** General office services 

![en-us_image_0000001563060729](figures/en-us_image_0000001563060729.png)

The **Grid** component can display a group of **GridItem** child components in two-dimensional layout mode.


```ts
Grid() {
  GridItem() {
    Text('Conference')
      ...
  }

  GridItem() {
    Text('Sign-in')
      ...
  }

  GridItem() {
    Text('Vote')
      ...
  }

  GridItem() {
    Text('Print')
      ...
  }
}
.rowsTemplate('1fr 1fr')
.columnsTemplate('1fr 1fr')
```

For multiple **GridItem** components with similar content structures, you are advised to nest them in **ForEach** statements to reduce repeated code.


```ts
@Entry
@Component
struct OfficeService {
  @State services: Array<string> = ['Conference', 'Vote','Sign-in', 'Print']

  build() {
    Column() {
      Grid() {
        ForEach(this.services, (service:string) => {
          GridItem() {
            Text(service)
          }
        }, (service:string):string => service)
      }
      .rowsTemplate(('1fr 1fr') as string)
      .columnsTemplate(('1fr 1fr') as string)
    }
  }
}
```


## Setting the Gap Between Rows and Columns

The horizontal spacing between two grid cells is called row spacing, and the vertical spacing is called column spacing, as shown in the following figure.

**Figure 8** Row spacing and column spacing 

![en-us_image_0000001511580908](figures/en-us_image_0000001511580908.png)

You can use **rowsGap** and **columnsGap** to set the row spacing and column spacing of the grid layout. In the calculator shown in Figure 5, the row spacing is 15 vp, and the column spacing is 10vp.


```ts
Grid() {
  ...
}
.columnsGap(10)
.rowsGap(15)
```


## Building a Scrollable Grid Layout

The scrollable grid layout is often used on the file list, product list, video list, and similar pages, as shown in the following figure. When only the number or proportion is set for rows and columns, that is, only the **rowsTemplate** or **columnsTemplate** attribute is set, the elements in the grid are arranged in the configured direction. When the content goes beyond the display area, the grid can be scrolled.

**Figure 9** Horizontal scrollable grid layout

![en-us_image_0000001511740512](figures/en-us_image_0000001511740512.gif)

If **columnsTemplate** is set, the grid scrolls vertically. If **rowsTemplate** is set, the grid scrolls horizontally.

In the horizontal scrollable grid layout shown in the preceding figure, **rowsTemplate** is set but **columnsTemplate** is not. When the content exceeds the width of the grid, the grid can scroll horizontally to display the content outside of the display area.


```ts
@Entry
@Component
struct Shopping {
  @State services: Array<string> = ['Live', 'Premium']

  build() {
    Column({ space: 5 }) {
      Grid() {
        ForEach(this.services, (service: string, index) => {
          GridItem() {
          }
          .width('25%')
        }, (service:string):string => service)
      }
      .rowsTemplate('1fr 1fr') // Set only the rowsTemplate attribute. When the content exceeds the display area of the grid, the grid can be scrolled horizontally.
      .rowsGap(15)
    }
  }
}
```


## Controlling the Scrolling Position

Similar to the Back to top button in a list layout, the feature of controlling the scrolling position is commonly used in the grid layout, for example, page turning in the calendar application, as shown below.

**Figure 10** Page turning in the calendar application 

![en-us_image_0000001562940549](figures/en-us_image_0000001562940549.gif)

When the **Grid** component is initialized, it can be bound to a [Scroller](../reference/apis-arkui/arkui-ts/ts-container-scroll.md#scroller) object for scrolling control. In this example, the [scrollPage](../reference/apis-arkui/arkui-ts/ts-container-scroll.md#scrollpage9) API of the **Scroller** object is used to turn pages.


```ts
private scroller: Scroller = new Scroller()
```

On the calendar page, when a user clicks the **Next** button, the application responds to the click event by setting the **next** parameter in the **scrollPage** API to **true** to scroll to the next page.


```ts
Column({ space: 5 }) {
  Grid(this.scroller) {
  }
  .columnsTemplate('1fr 1fr 1fr 1fr 1fr 1fr 1fr')

  Row({space: 20}) {
    Button('Previous')
      .onClick(() => {
        this.scroller.scrollPage({
          next: false
        })
      })

    Button('Next')
      .onClick(() => {
        this.scroller.scrollPage({
          next: true
        })
      })
  }
}
```


## Performance Optimization

Just as [LazyForEach](../quick-start/arkts-rendering-control-lazyforeach.md) is recommended for [handling a long list](arkts-layout-development-create-list.md#handling-a-long-list), it is also recommended for a scrolling grid layout when a large number of grid items is involved.

For details about the implementation, see the example in [LazyForEach: Lazy Data Loading](../quick-start/arkts-rendering-control-lazyforeach.md).

When the grid is rendered in lazy loading mode, to improve the grid scrolling experience and minimize white blocks during grid scrolling, you can use the **cachedCount** parameter of the **Grid** component. This parameter sets the number of grid items preloaded outside of the screen and is valid only in **LazyForEach**.

  Specifically, the number of the grid items to cache before and after the currently displayed one equals the value of **cachedCount** multiplied by the number of columns. Grid items that exceed the display and cache range are released.

```ts
Grid() {
  LazyForEach(this.dataSource, () => {
    GridItem() {
    }
  })
}
.cachedCount(3)
```

>**NOTE**
>
>A greater **cachedCount** value may result in higher CPU and memory overhead of the UI. Adjust the value by taking into account both the comprehensive performance and user experience.

#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: en-us_image_0000001511900472.png
###Image description: The image depicts a grid layout with a total of nine grid items arranged in a 3x3 grid. Each grid item is enclosed in a yellow border and has a light beige background. The grid is labeled "Grid" at the top center. The grid items are evenly spaced, creating a structured and organized appearance.
##Image Name: en-us_image_0000001562700473.png
###Image description: The image consists of three columns, each containing a series of blue squares arranged in a grid pattern. The squares are of uniform size and color, creating a consistent and repetitive visual pattern across all three columns. The background of the image is white, which contrasts with the blue squares, making them stand out clearly. The arrangement of the squares in each column is identical, with no variation in the number or size of the squares. The overall appearance is orderly and symmetrical, with each column containing the same number of squares.
##Image Name: en-us_image_0000001562820833.png
###Image description: The image depicts a grid layout with three columns and three rows, each containing a rectangular box. The layout is divided into nine equal sections, with each section representing a cell in the grid. The cells are filled with a light blue color.

### Grid Layout Description:
1. **Columns and Rows:**
   - There are three columns and three rows.
   - Each column and row is equally spaced.

2. **Cell Dimensions:**
   - The cells are of equal size.
   - Each cell has a height and width of 1fr (fraction of the available space).

3. **Spacing:**
   - There is a 1fr spacing between the cells in both the horizontal and vertical directions.
   - The spacing is consistent throughout the grid.

4. **Grid Layout Structure:**
   - The first column has a width of 1fr.
   - The second column has a width of 2fr.
   - The third column has a width of 1fr.
   - The first row has a height of 1fr.
   - The second row has a height of 1fr.
   - The third row has a height of 1fr.

### Analysis:
- The grid layout is designed to demonstrate the use of fractional units (fr) in CSS for creating responsive layouts.
- The fr unit is a relative unit of measure that represents a fraction of the available space. In this case, each cell occupies 1fr of the available space.
- The spacing between cells is also defined using fr units, ensuring that the layout remains consistent regardless of the container's size.

### Conclusion:
This image effectively illustrates how CSS grid layout can be used to create a responsive and flexible grid structure. The use of fr units allows for easy scaling and adaptation to different screen sizes, making it a powerful tool for web designers and developers.
##Image Name: en-us_image_0000001511900480.png
###Image description: The image is a collage template with a light blue background. It consists of a grid of nine squares arranged in a 3x3 pattern. Each square is of equal size and is outlined in a darker blue color. The overall layout is symmetrical and evenly spaced, creating a balanced and organized appearance. This type of template is commonly used for creating photo collages, where each square can be filled with a different image or photo.
##Image Name: en-us_image_0000001511421292.png
###Image description: The image depicts a basic calculator interface. The calculator has a numeric keypad with numbers from 0 to 9 arranged in a grid, along with various arithmetic operation buttons such as addition (+), subtraction (-), multiplication (×), and division (/). There are also buttons for clearing the current input (C), clearing the entire calculation history (CE), and a button for calculating the result (=). The display area at the top shows the number 0, indicating that no calculations have been performed yet. The overall design is simple and user-friendly, with a focus on basic arithmetic operations.
##Image Name: en-us_image_0000001562700469.png
###Image description: The image consists of two panels, each displaying a grid layout with nine squares. The layout direction is specified at the top of each panel. The left panel has the layout direction set to `GridDirection.Row`, while the right panel has the layout direction set to `GridDirection.Column`.

### Left Panel (GridDirection.Row):
- The grid is arranged in a horizontal manner, with three rows and three columns.
- The numbers 1, 2, and 3 are in the first row.
- The numbers 4, 5, and 6 are in the second row.
- The numbers 7, 8, and 9 are in the third row.

### Right Panel (GridDirection.Column):
- The grid is arranged in a vertical manner, with three rows and three columns.
- The numbers 1, 4, and 7 are in the first column.
- The numbers 2, 5, and 8 are in the second column.
- The numbers 3, 6, and 9 are in the third column.

### Analysis:
- **GridDirection.Row**: This layout direction arranges the grid in a horizontal sequence. Each row contains three squares, and the rows are stacked one after the other.
- **GridDirection.Column**: This layout direction arranges the grid in a vertical sequence. Each column contains three squares, and the columns are stacked one after the other.

### Relevant Knowledge:
- **Grid Layouts**: In user interface design, grid layouts are commonly used to organize and display content in a structured manner. GridDirection specifies the orientation of the grid, either row-wise or column-wise.
- **Flexbox and CSS Grid**: Both are layout systems that allow developers to create flexible and responsive layouts. GridDirection is a property that can be set in CSS Grid to control the orientation of the grid.

### Conclusion:
The image effectively demonstrates how changing the layout direction from row to column alters the arrangement of the squares in the grid. This is a fundamental concept in layout design, particularly useful for creating responsive and user-friendly interfaces.
##Image Name: en-us_image_0000001563060729.png
###Image description: The image displays a grid of four gray squares, each containing a different label. The grid is arranged in a 2x2 format. Here is a detailed description of each square:

1. **Top Left Square**: This square contains the label "Conference." The text is centered within the square and is in a bold, sans-serif font. The background of the square is a light gray, and the text is black.

2. **Top Right Square**: This square contains the label "Sign-in." Similar to the first square, it has a bold, sans-serif font centered within the square. The background is light gray, and the text is black.

3. **Bottom Left Square**: This square contains the label "Vote." The text is centered within the square and is in a bold, sans-serif font. The background is light gray, and the text is black.

4. **Bottom Right Square**: This square is empty, with no label or text present. The background is light gray, and there is no text.

The overall design is minimalistic, with a focus on clarity and simplicity. Each label is clearly visible and easy to read, suggesting that this image might be part of a user interface for a conference or event management system.

### Analysis and Description

The image appears to be part of a user interface, likely for a conference or event management system. The labels suggest different functionalities or sections within the system:

- **Conference**: This likely refers to a section where users can access information or resources related to the conference.
- **Sign-in**: This section is probably used for attendees to sign in or register for the event.
- **Vote**: This section might be used for attendees to cast votes or participate in a poll during the conference.
- **Print**: This section could be for printing materials, such as agendas, handouts, or certificates.

### Chain of Thought (CoT) Analysis

1. **Purpose of Each Section**:
   - **Conference**: Provides access to conference-related information.
   - **Sign-in**: Allows attendees to register or sign in.
   - **Vote**: Enables attendees to participate in voting or polls.
   - **Print**: Facilitates printing of materials.

2. **User Interface Design**:
   - The use of a grid layout with clear labels ensures that users can easily identify and navigate to the desired sections.
   - The minimalistic design focuses on functionality without unnecessary distractions.

3. **Potential Use Cases**:
   - **Conference Management**: Helps in organizing and managing a conference by providing access to various functionalities.
   - **Event Registration**: Simplifies the process of attendees signing in or registering for the event.
   - **Polling and Voting**: Enables interactive elements such as voting or polls during the conference.
   - **Printing Materials**: Facilitates the printing of necessary documents or certificates.

In conclusion, the image represents a user interface for a conference or event management system, with clear labels for different functionalities such as accessing conference information, signing in, voting, and printing materials. The design is straightforward and user-friendly, ensuring that users can easily navigate through the system to perform their tasks.
##Image Name: en-us_image_0000001511580908.png
###Image description: The image depicts a grid layout with a total of nine blue squares arranged in a 3x3 pattern. The grid is divided into three rows and three columns. Each row and column has a spacing between the squares, which is indicated by white lines. The spacing between the rows is labeled as "Row spacing," and the spacing between the columns is labeled as "Column spacing." The overall layout suggests a structured and organized arrangement, commonly used in user interfaces, data visualization, or grid-based designs.
