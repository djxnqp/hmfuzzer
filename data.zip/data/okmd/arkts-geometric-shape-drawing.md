# Drawing Geometric Shapes (Shape)


The drawing components are used to draw graphs on the page. The **Shape** component is the parent component of the drawing components. The attributes of **Shape** are universal attributes supported by all the drawing components. For details, see [Shape](../reference/apis-arkui/arkui-ts/ts-drawing-components-shape.md).


## Creating a Drawing Component

A drawing component can be created in either of the following ways:

- Create a drawing component with **Shape** as their parent to implement the effect similar to SVG. The API used is as follows:

  ```ts
  Shape(value?: PixelMap)
  ```

  In the API, the **value** parameter sets the drawing target. You can draw a graph in the specified **PixelMap** object. If the **value** parameter is not set, the graph is drawn in the current drawing target.

  ```ts
  Shape() {
    Rect().width(300).height(50)
  }
  ```


- Create an independent drawing component to draw a specific shape. Seven shapes are supported: [Circle](../reference/apis-arkui/arkui-ts/ts-drawing-components-circle.md), [Ellipse](../reference/apis-arkui/arkui-ts/ts-drawing-components-ellipse.md), [Line](../reference/apis-arkui/arkui-ts/ts-drawing-components-line.md), [Polyline](../reference/apis-arkui/arkui-ts/ts-drawing-components-polyline.md), [Polygon](../reference/apis-arkui/arkui-ts/ts-drawing-components-polygon.md), [Path](../reference/apis-arkui/arkui-ts/ts-drawing-components-path.md), and [Rect](../reference/apis-arkui/arkui-ts/ts-drawing-components-rect.md). The following uses the **Circle** API as an example:

  ```ts
  Circle(options?: {width?: string | number, height?: string | number}
  ```

    This API draws a circle on a page. The **width** parameter indicates the width of the circle, and the **height** parameter indicates the height of the circle. The diameter of the circle is determined by the minimum width and height.

  ```ts
  Circle({ width: 150, height: 150 })
  ```

  ![creation-2](figures/creation-2.jpg)


## Viewport


```ts
viewPort{ x?: number | string, y?: number | string, width?: number | string, height?: number | string }
```

Creates a viewport, which is a rectangle in the user space that maps to the view boundary established for the associated SVG element. Among the four optional parameters, **x** and **y** represent the coordinates of the upper left corner of the viewport, and **width** and **height** represent the size of the viewport.

The following examples describe how to use the viewport:

- Zoom in or zoom out a graph through the shape viewport.

  ```ts
  class tmp{
    x:number = 0
    y:number = 0
    width:number = 75
    height:number = 75
  }
  let viep:tmp = new tmp()
  class tmp1{
    x:number = 0
    y:number = 0
    width:number = 300
    height:number = 300
  }
  let viep1:tmp1 = new tmp1()
  // Draw a circle whose width and height are both 75.
  Text('Original Size Circle')
  Circle({width: 75, height: 75}).fill('#E87361')

  Row({space:10}) {
    Column() {
      // Create a shape component whose width and height are both 150, the background color is yellow, and a viewport whose width and height are both 75. Fill the viewport with a blue rectangle and draw a circle with a diameter of 75 in the viewport.
      // The drawing is complete. The viewport is zoomed in twice based on the width and height of the component.
      Text('Enlarged Circle')
      Shape() {
        Rect().width('100%').height('100%').fill('#0097D4')
        Circle({width: 75, height: 75}).fill('#E87361')
      }
      .viewPort(viep)
      .width(150)
      .height(150)
      .backgroundColor('#F5DC62')
    }
    Column() {
      // Create a shape component whose width and height are both 150, the background color is yellow, and a viewport whose width and height are both 300. Fill the viewport with a green rectangle and draw a circle with a diameter of 75 in the viewport.
      // After the drawing is complete, the viewport is zoomed out by twice based on the width and height of the component.
      Text('Shrunk Circle')
      Shape() {
        Rect().width('100%').height('100%').fill('#BDDB69')
        Circle({width: 75, height: 75}).fill('#E87361')
      }
      .viewPort(viep1)
      .width(150)
      .height(150)
      .backgroundColor('#F5DC62')
    }
  }
  ```

  ![2023032401632](figures/2023032401632.jpg)

- Create a shape component whose width and height are both 300, with a yellow background and a viewport whose width and height are both 300. Fill the viewport with a blue rectangle and draw a circle with a radius of 75 in the viewport.

  ```ts
  class tmp{
    x:number = 0
    y:number = 0
    width:number = 300
    height:number = 300
  }
  let viep:tmp = new tmp()
  class tmp1{
    x:number = -150
    y:number = -150
    width:number = 300
    height:number = 300
  }
  let viep1:tmp1 = new tmp1()
  Shape() {
    Rect().width("100%").height("100%").fill("#0097D4")
    Circle({ width: 150, height: 150 }).fill("#E87361")
  }
    .viewPort(viep)
    .width(300)
    .height(300)
    .backgroundColor("#F5DC62")
  ```

  ![viewport (2) ](figures/viewport (2) .jpg)

- Create a shape component whose width and height are both 300, with a yellow background and a viewport whose width and height are both 300. Fill the viewport with a blue rectangle, draw a circle with a radius of 75 in the viewport, and move the viewport 150 to the right and below respectively.

  ```ts
  Shape() {
    Rect().width("100%").height("100%").fill("#0097D4")
    Circle({ width: 150, height: 150 }).fill("#E87361")
  }
    .viewPort(viep1)
    .width(300)
    .height(300)
    .backgroundColor("#F5DC62")

  ```

  ![viewport (3) ](figures/viewport (3) .jpg)


## Setting Styles

The drawing component allows you to change the component style through various attributes.

- You can use **fill** to set the color of the filling area of the component.

  ```ts
  Path()
    .width(100)
    .height(100)
    .commands('M150 0 L300 300 L0 300 Z')
    .fill("#E87361")
  ```

  ![2023022792216(1)](figures/2023022792216(1).jpg)

- You can use **stroke** to set the stroke color of a component.

  ```ts
  Path()
    .width(100)
    .height(100)
    .fillOpacity(0)
    .commands('M150 0 L300 300 L0 300 Z')
    .stroke(Color.Red)
  ```

  ![stroke](figures/stroke.jpg)

- You can use **strokeOpacity** to set the stroke opacity.

  ```ts
  Path()
    .width(100)
    .height(100)
    .fillOpacity(0)
    .commands('M150 0 L300 300 L0 300 Z')
    .stroke(Color.Red)
    .strokeWidth(10)
    .strokeOpacity(0.2)
  ```

  ![strokeopacity](figures/strokeopacity.jpg)

- You can use **strokeLineJoin** to set the join style of the stroke. Options include **Bevel**, **Miter**, and **Round**.

  ```ts
  Polyline()
    .width(100)
    .height(100)
    .fillOpacity(0)
    .stroke(Color.Red)
    .strokeWidth(8)
    .points([[20, 0], [0, 100], [100, 90]])
     // Set the join style of the stroke to Round.
    .strokeLineJoin(LineJoinStyle.Round)
  ```

  ![strokeLineJoin](figures/strokeLineJoin.jpg)

- **strokeMiterLimit** places a limit on the ratio of the miter length to the value of **strokeWidth** used to draw a miter join.
  The miter length indicates the distance from the outer tip to the inner corner of the miter. This attribute must be set to a value greater than or equal to 1 and takes effect when **strokeLineJoin** is set to **LineJoinStyle.Miter**.

  ```ts
  Polyline()
    .width(100)
    .height(100)
    .fillOpacity(0)
    .stroke(Color.Red)
    .strokeWidth(10)
    .points([[20, 0], [20, 100], [100, 100]])
    // Set the join style of the stroke to Miter.
    .strokeLineJoin(LineJoinStyle.Miter)
    // Set the limit on the ratio of the miter length to the value of strokeWidth used to draw a miter join.
    .strokeMiterLimit(1/Math.sin(45))
  Polyline()
    .width(100)
    .height(100)
    .fillOpacity(0)
    .stroke(Color.Red)
    .strokeWidth(10)
    .points([[20, 0], [20, 100], [100, 100]])
    .strokeLineJoin(LineJoinStyle.Miter)
    .strokeMiterLimit(1.42)
  ```

  ![2023032405917](figures/2023032405917.jpg)

- Use the **antiAlias** attribute to set whether to enable anti-aliasing. The default value is true, indicating that anti-aliasing is enabled.

  ```ts
  // Enable anti-aliasing.
  Circle()
    .width(150)
    .height(200)
    .fillOpacity(0)
    .strokeWidth(5)
    .stroke(Color.Black)
  ```

  ![untitled](figures/untitled.png)

  ```ts
  // Disable anti-aliasing.
  Circle()
    .width(150)
    .height(200)
    .fillOpacity(0)
    .strokeWidth(5)
    .stroke(Color.Black)
    .antiAlias(false)
  ```

  ![2023032411518](figures/2023032411518.jpg)


## Example Scenario

- Draw a closed path at (-80, -5). The fill color is 0x317AF7, the stroke width is 3, the stroke color is red, and the stroke join style is miter (default value).

  ```ts
  @Entry
  @Component
  struct ShapeExample {
    build() {
      Column({ space: 10 }) {
        Shape() {
          Path().width(200).height(60).commands('M0 0 L400 0 L400 150 Z')
        }
        .viewPort({ x: -80, y: -5, width: 500, height: 300 })
        .fill(0x317AF7)
        .stroke(Color.Red)
        .strokeWidth(3)
        .strokeLineJoin(LineJoinStyle.Miter)
        .strokeMiterLimit(5)
      }.width('100%').margin({ top: 15 })
    }
  }
  ```

  ![scenario-1](figures/scenario-1.jpg)

- Draw a circle with a diameter of 150 mm and a ring with a diameter of 150 mm and a red dotted line (use the shorter side as the diameter if the width and height are different).

  ```ts
  @Entry
  @Component
  struct CircleExample {
    build() {
      Column({ space: 10 }) {
        // Draw a circle whose diameter is 150.
        Circle({ width: 150, height: 150 })
        // Draw a ring with a diameter of 150 mm and a red dotted line.
        Circle()
          .width(150)
          .height(200)
          .fillOpacity(0)
          .strokeWidth(3)
          .stroke(Color.Red)
          .strokeDashArray([1, 2])
      }.width('100%')
    }
  }
  ```

  ![scenario-2](figures/scenario-2.jpg)
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: creation-2.jpg
###Image description: The image depicts a simple, black circle centered on a white background. There are no other objects, text, or additional elements present in the image. The circle is perfectly round and appears to be of uniform size, with no variations in its thickness or color. The contrast between the black circle and the white background is stark, making the circle the sole focus of the image.
##Image Name: 2023032401632.jpg
###Image description: The image consists of three distinct geometric shapes arranged in a vertical sequence. The shapes are circles, each of different sizes and colors, and they are labeled accordingly. The background of the image is white, which helps to highlight the shapes and their colors.

1. **Original Size Circle**: 
   - **Shape**: Circle
   - **Color**: Red
   - **Position**: Located at the top of the image
   - **Description**: This circle is the smallest among the three and is positioned centrally. It is labeled "Original Size Circle."

2. **Enlarged Circle**:
   - **Shape**: Circle
   - **Color**: Red
   - **Position**: Located to the left of the "Original Size Circle"
   - **Description**: This circle is larger than the "Original Size Circle" and is contained within a blue square. The blue square is larger than the circle, indicating that the circle has been enlarged. The enlarged circle is labeled "Enlarged Circle."

3. **Shrunk Circle**:
   - **Shape**: Circle
   - **Color**: Red
   - **Position**: Located to the right of the "Original Size Circle"
   - **Description**: This circle is smaller than the "Original Size Circle" and is contained within a yellow square. The yellow square is larger than the circle, indicating that the circle has been shrunk. The shrunk circle is labeled "Shrunk Circle."

### Analysis and Description

The image serves as a visual representation of geometric transformations, specifically focusing on the concepts of enlargement and shrinkage of circles. The three circles are labeled to indicate their original size, enlarged size, and shrunk size, respectively. 

- **Enlargement**: The "Enlarged Circle" is larger than the "Original Size Circle," which means that its radius has been increased. This transformation is depicted by the circle being contained within a larger blue square.
- **Shrinkage**: The "Shrunk Circle" is smaller than the "Original Size Circle," indicating that its radius has been decreased. This transformation is depicted by the circle being contained within a larger yellow square.

### Relevant Knowledge

- **Geometric Transformations**: In geometry, transformations such as enlargement and shrinkage (also known as dilation) involve changing the size of a shape while maintaining its shape. Enlargement increases the size of a shape, while shrinkage decreases its size.
- **Mathematical Representation**: Mathematically, if a circle with radius \( r \) is enlarged by a factor of \( k \), its new radius becomes \( kr \). Similarly, if a circle is shrunk by a factor of \( k \), its new radius becomes \( \frac{r}{k} \).

### Conclusion

The image effectively demonstrates the concepts of enlargement and shrinkage of circles through visual representation. The use of different colors and labels helps to clearly distinguish between the original, enlarged, and shrunk circles, making it easier to understand the geometric transformations involved.
##Image Name: 2023022792216(1).jpg
###Image description: The image depicts a simple geometric shape, specifically a triangle. The triangle is filled with a solid color, which appears to be a shade of pink or coral. The triangle is oriented such that its base is horizontal, and the apex points upwards. The edges of the triangle are straight and sharp, indicating that it is an equilateral triangle, meaning all three sides are of equal length. The background of the image is plain white, which contrasts with the pink triangle, making it stand out clearly. There are no other objects or elements present in the image.
##Image Name: stroke.jpg
###Image description: The image depicts a simple geometric figure, specifically a triangle. The triangle is outlined in a thin, red line and is positioned against a white background. The triangle is an equilateral triangle, meaning all three sides are of equal length. The vertices of the triangle are not labeled, and there are no additional markings or annotations within the triangle itself. The lines forming the triangle are straight and evenly spaced, indicating a precise and symmetrical shape. The overall appearance is minimalistic, with no additional elements or textures present.
##Image Name: strokeopacity.jpg
###Image description: The image depicts a simple, light pink triangle. The triangle is outlined with a thin, light pink line and is set against a white background. The triangle is an equilateral triangle, meaning all three sides are of equal length. The lines are smooth and evenly spaced, giving the triangle a clean and minimalist appearance. There are no additional elements or markings within or around the triangle.
##Image Name: strokeLineJoin.jpg
###Image description: The image depicts a red, L-shaped object. The L-shape consists of two straight lines that meet at a right angle. The lines are of equal length and are positioned horizontally and vertically. The background of the image is plain white, which makes the red L-shape stand out prominently. The red color is solid and uniform, with no shading or gradient. The lines are clean and straight, suggesting that the object is likely a physical object or a digital representation of one.
##Image Name: 2023032405917.jpg
###Image description: The image displays two red "L" letters placed side by side against a white background. The "L" letters are identical in size and orientation, with each letter having a bold, sans-serif font. The lines of the letters are straight and evenly spaced, giving them a clean and modern appearance. The red color of the letters stands out prominently against the white background, making them easily noticeable.
##Image Name: untitled.png
###Image description: The image depicts a simple, black outline of a circle. The circle is centered and has a uniform thickness throughout its circumference. There are no additional elements, patterns, or colors within or around the circle. The background is plain white, which makes the black outline of the circle stand out clearly.
##Image Name: 2023032411518.jpg
###Image description: The image depicts a simple, black outline of a circle. The circle is centered and appears to be drawn with a consistent thickness, creating a uniform border around the inner space. There are no additional elements, patterns, or colors within or around the circle. The background is plain and does not contain any other objects or features.
##Image Name: scenario-1.jpg
###Image description: The image depicts a geometric shape that appears to be a triangle. The triangle is outlined in red, and the interior is filled with a solid blue color. The triangle is oriented such that one of its vertices is at the top, and the other two vertices are at the bottom, forming a right-angled triangle. The hypotenuse, which is the longest side of the triangle, is the side that extends from the top vertex to the bottom right vertex. The other two sides are the legs of the triangle, with one leg extending from the top vertex to the bottom left vertex and the other leg extending from the top vertex to the bottom right vertex. The triangle is set against a white background, which makes the blue interior and red outline stand out clearly.
##Image Name: scenario-2.jpg
###Image description: The image consists of two distinct objects placed against a plain white background. The upper object is a black circle, which appears to be a solid, uniform color without any visible texture or pattern. The lower object is a circular ring, which is composed of a series of small, evenly spaced, circular beads or links. The ring is colored in a light pink or rose hue, and it has a metallic sheen, suggesting it might be made of a material like metal or plastic. The ring is arranged in a circular pattern, with each bead or link appearing to be connected to the next, forming a continuous loop.

The black circle and the pink ring are positioned such that the black circle is directly above the pink ring, creating a clear visual separation between the two objects. The black circle is larger than the pink ring, and the pink ring is centered within the black circle, creating a sense of containment or enclosure.

### Analysis and Description

1. **Objects and Colors**:
   - **Black Circle**: Solid, uniform black color, no visible texture or pattern.
   - **Pink Ring**: Light pink or rose hue, circular, composed of small, evenly spaced beads or links, metallic sheen.

2. **Positioning**:
   - The black circle is positioned above the pink ring.
   - The pink ring is centered within the black circle.

3. **Material and Texture**:
   - The black circle appears to be solid and uniform in texture.
   - The pink ring has a metallic sheen, suggesting it might be made of metal or a similar material.

4. **Visual Contrast**:
   - The black circle and the pink ring provide a strong visual contrast due to their different colors and textures.
   - The black circle's solid nature contrasts with the pink ring's more intricate and detailed structure.

### Relevant Knowledge Integration

- **Color Contrast**: The use of black and pink colors can be significant in design and visual communication. Black is often associated with sophistication, elegance, and formality, while pink can symbolize femininity, playfulness, and warmth.
- **Material Interpretation**: The metallic sheen of the pink ring suggests it could be made of materials like brass, aluminum, or a coated plastic, which are commonly used in jewelry and decorative items.

### Conclusion

The image presents a simple yet striking contrast between two distinct objects: a black circle and a pink ring. The black circle's solid and uniform appearance contrasts with the pink ring's intricate and detailed structure, creating a visually appealing composition. The positioning of the objects and their contrasting colors and textures make the image both aesthetically pleasing and informative.
