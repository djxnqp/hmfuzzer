# Converting HAR to HSP
Currently, the HAR has a problem with duplicate packaging, leading an oversize application package. To fix this problem, you can convert the HAR to the HSP through by the configuration items.
## How to Convert

1. Change the value of **type** to **shared** and add the **deliveryWithInstall** field in the **module.json5** file of the HAR module.
    ```json
    // MyApplication\library\src\main\module.json5
    {
      "module": {
        "name": "library",
        "type": "shared",
        "description": "$string:shared_desc",
        "deliveryWithInstall": true,
        "pages": "$profile:main_pages"
      }
    }
    ```

2. Add a string field **shared_desc** in **element** of the **base**, **en\_US**, and **zh\_CN** qualifiers directories under the **resources** directory.
    ```json
    // MyApplication\library\src\main\resources\base\element\string.json
    {
      "string": [
        {
          "name": "shared_desc",
          "value": "description"
        }
      ]
    }
    ```

3. Add a **profile** folder in **resources** > **base**. Then add a **main_pages.json** file to the added folder and configure it as follows:
    ```json
    // MyApplication\library\src\main\resources\base\profile\main_pages.json
    {
      "src": [
        "pages/PageIndex"
      ]
    }
    ```

4. Add a **pages** directory in the **ets** directory. Then add a **PageIndex.ets** file in the added directory and configure it as follows:
    ```ts
    // MyApplication\library\src\main\ets\pages\PageIndex.ets
    @Entry
    @Component
    struct PageIndex {
      @State message: string = 'hello world';

      build() {
        Row() {
          Column() {
            Text(this.message)
              .fontSize(50)
              .fontWeight(FontWeight.Bold)
          }
          .width('100%')
        }
        .height('100%')
      }
    }
    ```

5. Delete the **consumerFiles** field from the **build-profile.json5** file of the HAR module.

6. Replace the content in the **hvigorfile.ts** file of the HAR module with the following content:
    ```ts
    // MyApplication\library\hvigorfile.ts
    import { hspTasks } from '@ohos/hvigor-ohos-plugin';

    export default {
      system: hspTasks,  /* Built-in plugin of Hvigor. It cannot be modified. */
      plugins:[]         /* Custom plugin to extend the functionality of Hvigor. */
    }
    ```

7. Add the **packageType** field in the **oh-package.json5** file.
    ```json
    // MyApplication\library\oh-package.json5
    {
      "packageType": "InterfaceHar"
    }
    ```

8. Modify the **build-profile.json5** configuration file in the project root directory.
![har-to-hsp-8-1.png](figures/har-to-hsp-8-1.png)
After modification
![har-to-hsp-8-2.png](figures/har-to-hsp-8-2.png)
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: har-to-hsp-8-1.png
###Image description: The image shows a screenshot of a code editor, specifically IntelliJ IDEA, with a focus on a JSON file named "build-profile.json5". The editor is displaying the contents of this file, which is used for defining build profiles in the project. The file is part of a larger project named "MyApplication".

Key elements in the image include:

1. **Project Structure**: The left sidebar shows the project structure, with folders and files listed. The highlighted folder is "build-profile.json5".

2. **JSON File Content**: The main area of the editor displays the JSON file content. The file contains an object with the following structure:
   - `buildModeSet`: An array containing two objects, each representing a build mode ("debug" and "release").
   - `modules`: An array containing two objects, each representing a module ("library" and "library1").

3. **Highlighted Sections**: There are two highlighted sections in the JSON file:
   - The first highlighted section is around the "library" module, indicating that it needs to be added.
   - The second highlighted section is around the "library1" module, also indicating that it needs to be added.

4. **Annotations**: There are annotations pointing to the highlighted sections, suggesting that these modules should be added to the build profile.

5. **Editor Interface**: The editor interface includes standard features such as file tabs, a gutter with line numbers, and syntax highlighting for the JSON code.

6. **Project Path**: The project path is displayed at the top of the editor, indicating the location of the project files.

### Analysis and Description

The image is a screenshot of a developer working on a project using IntelliJ IDEA, focusing on configuring build profiles for different modules. The build-profile.json5 file is used to define how the project should be built for different modes (debug and release). The highlighted sections suggest that the developer needs to add two additional modules to the build profile: "library" and "library1".

### Relevant Knowledge

Build profiles in project management tools like IntelliJ IDEA are used to define how a project should be built for different environments. For example, a "debug" profile might include more detailed logging and debugging information, while a "release" profile might optimize for performance and minimize debugging information. Adding modules to the build profile ensures that the build process includes the necessary dependencies and configurations for each module.

### Conclusion

The image shows a developer in the process of configuring build profiles for a project in IntelliJ IDEA. The highlighted sections indicate that two additional modules need to be added to the build profile, which is a crucial step in ensuring that the project is built correctly for different environments.
##Image Name: har-to-hsp-8-2.png
###Image description: The image shows a screenshot of a code editor interface, likely from a development environment such as Visual Studio Code or IntelliJ IDEA. The project is named "MyApplication," and the file being edited is "build-profile.json5." The editor is displaying the JSON5 configuration file, which is used to define build profiles for a project.

Key elements in the image include:

1. **Project Explorer (Left Pane)**:
   - The project explorer shows the structure of the project, including folders and files.
   - The project structure includes:
     - `.h vigor`
     - `.idea`
     - `entry`
     - `library`
     - `library1`
     - `oh_modules`
     - `build-profile.json5`
     - `code-linter.json5`
     - `h vigorfile.ts`
     - `local.properties`
     - `oh-package.json5`
     - `oh-package-lock.json5`
   - The `.gitignore` file is also visible.

2. **Code Editor (Right Pane)**:
   - The code editor is displaying the "build-profile.json5" file.
   - The file contains JSON5 syntax, which is a JSON-like syntax for JavaScript.
   - The file is structured with key-value pairs and arrays.
   - The highlighted section shows the "targets" array, which defines build targets for the project.
   - The targets are defined with the following properties:
     - `name`: The name of the target.
     - `applyToProducts`: An array of products to which the target applies.
     - `default`: Indicates the default target.

3. **Editor Features**:
   - The editor has syntax highlighting, which is evident from the color-coding of the code.
   - The editor provides line numbers and gutter icons for navigation.
   - The editor also shows a message at the top indicating that core configuration attributes have changed since the last project sync, suggesting that a project sync may be necessary for the IDE to work properly.

4. **Additional Context**:
   - The project appears to be a Node.js or JavaScript project, given the presence of `.json5` and `.ts` files.
   - The `.gitignore` file indicates that the project is being version-controlled with Git.

Overall, the image provides a snapshot of a development environment with a focus on project configuration and build profiles for a Node.js or JavaScript project.
