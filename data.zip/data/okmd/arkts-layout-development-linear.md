# Linear Layout (Row/Column)


## Overview

Linear layout is the most frequently used layout in development, built with the [Row](../reference/apis-arkui/arkui-ts/ts-container-row.md) or [Column](../reference/apis-arkui/arkui-ts/ts-container-column.md) linear containers. The linear layout is the basis of other layouts. Its child elements are arranged in sequence linearly in the horizontal direction, as in a **Row** container, or vertical direction, as in a **Column** container.  


  **Figure 1** Child element arrangement in a Column container 

![arrangement-child-elements-column](figures/arrangement-child-elements-column.png)


  **Figure 2** Child element arrangement in a Row container 

![arrangement-child-elements-row](figures/arrangement-child-elements-row.png)


## Basic Concepts

- Layout container: container component that is able to lay out other elements as its child elements. The layout container calculates the size of its child elements and arranges the layout.

- Layout child element: element inside the layout container.

- Main axis: axis along which child elements are laid out by default in the linear layout container. The main axis is horizontal for the **Row** container and vertical for the **Column** container.

- Cross axis: axis that runs perpendicular to the main axis. The cross axis is vertical for the **Row** container and horizontal for the **Column** container.

- Spacing: distance between child elements.


## Spacing of Child Elements in Arrangement Direction

In the layout container, use the **space** attribute to equally space child elements in the arrangement direction.


### In Column Container

  **Figure 3** Layout child element spacing in the arrangement direction in the Column container 

![arrangement-direction-column](figures/arrangement-direction-column.png)

```ts
Column({ space: 20 }) {
  Text('space: 20').fontSize(15).fontColor(Color.Gray).width('90%')
  Row().width('90%').height(50).backgroundColor(0xF5DEB3)
  Row().width('90%').height(50).backgroundColor(0xD2B48C)
  Row().width('90%').height(50).backgroundColor(0xF5DEB3)
}.width('100%')
```


![arrangement-direction-column-sample](figures/arrangement-direction-column-sample.png)


### In Row Container

  **Figure 4** Layout child element spacing in the arrangement direction in the Row container 

![arrangement-direction-row](figures/arrangement-direction-row.png)


```ts
Row({ space: 35 }) {
  Text('space: 35').fontSize(15).fontColor(Color.Gray)
  Row().width('10%').height(150).backgroundColor(0xF5DEB3)
  Row().width('10%').height(150).backgroundColor(0xD2B48C)
  Row().width('10%').height(150).backgroundColor(0xF5DEB3)
}.width('90%')
```

![en-us_image_0000001562700509](figures/en-us_image_0000001562700509.png)


## Alignment of Child Elements Along Cross Axis

In the layout container, use the **alignItems** attribute to set the alignment mode of child elements along the cross axis. The alignment performance is consistent across screens of various sizes. The value is of the [VerticalAlign Type](../reference/apis-arkui/arkui-ts/ts-appendix-enums.md#verticalalign) type when the cross axis is in the vertical direction and the [HorizontalAlign](../reference/apis-arkui/arkui-ts/ts-appendix-enums.md#horizontalalign) type when the cross axis is in the horizontal direction.

The layout container also provides the **alignSelf** attribute to control the alignment mode of a single child element along the cross axis. This attribute has a higher priority than the **alignItems** attribute. This means that, if **alignSelf** is set, it will overwrite the **alignItems** setting on the corresponding child element.


### Horizontal Alignment of Child Elements in Column Container

  **Figure 5** Horizontal alignment of child elements in the Column container 

![horizontal-arrangement-child-column](figures/horizontal-arrangement-child-column.png)

- **HorizontalAlign.Start**: Child elements are left aligned horizontally.

  ```ts
  Column({}) {
    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)

    Column() {
    }.width('80%').height(50).backgroundColor(0xD2B48C)

    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)
  }.width('100%').alignItems(HorizontalAlign.Start).backgroundColor('rgb(242,242,242)')
  ```

  ![en-us_image_0000001511580964](figures/en-us_image_0000001511580964.png)

- **HorizontalAlign.Center**: Child elements are center-aligned horizontally.

  ```ts
  Column({}) {
    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)

    Column() {
    }.width('80%').height(50).backgroundColor(0xD2B48C)

    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)
  }.width('100%').alignItems(HorizontalAlign.Center).backgroundColor('rgb(242,242,242)')
  ```

  ![en-us_image_0000001562820897](figures/en-us_image_0000001562820897.png)

- **HorizontalAlign.End**: Child elements are right-aligned horizontally.

  ```ts
  Column({}) {
    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)

    Column() {
    }.width('80%').height(50).backgroundColor(0xD2B48C)

    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)
  }.width('100%').alignItems(HorizontalAlign.End).backgroundColor('rgb(242,242,242)')
  ```

  ![en-us_image_0000001511421348](figures/en-us_image_0000001511421348.png)


### Vertical Alignment of Child Elements in Row Container

  **Figure 6** Vertical alignment of child elements in Row container 

![horizontal-arrangement-child-row](figures/horizontal-arrangement-child-row.png)

- **VerticalAlign.Top**: Child elements are top-aligned vertically.

  ```ts
  Row({}) {
    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)

    Column() {
    }.width('20%').height(30).backgroundColor(0xD2B48C)

    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)
  }.width('100%').height(200).alignItems(VerticalAlign.Top).backgroundColor('rgb(242,242,242)')
  ```

  ![en-us_image_0000001563060765](figures/en-us_image_0000001563060765.png)

- **VerticalAlign.Center**: Child elements are center-aligned vertically.

  ```ts
  Row({}) {
    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)

    Column() {
    }.width('20%').height(30).backgroundColor(0xD2B48C)

    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)
  }.width('100%').height(200).alignItems(VerticalAlign.Center).backgroundColor('rgb(242,242,242)')
  ```

  ![en-us_image_0000001562700505](figures/en-us_image_0000001562700505.png)

- **VerticalAlign.Bottom**: Child elements are bottom-aligned vertically.

  ```ts
  Row({}) {
    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)

    Column() {
    }.width('20%').height(30).backgroundColor(0xD2B48C)

    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)
  }.width('100%').height(200).alignItems(VerticalAlign.Bottom).backgroundColor('rgb(242,242,242)')
  ```

  ![en-us_image_0000001563060781](figures/en-us_image_0000001563060781.png)


## Arrangement of Child Elements Along Main Axis

In the layout container, you can use the **justifyContent** attribute to set the arrangement mode of child elements along the main axis. The arrangement may begin from the start point or end point of the main axis, or the space of the main axis can be evenly divided.


### Vertical Alignment of Child Elements in Column Container

  **Figure 7** Vertical alignment of child elements in the Column container

![vertial-arrangement-child-column](figures/vertial-arrangement-child-column.png)

- **justifyContent(FlexAlign.Start)**: The items are vertically aligned with each other toward the start edge of the container.

  ```ts
  Column({}) {
    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)

    Column() {
    }.width('80%').height(50).backgroundColor(0xD2B48C)

    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)
  }.width('100%').height(300).backgroundColor('rgb(242,242,242)').justifyContent(FlexAlign.Start)
  ```

  ![en-us_image_0000001562700501](figures/en-us_image_0000001562700501.png)

- **justifyContent(FlexAlign.Center)**: The elements are vertically aligned with each other toward the center of the container. The space between the first component and the start edge is the same as that between the last component and the end edge.

  ```ts
  Column({}) {
    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)

    Column() {
    }.width('80%').height(50).backgroundColor(0xD2B48C)

    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)
  }.width('100%').height(300).backgroundColor('rgb(242,242,242)').justifyContent(FlexAlign.Center)
  ```

  ![en-us_image_0000001562700517](figures/en-us_image_0000001562700517.png)

- **justifyContent(FlexAlign.End)**: The elements are vertically aligned with each other toward the end edge of the container.

  ```ts
  Column({}) {
    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)

    Column() {
    }.width('80%').height(50).backgroundColor(0xD2B48C)

    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)
  }.width('100%').height(300).backgroundColor('rgb(242,242,242)').justifyContent(FlexAlign.End)
  ```

  ![en-us_image_0000001562940585](figures/en-us_image_0000001562940585.png)

- **justifyContent(FlexAlign.SpaceBetween)**: The elements are evenly distributed vertically. The space between any two adjacent elements is the same. The first element is aligned with the start edge, the last element is aligned with the end edge, and the remaining elements are distributed so that the space between any two adjacent elements is the same.

  ```ts
  Column({}) {
    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)

    Column() {
    }.width('80%').height(50).backgroundColor(0xD2B48C)

    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)
  }.width('100%').height(300).backgroundColor('rgb(242,242,242)').justifyContent(FlexAlign.SpaceBetween)
  ```

  ![en-us_image_0000001511900532](figures/en-us_image_0000001511900532.png)

- **justifyContent(FlexAlign.SpaceAround)**: The elements are evenly distributed vertically. The space between any two adjacent elements is the same. The space between the first element and start edge, and that between the last element and end edge are both half the size of the space between two adjacent elements.

  ```ts
  Column({}) {
    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)

    Column() {
    }.width('80%').height(50).backgroundColor(0xD2B48C)

    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)
  }.width('100%').height(300).backgroundColor('rgb(242,242,242)').justifyContent(FlexAlign.SpaceAround)
  ```

  ![en-us_image_0000001562700525](figures/en-us_image_0000001562700525.png)

- **justifyContent(FlexAlign.SpaceEvenly)**: The elements are evenly distributed vertically. The space between the first element and start edge, the space between the last element and end edge, and the space between any two adjacent elements are the same.

  ```ts
  Column({}) {
    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)

    Column() {
    }.width('80%').height(50).backgroundColor(0xD2B48C)

    Column() {
    }.width('80%').height(50).backgroundColor(0xF5DEB3)
  }.width('100%').height(300).backgroundColor('rgb(242,242,242)').justifyContent(FlexAlign.SpaceEvenly)
  ```

  ![en-us_image_0000001563060785](figures/en-us_image_0000001563060785.png)


### Horizontal Alignment of Child Elements in Row Container

  **Figure 8** Horizontal alignment of child elements in the Row container 

![vertial-arrangement-child-row](figures/vertial-arrangement-child-row.png)

- **justifyContent(FlexAlign.Start)**: The items are horizontally aligned with each other toward the start edge of the container.

  ```ts
  Row({}) {
    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)

    Column() {
    }.width('20%').height(30).backgroundColor(0xD2B48C)

    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)
  }.width('100%').height(200).backgroundColor('rgb(242,242,242)').justifyContent(FlexAlign.Start)
  ```

  ![en-us_image_0000001511421356](figures/en-us_image_0000001511421356.png)

- **justifyContent(FlexAlign.Center)**: The elements are horizontally aligned with each other toward the center of the container. The space between the first component and the start edge is the same as that between the last component and the end edge.

  ```ts
  Row({}) {
    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)

    Column() {
    }.width('20%').height(30).backgroundColor(0xD2B48C)

    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)
  }.width('100%').height(200).backgroundColor('rgb(242,242,242)').justifyContent(FlexAlign.Center)
  ```

  ![en-us_image_0000001511900516](figures/en-us_image_0000001511900516.png)

- **justifyContent(FlexAlign.End)**: The elements are horizontally aligned with each other toward the end edge of the container.

  ```ts
  Row({}) {
    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)

    Column() {
    }.width('20%').height(30).backgroundColor(0xD2B48C)

    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)
  }.width('100%').height(200).backgroundColor('rgb(242,242,242)').justifyContent(FlexAlign.End)
  ```

  ![en-us_image_0000001562940601](figures/en-us_image_0000001562940601.png)

- **justifyContent(FlexAlign.SpaceBetween)**: The elements are evenly distributed horizontally. The space between any two adjacent elements is the same. The first element is aligned with the start edge, the last element is aligned with the end edge, and the remaining elements are distributed so that the space between any two adjacent elements is the same.

  ```ts
  Row({}) {
    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)

    Column() {
    }.width('20%').height(30).backgroundColor(0xD2B48C)

    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)
  }.width('100%').height(200).backgroundColor('rgb(242,242,242)').justifyContent(FlexAlign.SpaceBetween)
  ```

  ![en-us_image_0000001562700521](figures/en-us_image_0000001562700521.png)

- **justifyContent(FlexAlign.SpaceAround)**: The elements are evenly distributed horizontally. The space between any two adjacent elements is the same. The space between the first element and start edge, and that between the last element and end edge are both half the size of the space between two adjacent elements.

  ```ts
  Row({}) {
    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)

    Column() {
    }.width('20%').height(30).backgroundColor(0xD2B48C)

    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)
  }.width('100%').height(200).backgroundColor('rgb(242,242,242)').justifyContent(FlexAlign.SpaceAround)
  ```

  ![en-us_image_0000001562820893](figures/en-us_image_0000001562820893.png)

- **justifyContent(FlexAlign.SpaceEvenly)**: The elements are evenly distributed horizontally. The space between the first element and start edge, the space between the last element and end edge, and the space between any two adjacent elements are the same.

  ```ts
  Row({}) {
    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)

    Column() {
    }.width('20%').height(30).backgroundColor(0xD2B48C)

    Column() {
    }.width('20%').height(30).backgroundColor(0xF5DEB3)
  }.width('100%').height(200).backgroundColor('rgb(242,242,242)').justifyContent(FlexAlign.SpaceEvenly)
  ```

  ![en-us_image_0000001511421352](figures/en-us_image_0000001511421352.png)


## Adaptive Stretching

In linear layout, adaptive stretching is achieved by using the [Blank](../reference/apis-arkui/arkui-ts/ts-basic-components-blank.md) component, which automatically fills the empty spaces in the container – **Row** or **Column** – along the main axis. Just add the width and height as a percentage, and then adaptive scaling will take effect once the screen width and height change.


```ts
@Entry
@Component
struct BlankExample {
  build() {
    Column() {
      Row() {
        Text('Bluetooth').fontSize(18)
        Blank()
        Toggle({ type: ToggleType.Switch, isOn: true })
      }.backgroundColor(0xFFFFFF).borderRadius(15).padding({ left: 12 }).width('100%')
    }.backgroundColor(0xEFEFEF).padding(20).width('100%')
  }
}
```

  **Figure 9** Portrait mode 

![en-us_image_0000001562820881](figures/en-us_image_0000001562820881.png)

  **Figure 10** Landscape mode 

![en-us_image_0000001511421332](figures/en-us_image_0000001511421332.png)


## Adaptive Scaling

Adaptive scaling means that the size of a child element is automatically adjusted according to a preset ratio to fit into the container across devices of various screen sizes. In linear layout, adaptive scaling can be achieved using either of the following methods:


- When the container size is determined, use **layoutWeight** to set the weight of a child element during layout. The container space is then allocated along the main axis among the element and sibling elements based on the set layout weight, ignoring the size settings of the elements themselves.

  ```ts
  @Entry
  @Component
  struct layoutWeightExample {
    build() {
      Column() {
        Text('1:2:3').width('100%')
        Row() {
          Column() {
            Text('layoutWeight(1)')
              .textAlign(TextAlign.Center)
          }.layoutWeight(1).backgroundColor(0xF5DEB3).height('100%')

          Column() {
            Text('layoutWeight(2)')
              .textAlign(TextAlign.Center)
          }.layoutWeight(2).backgroundColor(0xD2B48C).height('100%')

          Column() {
            Text('layoutWeight(3)')
              .textAlign(TextAlign.Center)
          }.layoutWeight(3).backgroundColor(0xF5DEB3).height('100%')

        }.backgroundColor(0xffd306).height('30%')

        Text('2:5:3').width('100%')
        Row() {
          Column() {
            Text('layoutWeight(2)')
              .textAlign(TextAlign.Center)
          }.layoutWeight(2).backgroundColor(0xF5DEB3).height('100%')

          Column() {
            Text('layoutWeight(5)')
              .textAlign(TextAlign.Center)
          }.layoutWeight(5).backgroundColor(0xD2B48C).height('100%')

          Column() {
            Text('layoutWeight(3)')
              .textAlign(TextAlign.Center)
          }.layoutWeight(3).backgroundColor(0xF5DEB3).height('100%')
        }.backgroundColor(0xffd306).height('30%')
      }
    }
  }
  ```

    **Figure 11** Landscape mode 

  ![en-us_image_0000001511421336](figures/en-us_image_0000001511421336.png)

    **Figure 12** Portrait mode 

  ![en-us_image_0000001511580968](figures/en-us_image_0000001511580968.png)

- When the container size is determined, set the width of a child element in percentage. The container space is then allocated among the element and sibling elements based on the set percentage.

  ```ts
  @Entry
  @Component
  struct WidthExample {
    build() {
      Column() {
        Row() {
          Column() {
            Text('left width 20%')
              .textAlign(TextAlign.Center)
          }.width('20%').backgroundColor(0xF5DEB3).height('100%')

          Column() {
            Text('center width 50%')
              .textAlign(TextAlign.Center)
          }.width('50%').backgroundColor(0xD2B48C).height('100%')

          Column() {
            Text('right width 30%')
              .textAlign(TextAlign.Center)
          }.width('30%').backgroundColor(0xF5DEB3).height('100%')
        }.backgroundColor(0xffd306).height('30%')
      }
    }
  }
  ```

    **Figure 13** Landscape mode 

  ![en-us_image_0000001563060777](figures/en-us_image_0000001563060777.png)

    **Figure 14** Portrait mode 

  ![en-us_image_0000001511740564](figures/en-us_image_0000001511740564.png)


## Adaptive Extension

Adaptive extension allows users to drag the scrollbar to display the page content outside the screen. It is applicable to the scenario where the content extends beyond the viewport in linear layout. Below are the methods to implement adaptive extension in linear layout:

- [Add a scrollbar to a List component](arkts-layout-development-create-list.md#adding-a-scrollbar): If the list items cannot be fully displayed on one screen, you can place the child elements in different components and employ a scrollbar to display them. Use the **scrollBar** attribute to set the scrollbar status and the **edgeEffect** attribute to set the rebound effect when the scrollbar has reached the edge.

- Use a **Scroll** component: When one screen is not able to accommodate the full content, you can wrap a **Scroll** component at the outer layer of the **Column** or **Row** component to implement a scrollable linear layout.
    Example of using a **Scroll** component in the vertical layout:

  ```ts
  @Entry
  @Component
  struct ScrollExample {
    scroller: Scroller = new Scroller();
    private arr: number[] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  
    build() {
      Scroll(this.scroller) {
        Column() {
          ForEach(this.arr, (item?:number|undefined) => {
            if(item){
              Text(item.toString())
              .width('90%')
              .height(150)
              .backgroundColor(0xFFFFFF)
              .borderRadius(15)
              .fontSize(16)
              .textAlign(TextAlign.Center)
              .margin({ top: 10 })
            }
          }, (item:number) => item.toString())
        }.width('100%')
      }
      .backgroundColor(0xDCDCDC)
      .scrollable(ScrollDirection.Vertical) // Vertical scrolling.
      .scrollBar(BarState.On) // The scrollbar is always displayed.
      .scrollBarColor(Color.Gray) // The scrollbar color is gray.
      .scrollBarWidth(10) // The scrollbar width is 10.
      .edgeEffect(EdgeEffect.Spring) // The spring effect is produced when the scrollbar has reached the edge.
    }
  }
  ```

  ![en-us_image_0000001511900524](figures/en-us_image_0000001511900524.gif)

  Example of using a **Scroll** component in the horizontal layout:


  ```ts
  @Entry
  @Component
  struct ScrollExample {
    scroller: Scroller = new Scroller();
    private arr: number[] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];
  
    build() {
      Scroll(this.scroller) {
        Row() {
          ForEach(this.arr, (item?:number|undefined) => {
            if(item){
              Text(item.toString())
              .height('90%')
              .width(150)
              .backgroundColor(0xFFFFFF)
              .borderRadius(15)
              .fontSize(16)
              .textAlign(TextAlign.Center)
              .margin({ left: 10 })
            }
          })
        }.height('100%')
      }
      .backgroundColor(0xDCDCDC)
      .scrollable(ScrollDirection.Horizontal) // Horizontal scrolling.
      .scrollBar(BarState.On) // The scrollbar is always displayed.
      .scrollBarColor(Color.Gray) // The scrollbar color is gray.
      .scrollBarWidth(10) // The scrollbar width is 10.
      .edgeEffect(EdgeEffect.Spring) // The spring effect is produced when the scrollbar has reached the edge.
    }
  }
  ```

  ![en-us_image_0000001562940609](figures/en-us_image_0000001562940609.gif)
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: arrangement-child-elements-column.png
###Image description: The image shows a simple layout with four horizontal bars arranged in a column. The bars are of equal width and are filled with a light blue color. The background of the image is white. At the bottom of the image, there is a label that reads "Column" in black text.
##Image Name: arrangement-child-elements-row.png
###Image description: The image shows a simple layout with four rectangular shapes arranged in a single row. The background is light gray, and the rectangular shapes are filled with a light blue color. The text "Row" is written above the rectangles, indicating that these shapes are part of a row in a grid layout.
##Image Name: arrangement-direction-column.png
###Image description: The image depicts a diagram of a column layout with three horizontal sections. Each section is represented by a blue rectangle, and there are two vertical arrows labeled "space" between the sections. The top and bottom sections are connected by these arrows, indicating spacing or padding between them. The middle section is also connected to the top and bottom sections by similar arrows, suggesting that it is also spaced from the other sections. The word "Column" is written at the bottom of the diagram, indicating that this is a representation of a column layout in a user interface design.
##Image Name: arrangement-direction-column-sample.png
###Image description: The image contains three horizontal rectangular bars, each with a different color and spacing between them. The bars are arranged in a vertical sequence from top to bottom. Here is a detailed description of each bar:

1. **Top Bar:**
   - Color: Light beige or cream.
   - Width: Approximately 100 pixels.
   - Height: Approximately 20 pixels.
   - Position: Located at the top of the image.
   - Spacing: There is a 20-pixel space between this bar and the next bar below it.

2. **Middle Bar:**
   - Color: Dark beige or light brown.
   - Width: Approximately 100 pixels.
   - Height: Approximately 20 pixels.
   - Position: Located directly below the top bar.
   - Spacing: There is a 20-pixel space between this bar and the bottom bar.

3. **Bottom Bar:**
   - Color: Light beige or cream.
   - Width: Approximately 100 pixels.
   - Height: Approximately 20 pixels.
   - Position: Located at the bottom of the image.
   - Spacing: There is a 20-pixel space between this bar and the middle bar.

The bars are evenly spaced, with a consistent 20-pixel gap between each bar. The image appears to be a simple representation, possibly used for design or layout purposes, showcasing the use of color and spacing in a graphical context.
##Image Name: arrangement-direction-row.png
###Image description: The image depicts a diagram illustrating the concept of a "row" in a layout context, specifically in a graphical user interface (GUI) design. The diagram consists of three vertical bars, each representing a column or element within the row. The columns are arranged horizontally, with spaces between them.

Here is a detailed description of the image:

1. **Title**: The title at the top of the image is "Row."
2. **Columns**: There are three vertical bars, each colored blue. These bars represent the columns within the row.
3. **Spaces**: There are two spaces indicated between the columns. These spaces are labeled with the word "space" and arrows pointing towards them, indicating the direction of the spacing.

### Analysis and Description

- **Title**: The title "Row" indicates that the diagram is focused on the concept of a row in a layout context.
- **Columns**: The three blue vertical bars represent the columns within the row. Each column is separated from the others by spaces.
- **Spaces**: The spaces between the columns are crucial in determining the layout and spacing within the row. The arrows pointing towards the spaces suggest that the spacing is intentional and can be adjusted.

### Relevant Knowledge

In GUI design, rows and columns are fundamental components used to organize and layout content. The spacing between columns can affect the readability and aesthetics of the layout. Adjusting the spacing can help in creating a more balanced and visually appealing design.

### Answer to Potential Questions

1. **What does the title "Row" signify?**
   - The title "Row" signifies that the diagram is focused on the concept of a row in a layout context, specifically in a GUI design.

2. **How many columns are there in the row?**
   - There are three columns in the row.

3. **What is the purpose of the spaces between the columns?**
   - The spaces between the columns are used to adjust the spacing within the row, which can affect the readability and aesthetics of the layout.

4. **What does the arrow pointing towards the space indicate?**
   - The arrow pointing towards the space indicates the direction of the spacing, suggesting that the spacing is intentional and can be adjusted.

By understanding the components and their relationships in the diagram, one can better comprehend the principles of layout design in GUIs.
##Image Name: en-us_image_0000001562700509.png
###Image description: The image displays a simple graphical representation consisting of three vertical bars. The bars are arranged horizontally across the image. The first and third bars are light yellow in color, while the middle bar is a darker shade of yellow. The bars are evenly spaced, with a specified space of 35 units between them. The text "space: 35" is placed above the bars, indicating the distance between each bar.
##Image Name: horizontal-arrangement-child-column.png
###Image description: The image consists of three panels, each containing three blue rectangular items labeled "Item1," "Item2," and "Item3." The panels are arranged horizontally, and each panel has a different horizontal alignment applied to the items within it. Here is a detailed description of each panel:

1. **Left Panel (HorizontalAlign.Start):**
   - The first panel on the left has the horizontal alignment set to "HorizontalAlign.Start."
   - The items are aligned to the left edge of the panel.
   - The first item ("Item1") is positioned at the leftmost edge of the panel.
   - The second item ("Item2") is positioned to the right of the first item.
   - The third item ("Item3") is positioned to the right of the second item.

2. **Middle Panel (HorizontalAlign.Center):**
   - The second panel in the middle has the horizontal alignment set to "HorizontalAlign.Center."
   - The items are centered within the panel.
   - The first item ("Item1") is positioned in the center of the panel.
   - The second item ("Item2") is positioned to the left of the first item.
   - The third item ("Item3") is positioned to the right of the first item.

3. **Right Panel (HorizontalAlign.End):**
   - The third panel on the right has the horizontal alignment set to "HorizontalAlign.End."
   - The items are aligned to the right edge of the panel.
   - The first item ("Item1") is positioned at the rightmost edge of the panel.
   - The second item ("Item2") is positioned to the left of the first item.
   - The third item ("Item3") is positioned to the left of the second item.

Each panel demonstrates how the horizontal alignment affects the positioning of the items within the panel.
##Image Name: en-us_image_0000001511580964.png
###Image description: The image consists of three horizontal stripes of varying colors. The top stripe is a light beige color, the middle stripe is a medium brown color, and the bottom stripe is a darker brown color. The background of the image is white. The stripes are evenly spaced and appear to be of equal width. The image has a simple and clean design, with no additional elements or text present.
##Image Name: en-us_image_0000001562820897.png
###Image description: The image consists of a rectangular shape divided into three horizontal sections. The top and bottom sections are light beige in color, while the middle section is a slightly darker shade of beige. The overall design is simple and minimalistic, with no additional elements or text present.
##Image Name: en-us_image_0000001511421348.png
###Image description: The image consists of a simple geometric design featuring three horizontal stripes. The stripes are arranged from top to bottom in a gradient of beige and brown tones. The topmost stripe is a light beige color, the middle stripe is a medium beige, and the bottom stripe is a darker brown. The background of the image is a light beige color, which matches the topmost stripe. The overall design is minimalistic and uses a limited color palette.
##Image Name: horizontal-arrangement-child-row.png
###Image description: The image shows three horizontal rows of three blue rectangular items labeled "Item1," "Item2," and "Item3." Each row has a different vertical alignment setting, as indicated by the text above each row. The vertical alignment settings are:

1. **VerticalAlign.Top**: This row has the items aligned at the top of the row.
2. **VerticalAlign.Center**: This row has the items aligned in the center of the row.
3. **VerticalAlign.Bottom**: This row has the items aligned at the bottom of the row.

The background of the image is light gray, and the text is black, making it easy to read the alignment settings.
##Image Name: en-us_image_0000001563060765.png
###Image description: The image consists of a simple, minimalist design featuring three horizontal rectangular sections. Each section is filled with a different shade of beige or light brown. The topmost section is the lightest, followed by a slightly darker shade in the middle, and the bottom section is the darkest among the three. The background of the image is plain white, which contrasts with the beige tones of the rectangular sections. There are no additional objects, text, or patterns present in the image. The overall aesthetic is clean and uncluttered, with a focus on the gradient of beige shades.
##Image Name: en-us_image_0000001562700505.png
###Image description: The image shows a simple, minimalist design consisting of two horizontal bars. The bars are positioned horizontally across the image. The left bar is a light beige color, while the right bar is a slightly darker shade of beige. The background of the image is a plain, light gray color. The overall design is very clean and modern, with a focus on simplicity and minimalism.
##Image Name: en-us_image_0000001563060781.png
###Image description: The image is a simple, minimalist design featuring a horizontal split. The top half of the image is white, while the bottom half is divided into three horizontal sections. The first section from the left is a light beige color, the second section is a darker beige or tan color, and the third section is a light beige color again. The overall design is clean and modern, with a focus on simplicity and contrast.
##Image Name: vertial-arrangement-child-column.png
###Image description: The image consists of six diagrams, each representing a different arrangement of three items labeled as Item1, Item2, and Item3. The diagrams are arranged in two rows and three columns, with each diagram showing the relative positions and spacing between the items. The items are depicted as rectangular boxes, and the spacing between them is indicated by blue arrows pointing upwards, with numerical values next to them representing the spacing in units.

### Diagrams Description:

1. **Top Left Diagram:**
   - Item1 is at the top.
   - Item2 is directly below Item1.
   - Item3 is directly below Item2.
   - There are no arrows indicating spacing between the items.

2. **Top Middle Diagram:**
   - Item1 is at the top.
   - Item2 is directly below Item1.
   - Item3 is directly below Item2.
   - There are arrows pointing upwards from Item1 to Item2 and from Item2 to Item3, with the value "1" next to each arrow, indicating the spacing between the items.

3. **Top Right Diagram:**
   - Item1 is at the top.
   - Item2 is directly below Item1.
   - Item3 is directly below Item2.
   - There are arrows pointing upwards from Item1 to Item2 and from Item2 to Item3, with the value "1" next to each arrow, indicating the spacing between the items.

4. **Bottom Left Diagram:**
   - Item1 is at the top.
   - Item2 is directly below Item1.
   - Item3 is directly below Item2.
   - There are arrows pointing upwards from Item1 to Item2 and from Item2 to Item3, with the value "1" next to each arrow, indicating the spacing between the items.

5. **Bottom Middle Diagram:**
   - Item1 is at the top.
   - Item2 is directly below Item1.
   - Item3 is directly below Item2.
   - There are arrows pointing upwards from Item1 to Item2 and from Item2 to Item3, with the value "0.5" next to each arrow, indicating the spacing between the items.

6. **Bottom Right Diagram:**
   - Item1 is at the top.
   - Item2 is directly below Item1.
   - Item3 is directly below Item2.
   - There are arrows pointing upwards from Item1 to Item2 and from Item2 to Item3, with the value "1" next to each arrow, indicating the spacing between the items.

### Analysis:

- **Top Row Diagrams:**
  - All diagrams in the top row show the items in a vertical arrangement with no spacing between them.
  - The arrows indicate the direction of the items but do not show any spacing.

- **Bottom Row Diagrams:**
  - The bottom row diagrams show the items in a vertical arrangement with spacing between them.
  - The spacing is indicated by the arrows pointing upwards with the value "0.5" or "1" next to each arrow, showing the distance between the items.

### Conclusion:

The diagrams illustrate different arrangements and spacings of three items labeled Item1, Item2, and Item3. The top row diagrams show the items without any spacing, while the bottom row diagrams show the items with spacing of either 0.5 or 1 unit. The arrows indicate the direction and spacing between the items.
##Image Name: en-us_image_0000001562700501.png
###Image description: The image consists of a rectangular shape divided into three horizontal stripes. The top and bottom stripes are light beige in color, while the middle stripe is a slightly darker shade of beige. The overall design is simple and minimalistic, with no additional elements or text present.
##Image Name: en-us_image_0000001562700517.png
###Image description: The image depicts a rectangular shape divided into three horizontal sections. The top and bottom sections are light beige in color, while the middle section is a slightly darker shade of beige. The overall design is simple and minimalistic, with no additional elements or text present.
##Image Name: en-us_image_0000001562940585.png
###Image description: The image depicts a rectangular shape divided into three horizontal stripes. The top and bottom stripes are light beige, while the middle stripe is a slightly darker shade of beige. The overall design is simple and minimalistic.
##Image Name: en-us_image_0000001511900532.png
###Image description: The image consists of three horizontal rectangular sections. The top and bottom sections are light yellow in color, while the middle section is a slightly darker shade of yellow. The middle section is wider than the top and bottom sections. The overall design is simple and minimalistic.
##Image Name: en-us_image_0000001562700525.png
###Image description: The image consists of three horizontal bars of different colors and lengths. The top bar is light yellow, the middle bar is a darker shade of yellow, and the bottom bar is a light beige color. The bars are arranged in a horizontal line from left to right.
##Image Name: en-us_image_0000001563060785.png
###Image description: The image consists of three horizontal bars of varying colors and lengths. The bars are arranged in a vertical sequence from top to bottom. 

1. The top bar is light yellow in color and is the shortest among the three bars.
2. The middle bar is a darker shade of yellow and is the longest bar in the image.
3. The bottom bar is also light yellow in color and is shorter than the top bar but longer than the middle bar.

The bars are evenly spaced, with a consistent gap between each bar. The background of the image is a light gray color, which contrasts with the yellow bars, making them stand out clearly. 

The image appears to be a simple graphical representation, possibly used for illustrative purposes, such as demonstrating color variations or length differences. There are no additional elements or text present in the image. 

This description provides a clear and detailed account of the image, focusing solely on the objects present and their characteristics without any unnecessary sensory expressions or aesthetic interpretations.
##Image Name: vertial-arrangement-child-row.png
###Image description: The image is a diagram illustrating the effects of different justifyContent alignments on a flex container with three items. The diagram is divided into four sections, each representing a different justifyContent value: Start, SpaceBetween, SpaceAround, and SpaceEvenly. Each section shows the layout of the items within the flex container and the spacing between them.

### JustifyContent: Start
- **Description**: The items are aligned to the start of the flex container.
- **Layout**: Item1 is aligned to the left edge of the container, Item2 is centered horizontally between Item1 and Item3, and Item3 is aligned to the right edge of the container.
- **Spacing**: There is no explicit spacing between the items.

### JustifyContent: SpaceBetween
- **Description**: The items are evenly spaced within the flex container.
- **Layout**: Each item has an equal amount of space between it and the adjacent items.
- **Spacing**: There is a consistent gap of 1 unit between each item.

### JustifyContent: SpaceAround
- **Description**: The items are evenly spaced around the container, including the edges.
- **Layout**: Each item has an equal amount of space around it, including the edges of the container.
- **Spacing**: There is a consistent gap of 0.5 units between each item and the edges of the container.

### JustifyContent: SpaceEvenly
- **Description**: The items are evenly spaced within the flex container, similar to SpaceBetween.
- **Layout**: Each item has an equal amount of space between it and the adjacent items.
- **Spacing**: There is a consistent gap of 1 unit between each item.

### Analysis
- **Start**: This alignment places the first item at the start of the container and the last item at the end, with the middle item centered.
- **SpaceBetween**: This alignment evenly distributes the space between each item.
- **SpaceAround**: This alignment evenly distributes the space around each item, including the edges of the container.
- **SpaceEvenly**: This alignment is similar to SpaceBetween, evenly distributing the space between each item.

### Conclusion
The diagram effectively demonstrates how different justifyContent values affect the layout and spacing of items within a flex container. Understanding these alignments is crucial for designing responsive and visually appealing layouts in user interfaces.
##Image Name: en-us_image_0000001511421356.png
###Image description: The image depicts a simple, minimalist design consisting of three horizontal bars. The bars are arranged horizontally across the image, with each bar having a distinct color. The leftmost bar is a light beige color, the middle bar is a darker beige color, and the rightmost bar is a light brown color. The background of the image is white, which contrasts with the colors of the bars, making them stand out prominently. The bars are evenly spaced, and there are no other objects or elements present in the image. The overall design is clean and straightforward, with a focus on the color differentiation between the bars.
##Image Name: en-us_image_0000001511900516.png
###Image description: The image depicts a simple, rectangular shape divided into three horizontal segments. The segments are colored differently, with the top and bottom segments being a light beige color, and the middle segment being a slightly darker beige color. The overall design is minimalistic and uses a limited color palette.
##Image Name: en-us_image_0000001562940601.png
###Image description: The image depicts a simple, minimalist design consisting of three horizontal bars. The bars are arranged horizontally across the image, with each bar having a distinct color. The leftmost bar is a light beige color, the middle bar is a darker beige color, and the rightmost bar is a light brown color. The background of the image is plain white, which contrasts with the colored bars, making them stand out prominently. The bars are evenly spaced, and there are no other objects or elements present in the image. The overall design is clean and straightforward, with a focus on the color differentiation between the bars.
##Image Name: en-us_image_0000001562700521.png
###Image description: The image consists of a simple, minimalist design featuring three horizontal rectangular shapes. These shapes are arranged in a horizontal line, with two smaller rectangles flanking a larger rectangle in the center. The background is a light, neutral color, possibly white or a very light gray. The rectangles themselves are in a gradient of beige and light brown tones, creating a subtle contrast against the background. The overall design is clean and modern, with a focus on simplicity and minimalism.
##Image Name: en-us_image_0000001562820893.png
###Image description: The image consists of three rectangular shapes arranged horizontally. The background is a light gray color. The rectangles are of different sizes and colors:

1. The first rectangle on the left is light yellow.
2. The second rectangle in the middle is a beige color.
3. The third rectangle on the right is also light yellow.

The rectangles are evenly spaced, with the beige rectangle positioned centrally between the two light yellow rectangles. The overall layout is simple and symmetrical.
##Image Name: en-us_image_0000001511421352.png
###Image description: The image consists of three rectangular shapes arranged horizontally. The background is a light gray color. The three rectangles are of different sizes and colors:

1. The first rectangle on the left is light yellow.
2. The second rectangle in the middle is a slightly darker shade of yellow.
3. The third rectangle on the right is also light yellow, similar in color to the first rectangle.

The rectangles are evenly spaced, with equal distances between each of them. The overall arrangement is simple and symmetrical.
##Image Name: en-us_image_0000001562820881.png
###Image description: The image shows a simple interface element, likely from a settings menu or a control panel. The text "Bluetooth" is displayed prominently in the center of the image. To the right of the text, there is a toggle switch, which is currently in the "on" position, indicated by the blue color and the position of the switch. The background of the interface is a light gray color, providing a clean and minimalistic look.
##Image Name: en-us_image_0000001511421332.png
###Image description: The image shows a simple interface element, likely from a settings menu or a control panel. The interface element is a toggle switch labeled "Bluetooth." The toggle switch is currently in the "on" position, indicated by the blue color of the switch and the blue checkmark. The background of the interface is a light gray color.
##Image Name: en-us_image_0000001511421336.png
###Image description: The image consists of two sections, each containing a layout with three rectangular components. The layout components are colored in different shades of brown and yellow, and each section has a different ratio of layout weights assigned to the components. The layout weights are represented by the numbers within parentheses next to each component.

### Top Section:
- **Ratio:** 1:2:3
- **Components:**
  - The first component has a layout weight of 1.
  - The second component has a layout weight of 2.
  - The third component has a layout weight of 3.

### Bottom Section:
- **Ratio:** 2:5:3
- **Components:**
  - The first component has a layout weight of 2.
  - The second component has a layout weight of 5.
  - The third component has a layout weight of 3.

### Analysis:
1. **Top Section:**
   - The first component has a layout weight of 1, which means it will occupy 1/6 of the total space.
   - The second component has a layout weight of 2, which means it will occupy 2/6 or 1/3 of the total space.
   - The third component has a layout weight of 3, which means it will occupy 3/6 or 1/2 of the total space.

2. **Bottom Section:**
   - The first component has a layout weight of 2, which means it will occupy 2/10 or 1/5 of the total space.
   - The second component has a layout weight of 5, which means it will occupy 5/10 or 1/2 of the total space.
   - The third component has a layout weight of 3, which means it will occupy 3/10 of the total space.

### Conclusion:
The image demonstrates how different layout weights affect the distribution of space among components in a layout. The top section shows a simpler ratio (1:2:3), while the bottom section shows a more complex ratio (2:5:3). The layout weights determine the proportion of space each component occupies, with higher weights leading to larger portions of the total space.
##Image Name: en-us_image_0000001511580968.png
###Image description: The image consists of two sections, each containing three rectangular boxes with different colors and labels. The boxes are arranged horizontally and have varying widths. The labels within the boxes indicate the `layoutWeight` values assigned to each box. The colors of the boxes are as follows:

1. The top section has three boxes with the following colors and labels:
   - The first box is light yellow and labeled `layoutWeight(1)`.
   - The second box is a medium brown color and labeled `layoutWeight(2)`.
   - The third box is a light brown color and labeled `layoutWeight(3)`.

2. The bottom section has three boxes with the following colors and labels:
   - The first box is light yellow and labeled `layoutWeight(2)`.
   - The second box is a medium brown color and labeled `layoutWeight(5)`.
   - The third box is a light brown color and labeled `layoutWeight(3)`.

### Analysis and Description

#### Top Section:
- **Boxes and Colors**: The top section has three boxes with different colors.
  - The first box is light yellow.
  - The second box is medium brown.
  - The third box is light brown.
- **Labels**: Each box is labeled with `layoutWeight` values.
  - The first box is labeled `layoutWeight(1)`.
  - The second box is labeled `layoutWeight(2)`.
  - The third box is labeled `layoutWeight(3)`.

#### Bottom Section:
- **Boxes and Colors**: The bottom section also has three boxes with different colors.
  - The first box is light yellow.
  - The second box is medium brown.
  - The third box is light brown.
- **Labels**: Each box is labeled with `layoutWeight` values.
  - The first box is labeled `layoutWeight(2)`.
  - The second box is labeled `layoutWeight(5)`.
  - The third box is labeled `layoutWeight(3)`.

### Relevant Knowledge:
In Android layout systems, `layoutWeight` is a property used to distribute space among layout items. The `layoutWeight` value determines how much space each item will take up in the layout. A higher `layoutWeight` value means the item will take up more space. The total space is divided among all items based on their `layoutWeight` values.

### Answer to Potential Questions:
1. **What are the colors of the boxes in the top section?**
   - The colors of the boxes in the top section are light yellow, medium brown, and light brown.

2. **What are the `layoutWeight` values of the boxes in the top section?**
   - The `layoutWeight` values of the boxes in the top section are 1, 2, and 3, respectively.

3. **What are the colors of the boxes in the bottom section?**
   - The colors of the boxes in the bottom section are light yellow, medium brown, and light brown.

4. **What are the `layoutWeight` values of the boxes in the bottom section?**
   - The `layoutWeight` values of the boxes in the bottom section are 2, 5, and 3, respectively.

5. **How are the boxes arranged in the top and bottom sections?**
   - The boxes are arranged horizontally in both sections. The first box is on the left, the second box is in the middle, and the third box is on the right.

By understanding the layout and the `layoutWeight` values, one can predict how the space will be distributed among the boxes in the layout.
##Image Name: en-us_image_0000001563060777.png
###Image description: The image is a simple graphical representation that illustrates the concept of dividing a space into three sections with specific width percentages. The image is divided into three horizontal sections, each with a different width percentage. Here is a detailed description of the image:

1. **Left Section:**
   - **Width:** 20%
   - **Color:** Light beige
   - **Description:** This section is the leftmost part of the image and occupies 20% of the total width. It is colored in a light beige shade.

2. **Center Section:**
   - **Width:** 50%
   - **Color:** Beige
   - **Description:** This section is the middle part of the image and occupies 50% of the total width. It is colored in a beige shade, which is slightly darker than the light beige of the left section.

3. **Right Section:**
   - **Width:** 30%
   - **Color:** Light beige
   - **Description:** This section is the rightmost part of the image and occupies 30% of the total width. It is colored in a light beige shade, similar to the left section.

### Analysis and Description:

The image is a visual representation of how a space can be divided into three equal parts based on width percentages. The left section is 20% of the total width, the center section is 50%, and the right section is 30%. This division is symmetrical, with the center section being the largest and the left and right sections being equal in width but smaller than the center.

### Relevant Knowledge:

This type of division is often used in web design, layout design, and other graphical contexts where it is necessary to allocate space in a proportional manner. The percentages used (20%, 50%, and 30%) are common in design to create balanced and aesthetically pleasing layouts. The use of light beige and beige colors helps in maintaining a consistent visual flow and ensures that the sections are easily distinguishable from each other.

### Conclusion:

The image effectively demonstrates the concept of dividing a space into three sections with specific width percentages. The left and right sections are equal in width, each occupying 20% of the total width, while the center section is wider, occupying 50% of the total width. This visual representation can be useful for understanding how to allocate space in a layout based on percentage widths.
##Image Name: en-us_image_0000001511740564.png
###Image description: The image consists of three vertical sections with different shades of brown and beige. The left section is a light beige color and occupies 20% of the width. The middle section is a darker brown color and occupies 50% of the width. The right section is a light brown color and occupies 30% of the width. The sections are arranged side by side, creating a visual representation of the specified width percentages.
