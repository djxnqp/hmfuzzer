# Touchscreen Event


Touchscreen events are events triggered when a finger or stylus is placed on, moved along, or lifted from a component. They can be classified as [click event](#click-event), [drag event](arkts-common-events-drag-event.md), or [touch event](#touch-event).


**Figure 1** Touchscreen event principles


![en-us_image_0000001562700461](figures/en-us_image_0000001562700461.png)


## Click Event

A click event is triggered when a complete press and lift action is performed by using a finger or a stylus. When a click event occurs, the following callback is triggered:



```ts
onClick(event: (event?: ClickEvent) => void)
```


The **event** parameter provides the coordinates of the click relative to the window or component as well as the event source where the click occurs, for example, a button, a click on which shows or hides an image.

```ts
@Entry
@Component
struct IfElseTransition {
  @State flag: boolean = true;
  @State btnMsg: string = 'show';

  build() {
    Column() {
      Button(this.btnMsg).width(80).height(30).margin(30)
        .onClick(() => {
          if (this.flag) {
            this.btnMsg = 'hide';
          } else {
            this.btnMsg = 'show';
          }
          // Click the button to show or hide the image.
          this.flag = !this.flag;
        })
      if (this.flag) {
        Image($r('app.media.icon')).width(200).height(200)
      }
    }.height('100%').width('100%')
  }
}
```
**Figure 2** Showing or hiding an image through the click event of a button


![ClickEventControl.gif](figures/ClickEventControl.gif)



## Touch Event

A touch event is triggered when a finger or stylus is placed on, moved along, or lifted from a component.


```ts
onTouch(event: (event?: TouchEvent) => void)
```

- If **event.type** is **TouchType.Down**, the finger or stylus is placed on the component.

- If **event.type** is **TouchType.Up**, the finger or stylus is lifted from the component.

- If **event.type** is **TouchType.Move**, the finger or stylus is moved along the component.

- If **event.type** is **TouchType.Cancel**, the current finger operation is interrupted and canceled.

The touch event supports single and multi-touch interactions. Information about the touch event can be obtained using the **event** parameter, such as the location of the finger that triggers the event, unique identifier of the finger, finger information changed, and the input device source.


```ts
// xxx.ets
@Entry
@Component
struct TouchExample {
  @State text: string = '';
  @State eventType: string = '';

  build() {
    Column() {
      Button('Touch').height(40).width(100)
        .onTouch((event?: TouchEvent) => {
          if(event){
            if (event.type === TouchType.Down) {
              this.eventType = 'Down';
            }
            if (event.type === TouchType.Up) {
              this.eventType = 'Up';
            }
            if (event.type === TouchType.Move) {
              this.eventType = 'Move';
            }
            this.text = 'TouchType:' + this.eventType + '\nDistance between touch point and touch element:\nx: '
            + event.touches[0].x + '\n' + 'y: ' + event.touches[0].y + '\nComponent globalPos:('
            + event.target.area.globalPosition.x + ',' + event.target.area.globalPosition.y + ')\nwidth:'
            + event.target.area.width + '\nheight:' + event.target.area.height
          }
        })
      Button('Touch').height(50).width(200).margin(20)
        .onTouch((event?: TouchEvent) => {
          if(event){
            if (event.type === TouchType.Down) {
              this.eventType = 'Down';
            }
            if (event.type === TouchType.Up) {
              this.eventType = 'Up';
            }
            if (event.type === TouchType.Move) {
              this.eventType = 'Move';
            }
            this.text = 'TouchType:' + this.eventType + '\nDistance between touch point and touch element:\nx: '
            + event.touches[0].x + '\n' + 'y: ' + event.touches[0].y + '\nComponent globalPos:('
            + event.target.area.globalPosition.x + ',' + event.target.area.globalPosition.y + ')\nwidth:'
            + event.target.area.width + '\nheight:' + event.target.area.height
          }
        })
      Text(this.text)
    }.width('100%').padding(30)
  }
}
```


![en-us_image_0000001511900468](figures/en-us_image_0000001511900468.gif)
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: en-us_image_0000001562700461.png
###Image description: The image is a diagram illustrating the architecture of a touchscreen system, specifically focusing on the interaction between the touchscreen and the software components that process input. Here is a detailed description of the components and their interactions:

1. **Touchscreen**: This is the physical input device that captures user interactions such as taps, swipes, and touches.

2. **Driver**: This component is responsible for translating the raw input data from the touchscreen into a format that can be understood by the higher-level software components. It handles the low-level communication between the touchscreen hardware and the software.

3. **Multimodal Input**: This component processes the input data from the touchscreen and other input devices (e.g., keyboards, mice) to provide a unified input stream to the software. It ensures that different types of input are handled consistently and efficiently.

4. **Window**: This component represents the graphical user interface (GUI) layer. It is responsible for displaying the application windows and managing the layout and appearance of the user interface.

5. **ArkUI**: This is a software framework or library that provides a set of tools and APIs for developing applications that run on the touchscreen system. ArkUI likely handles the rendering of the user interface and provides a high-level abstraction for interacting with the window and other UI components.

6. **Callback by developer**: This represents the interaction between the developer and the software framework. Developers can write custom code to handle specific events or actions, such as responding to user inputs or triggering certain behaviors in the application.

The flow of data in the diagram is as follows:
- The touchscreen captures user interactions and sends raw input data to the driver.
- The driver processes this data and passes it to the multimodal input component.
- The multimodal input component combines and processes the input data, possibly integrating it with data from other input devices.
- The processed input data is then passed to the window component, which displays the user interface.
- The window component interacts with ArkUI, which handles the rendering and management of the user interface.
- Finally, the developer can write custom code to handle specific events or actions, as indicated by the "Callback by developer" box.

This diagram provides a clear overview of how different components work together to process and respond to user input on a touchscreen system.
