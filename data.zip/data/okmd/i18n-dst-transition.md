# DST Transition


## Use Cases

DST is a local time system that sees manual adjustment to the time with the aim of saving energy in certain countries/regions. Time in DST is one hour faster than that in GMT.


## How It Works

When the local time reaches the DST transition point, DST transition is automatically implemented based on the DST transition rules configured in the system. If an application uses a common TS API, for example, **Date()**, to obtain and display the time, it also displays the DST time when the DST transition time is reached.

The DST transition rules are as follows:

1. Calculate the number of hours in a day.
   The number of hours in a day changes on the day of DST transition. On the day when DST starts, there are 23 hours. On the day when the DST ends, there are 25 hours.

   Calculate the number of hours between the same clock time before and after the DST transition. The sample code is as follows:
   ```ts
   import { i18n } from '@kit.LocalizationKit';

   let calendar = i18n.getCalendar("zh-Hans");
   calendar.setTimeZone("Europe/London");
   calendar.set(2021, 2, 27, 16, 0, 0); //The day before daylight saving time start
   let time1 = calendar.getTimeInMillis();
   calendar.set(2021, 2, 28, 16, 0, 0); //The day daylight saving time start
   let time2 = calendar.getTimeInMillis();
   let hours = (time2 - time1)/(3600*1000) //The hours between the same wall clock time before and after DST. Should be 23
   ```

2. Store and display time data.
   Store and display time data according to the local DST timing rules. The time gap and repetition caused by DST transition need to be processed.

   When DST starts, one hour is missing, for example, 1:59:59→3:00:00. When DST ends, one hour is repeated, for example, 3:59:59→3:00:00.

   It is recommended that the DST flag be added to the local time when DST is active.

   ![DST flag](figures/dst-transition.png)

3. Store and transmit time data.
   You are advised to use the standard time (UTC or GMT) of time zone 0 for time data storage and transmission. This helps prevent data loss or errors caused by DST transition.
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: dst-transition.png
###Image description: The image is a timeline diagram illustrating the transition periods for Daylight Saving Time (DST) in a specific region. The timeline is marked with specific dates and times, and it highlights the local time changes due to DST transitions. The timeline is divided into four main segments, each representing a different phase of the DST transition process.

### Description of the Timeline:

1. **Transition into DST Started (April 1, 01:59:59)**
   - This segment marks the beginning of the transition into Daylight Saving Time. The timeline shows a blue bar indicating the start of the DST transition process.

2. **Transition into DST Completed (April 1, 03:00:00)**
   - This segment shows the completion of the transition into DST. The timeline displays a horizontal line indicating the end of the DST transition period. The transition into DST is completed at 03:00:00.

3. **Transition out of DST Completed (November 1, 03:00:00)**
   - This segment marks the completion of the transition out of DST. The timeline shows a horizontal line indicating the end of the DST transition period. The transition out of DST is completed at 03:00:00.

4. **Transition out of DST Started (November 1, 03:59:59)**
   - This segment marks the beginning of the transition out of DST. The timeline shows a blue bar indicating the start of the DST transition process.

### Key Points:

- **Local Time Gap Due to DST Transition:**
  - There is a local time gap due to the DST transition, which is indicated by a dashed line between the transition into DST completed and the transition out of DST completed. This gap occurs because the transition into DST is completed at 03:00:00, while the transition out of DST is started at 03:59:59.

- **Local Time Repetition Due to DST Transition:**
  - There is a local time repetition due to the DST transition, which is indicated by a dashed line between the transition out of DST completed and the transition out of DST started. This repetition occurs because the transition out of DST is started at 03:59:59, which is the same time as the transition into DST started.

### Analysis:

The timeline diagram effectively illustrates the transition periods for DST, highlighting the local time changes and the gaps and repetitions that occur during these transitions. The transition into DST starts at 01:59:59 on April 1 and is completed at 03:00:00. Conversely, the transition out of DST starts at 03:59:59 on November 1 and is completed at 03:00:00. The local time gap and repetition are critical aspects to understand the impact of DST on local timekeeping.

### Conclusion:

This timeline diagram provides a clear visual representation of the DST transition process, emphasizing the local time changes and the gaps and repetitions that occur during these transitions. Understanding these details is crucial for individuals and organizations that need to adjust their schedules and operations accordingly.
