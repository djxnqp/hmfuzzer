# Cross-Device Sync of KV Stores


## When to Use

KV Stores are suitable for storing service data with simple relationships. It provides higher read and write performance than the SQL database. KV stores are widely used because the simplicity of the KV data model poses fewer database version compatibility issues in distributed scenarios and simplifies conflict handling in data sync.


## Basic Concepts

Before implementing cross-device sync of KV stores, understand the following concepts:


### Single KV Store

In a single KV store, data is saved in the unit of a single entry. When data is modified locally, the data entry is updated no matter whether it has been synced. Only one copy of data is retained globally for multiple devices. The data of the latest time is kept for the same entry (with the same primary code) of multiple devices. The data in single KV stores is not differentiated by device. If the data modified on multiple devices has the same key, the value will be overwritten. For the data written or modified locally, the data with the latest time is synced to other devices. Single KV stores are used to store information, such as the Contacts and weather application data.

![singleKVStore](figures/singleKVStore.jpg)


### Device KV Store

In a device KV store, the local device ID is added before the key of the KV pair stored by an application. In this way, the data of different devices is isolated. Data is managed by device and can be queried by device.

The underlying devices manage the data by device. The device KV stores support distributed data query by device, but do not support modification of the data synced from peer devices. Device KV stores are used to store the data that needs to be accessed by device, such as the Gallery thumbnails.

![deviceKVStore](figures/deviceKVStore.jpg)


## Sync Types

**DatamgrService** provides the following sync types:

### Manual Sync

The application calls **sync()** with the devices to be synced and the sync mode specified to trigger the sync. The sync mode can be **PULL_ONLY** (pulling remote data to the local end), **PUSH_ONLY** (pushing local data to the remote end), or **PUSH_PULL** (pushing local data to the remote end and pulling remote data to the local end). You can use the [**sync()** with the **query** parameter](../reference/apis-arkdata/js-apis-distributedKVStore.md#sync-1) to synchronize the data that meets the specified conditions.

### Auto Sync

<!--RP5-->
In [multi-device collaboration via cross-device calls](../application-models/hop-multi-device-collaboration.md#using-cross-device-call), after an application updates data, the distributed database automatically pushes the local data to the peer ends and pulls the peer data to the local device for data sync. In this case, the application does not need to call **sync()**.<!--RP5End-->


## Working Principles

After completing device discovery and authentication, the underlying communication component notifies the application that the device goes online. The **DatamgrService** then establishes an encrypted transmission channel to synchronize data between the two devices.


### Cross-Device Data Sync Mechanism

![kvStore](figures/kvStore.jpg)

When **put()** or **delete()** is called successfully, an auto sync is triggered. The distributed data is sent to the peer device through the communication adaptation layer for sync.

If **sync()** is called successfully, a manual sync is triggered to send distributed data to the peer device through the communication adaptation layer.


### Data Change Notification Mechanism

When data is added, deleted, or modified, a notification is sent to the subscriber. The notifications can be classified into the following types:

- Local data change notification: subscription of the application data changes on the local device. When the data in the local KV store is added, deleted, or modified in the database, a notification is received.

- Distributed data change notification: subscription of the application data changes of other devices in the network. When the data in the local KV store changes after being synced with data from another device in the same network, a notification is received.


## Constraints

- For each record in a device KV store, the key cannot exceed 896 bytes and the value cannot exceed 4 MB.

- For each record in a single KV store, the key cannot exceed 1 KB and the value cannot exceed 4 MB.

- The KV stores do not support custom conflict resolution policies for applications.

- A maximum of 16 KV stores can be opened simultaneously for an application.

- Each KV store supports a maximum of eight callbacks for subscription of data change notifications.


## Available APIs

The following table lists the APIs for cross-device data sync of the single KV store. Most of the APIs are executed asynchronously, using a callback or promise to return the result. The following table uses the callback-based APIs as an example. For more information about the APIs, see [Distributed KV Store](../reference/apis-arkdata/js-apis-distributedKVStore.md).

| API| Description|
| -------- | -------- |
| createKVManager(config: KVManagerConfig): KVManager | Creates a **KvManager** instance to manage database objects.|
| getKVStore&lt;T&gt;(storeId: string, options: Options, callback: AsyncCallback&lt;T&gt;): void | Obtains a KV store of the specified type.|
| put(key: string, value: Uint8Array \| string \| number \| boolean, callback: AsyncCallback&lt;void&gt;): void | Inserts and updates data.|
| on(event: 'dataChange', type: SubscribeType, listener: Callback&lt;ChangeNotification&gt;): void | Subscribes to data changes in the KV store.|
| get(key: string, callback: AsyncCallback&lt;boolean \| string \| number \| Uint8Array&gt;): void | Queries the value of the specified key.|
| sync(deviceIds: string[], mode: SyncMode, delayMs?: number): void | Triggers a manual sync of the KV store.|


## How to Develop

The following uses a single KV store as an example to describe how to implement cross-device data sync. The development process is as follows.

![kvStore_development_process](figures/kvStore_development_process.png)

> **NOTE**
>
> The security level of the destination device (to which data is synced) cannot be higher than that of the source device. For details, see [Access Control Mechanism in Cross-Device Sync](access-control-by-device-and-data-level.md#access-control-mechanism-in-cross-device-sync).

1. Import the module.
   
   ```ts
   import { distributedKVStore } from '@kit.ArkData';
   ```

2. Request permissions.

   (1) Declare the **ohos.permission.DISTRIBUTED_DATASYNC** permission. For details, see [Declaring Permissions](../security/AccessToken/declare-permissions.md).
   (2) Display a dialog box to ask for user authorization when the application is started for the first time. For details, see [Requesting User Authorization](../security/AccessToken/request-user-authorization.md).

3. Create a **KvManager** instance based on the specified **KvManagerConfig** object.

   (1) Create a **kvManagerConfig** object based on the application context.
   (2) Create a **KvManager** instance.

   
   ```ts
   // Obtain the context of the stage model.
   import { window } from '@kit.ArkUI';
   import { UIAbility } from '@kit.AbilityKit';
   import { BusinessError } from '@kit.BasicServicesKit';
   
   let kvManager: distributedKVStore.KVManager | undefined = undefined;
   
   class EntryAbility extends UIAbility {
     onWindowStageCreate(windowStage:window.WindowStage) {
       let context = this.context;
     }
   }
    
    // Obtain the context of the FA model.
   import { featureAbility } from '@kit.AbilityKit';
   import { BusinessError } from '@kit.BasicServicesKit';
    
   let context = featureAbility.getContext();
   
   // Construct a kvManager instance.
   try {
     const kvManagerConfig: distributedKVStore.KVManagerConfig = {
       bundleName: 'com.example.datamanagertest',
       context: context
     }
     kvManager = distributedKVStore.createKVManager(kvManagerConfig);
     console.info('Succeeded in creating KVManager.');
     // Create and obtain the KV store.
   } catch (e) {
     let error = e as BusinessError;
     console.error(`Failed to create KVManager. Code:${error.code},message:${error.message}`);
   }
   
   if (kvManager !== undefined) {
     kvManager = kvManager as distributedKVStore.KVManager;
     // Perform subsequent operations such as creating a KV store.
     // ...
   }
   ```

4. Obtain the KV store of the specified type.

   (1) Declare the ID of the distributed KV store to create, for example, **'storeId'** in the sample code.
   (2) Disable the auto sync function (**autoSync:false**) to facilitate subsequent verification of the sync function. If sync is required, call the **sync()** interface.

   
   ```ts
   let kvStore: distributedKVStore.SingleKVStore | undefined = undefined;
   try {
     let child1 = new distributedKVStore.FieldNode('id');
     child1.type = distributedKVStore.ValueType.INTEGER;
     child1.nullable = false;
     child1.default = '1';
     let child2 = new distributedKVStore.FieldNode('name');
     child2.type = distributedKVStore.ValueType.STRING;
     child2.nullable = false;
     child2.default = 'zhangsan';

     let schema = new distributedKVStore.Schema();
     schema.root.appendChild(child1);
     schema.root.appendChild(child2);
     schema.indexes = ['$.id', '$.name'];
     // The value 0 indicates the compatible mode, and 1 indicates the strict mode.
     schema.mode = 1;
     // Set the number of bytes to be skipped during the value check. The value range is [0, 4M-2].
     schema.skip = 0;

     const options: distributedKVStore.Options = {
       createIfMissing: true,
       encrypt: false,
       backup: false,
       autoSync: false,
       // If kvStoreType is left empty, a device KV store is created by default.
       // Device KV store: kvStoreType: distributedKVStore.KVStoreType.DEVICE_COLLABORATION,
       kvStoreType: distributedKVStore.KVStoreType.SINGLE_VERSION,
       // The schema parameter is optional. You need to set this parameter when the schema function is required, for example, when predicates are used for query.
       schema: schema,
       securityLevel: distributedKVStore.SecurityLevel.S3
     };
     kvManager.getKVStore<distributedKVStore.SingleKVStore>('storeId', options, (err, store: distributedKVStore.SingleKVStore) => {
       if (err) {
         console.error(`Failed to get KVStore: Code:${err.code},message:${err.message}`);
         return;
       }
       console.info('Succeeded in getting KVStore.');
       kvStore = store;
       // Before performing related data operations, obtain a KV store instance.
     });
   } catch (e) {
     let error = e as BusinessError;
     console.error(`An unexpected error occurred. Code:${error.code},message:${error.message}`);
   }
   if (kvStore !== undefined) {
     kvStore = kvStore as distributedKVStore.SingleKVStore;
       // Perform subsequent data operations, such as adding, deleting, modifying, and querying data, and subscribing to data changes.
       // ...
   }
   ```

5. Subscribe to distributed data changes. To unsubscribe from the data changes, call [off('dataChange')](../reference/apis-arkdata/js-apis-distributedKVStore.md#offdatachange).
   
   ```ts
   try {
     kvStore.on('dataChange', distributedKVStore.SubscribeType.SUBSCRIBE_TYPE_ALL, (data) => {
       console.info(`dataChange callback call data: ${data}`);
     });
   } catch (e) {
     let error = e as BusinessError;
     console.error(`An unexpected error occurred. code:${error.code},message:${error.message}`);
   }
   ```

6. Write data to the single KV store.

   (1) Construct the key and value to be written to the single KV store.
   (2) Write KV pairs to the single KV store.

   
   ```ts
   const KEY_TEST_STRING_ELEMENT = 'key_test_string';
   // If schema is not defined, pass in other values that meet the requirements.
   const VALUE_TEST_STRING_ELEMENT = '{"id":0, "name":"lisi"}';
   try {
     kvStore.put(KEY_TEST_STRING_ELEMENT, VALUE_TEST_STRING_ELEMENT, (err) => {
       if (err !== undefined) {
         console.error(`Failed to put data. Code:${err.code},message:${err.message}`);
         return;
       }
       console.info('Succeeded in putting data.');
     });
   } catch (e) {
     let error = e as BusinessError;
     console.error(`An unexpected error occurred. Code:${error.code},message:${error.message}`);
   }
   ```

7. Query data in the single KV store.

   (1) Construct the key to be queried from the single KV store.
   (2) Query data from the single KV store.

   
   ```ts
   try {
     kvStore.put(KEY_TEST_STRING_ELEMENT, VALUE_TEST_STRING_ELEMENT, (err) => {
       if (err !== undefined) {
         console.error(`Failed to put data. Code:${err.code},message:${err.message}`);
         return;
       }
       console.info('Succeeded in putting data.');
       kvStore = kvStore as distributedKVStore.SingleKVStore;
       kvStore.get(KEY_TEST_STRING_ELEMENT, (err, data) => {
         if (err != undefined) {
           console.error(`Failed to get data. Code:${err.code},message:${err.message}`);
           return;
         }
         console.info(`Succeeded in getting data. Data:${data}`);
       });
     });
   } catch (e) {
     let error = e as BusinessError;
     console.error(`Failed to get data. Code:${error.code},message:${error.message}`);
   }
   ```

8. Synchronize data to other devices.

   Select the devices to be synced with data and the sync mode. The user needs to confirm the sync mode when the application is started for the first time.

   > **NOTE**
   >
   > In manual sync mode, **deviceIds** can be obtained by [devManager.getAvailableDeviceListSync](../reference/apis-distributedservice-kit/js-apis-distributedDeviceManager.md#getavailabledevicelistsync).

   ```ts
   import { distributedDeviceManager } from '@kit.DistributedServiceKit';
    
   let devManager: distributedDeviceManager.DeviceManager;
   try {
     // create deviceManager
     devManager = distributedDeviceManager.createDeviceManager(context.applicationInfo.name);
     // deviceIds is obtained by devManager.getAvailableDeviceListSync.
     let deviceIds: string[] = [];
     if (devManager != null) {
       let devices = devManager.getAvailableDeviceListSync();
       for (let i = 0; i < devices.length; i++) {
         deviceIds[i] = devices[i].networkId as string;
       }
     }
     try {
       // 1000 indicates the maximum delay, in ms.
       kvStore.sync(deviceIds, distributedKVStore.SyncMode.PUSH_ONLY, 1000);
     } catch (e) {
       let error = e as BusinessError;
       console.error(`An unexpected error occurred. Code:${error.code},message:${error.message}`);
     }
   
   } catch (err) {
     let error = err as BusinessError;
     console.error("createDeviceManager errCode:" + error.code + ",errMessage:" + error.message);
   }
   ```

#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: singleKVStore.jpg
###Image description: The image depicts a conceptual diagram of a distributed system involving three devices labeled as Device A, Device B, and Device C. These devices are connected to a single Key-Value (KV) store, which is represented by a dashed blue rectangle labeled "Single KV store."

Each device is shown to have a local copy of the KV store, containing the same key-value pairs. Specifically, each device has the following key-value pairs:
- (key1, value1)
- (key2, value2)

The diagram illustrates the following key points:
1. **Device A**: Contains the key-value pairs (key1, value1) and (key2, value2).
2. **Device B**: Contains the same key-value pairs (key1, value1) and (key2, value2).
3. **Device C**: Contains the same key-value pairs (key1, value1) and (key2, value2).

The KV store is centralized and shared among these devices, indicating that the data is replicated across the devices to ensure redundancy and availability. This setup is typical in distributed systems where data needs to be accessible and consistent across multiple nodes.

### Analysis and Description

1. **Replication**: The KV store is replicated across Device A, Device B, and Device C. This redundancy ensures that if one device fails, the data can still be accessed from another device.
2. **Consistency**: The diagram shows that the data is consistent across all devices. Any changes made to the KV store on one device are replicated to the other devices, maintaining a consistent view of the data.
3. **Scalability**: This setup allows for scalability, as additional devices can be added to the system to handle more data or traffic.
4. **Fault Tolerance**: The distributed nature of the system enhances fault tolerance. If one device fails, the system can continue to function with the remaining devices.

### Conclusion

The image effectively illustrates a distributed system with a single KV store replicated across multiple devices. This design ensures data consistency, redundancy, and fault tolerance, making it suitable for applications requiring high availability and scalability.
##Image Name: deviceKVStore.jpg
###Image description: The image depicts a diagram illustrating a distributed key-value (KV) store system across three devices labeled as Device A, Device B, and Device C. The diagram is structured as follows:

1. **Device A**: Contains three key-value pairs:
   - Key: ${A}key1, Value: value1
   - Key: ${A}key2, Value: value2
   - Key: ${A}key3, Value: value3

2. **Device B**: Contains three key-value pairs:
   - Key: ${B}key1, Value: value1
   - Key: ${B}key2, Value: value2
   - Key: ${B}key3, Value: value3

3. **Device C**: Contains three key-value pairs:
   - Key: ${C}key1, Value: value1
   - Key: ${C}key2, Value: value2
   - Key: ${C}key3, Value: value3

4. **Device KV Store**: This is a conceptual representation of the distributed storage system where the data from Devices A, B, and C is aggregated. The KV store is shown as a single entity that holds the combined key-value pairs from all three devices.

### Analysis and Description:

- **Distributed Storage**: The diagram illustrates a distributed key-value store, which is a type of database that stores data in key-value pairs. This architecture allows for scalability and fault tolerance by distributing data across multiple devices or nodes.

- **Key-Value Pairs**: Each device (A, B, C) stores its own set of key-value pairs. The keys are prefixed with the device identifier (${A}, ${B}, ${C}) to distinguish them from other devices.

- **Aggregation**: The Device KV store is a conceptual representation that aggregates the data from all three devices. This means that the KV store holds all the key-value pairs from Devices A, B, and C, effectively creating a single, unified view of the data.

- **Data Consistency**: In a distributed system, maintaining data consistency across multiple nodes can be challenging. The KV store likely employs mechanisms such as replication, consistency protocols (e.g., Raft, Paxos), or eventual consistency to ensure that the data remains consistent despite failures or network partitions.

- **Scalability**: The distributed nature of the KV store allows for scalability. As more devices are added, the load can be distributed across them, improving performance and handling larger data volumes.

### Conclusion:

The diagram effectively illustrates a distributed key-value store system where data is stored across multiple devices, and a central KV store aggregates this data. This architecture is commonly used in cloud computing, microservices, and other distributed systems to manage large volumes of data efficiently and maintain consistency across multiple nodes.
##Image Name: kvStore.jpg
###Image description: The image depicts a diagram illustrating the architecture and components involved in a distributed data synchronization system between two devices, labeled as Device A and Device B. The diagram is divided into two main sections, each representing one of the devices, and includes various components and interactions between them.

### Device A
- **Storage Component**: This component is responsible for storing data locally. It includes functionalities for adding, deleting, modifying, and querying data. It also interacts with a database (DB).
- **Sync Component**: This component handles synchronization tasks between Device A and Device B. It communicates with the Storage Component to manage data updates.
- **Communication Adaptation Layer**: This layer facilitates the communication between the Storage Component and the Sync Component. It adapts the communication protocols and formats to ensure smooth data exchange.
- **DatamgrService**: This service manages the data synchronization process. It is responsible for coordinating the synchronization tasks between Device A and Device B.

### Device B
- **DatamgrService of the Peer Device**: This component is the counterpart of the DatamgrService on Device A. It manages the synchronization process on Device B.
- **Distributed Data Communication**: This represents the communication channel between Device A and Device B. It is responsible for transferring data between the two devices.

### Interactions
- **Manual Sync**: There is a manual sync process indicated by a red arrow from Device A to Device B. This suggests that the user can initiate a synchronization process manually.
- **Auto Sync**: There is an auto sync process indicated by a blue arrow from Device A to Device B. This suggests that synchronization occurs automatically without user intervention.

### Key Points
- **Data Flow**: Data flows from the Storage Component to the Sync Component, then to the Communication Adaptation Layer, and finally to the DatamgrService. The DatamgrService then communicates with the DatamgrService of the peer device (Device B) via the Distributed Data Communication channel.
- **Sync Mechanism**: The sync mechanism involves both manual and automatic synchronization processes. Manual sync is initiated by the user, while auto sync occurs periodically or based on predefined conditions.

### Analysis
This diagram effectively illustrates the architecture of a distributed data synchronization system. The key components and their interactions are clearly depicted, providing a comprehensive view of how data is managed and synchronized between two devices. The use of manual and auto sync mechanisms ensures flexibility and reliability in the synchronization process. The communication adaptation layer is crucial for ensuring that data can be exchanged between different systems with varying communication protocols and formats.
##Image Name: kvStore_development_process.png
###Image description: The image depicts a flowchart outlining a process for managing data synchronization in a distributed system. The flowchart is structured with a series of steps, each represented by a rounded rectangle, and arrows indicating the sequence of actions. Here is a detailed description of each step:

1. **Start**: The process begins with the start symbol, indicating the initiation of the procedure.

2. **Declare permissions in the configuration file and obtain user authorization when the application starts the first time**: This step involves setting up permissions in the configuration file and obtaining user authorization before the application starts for the first time. This is crucial for ensuring that the application has the necessary permissions to operate and for obtaining user consent for data handling.

3. **Create a KvManager instance and create a KV store**: In this step, a KvManager instance is created, which is likely a class or object responsible for managing key-value stores. A KV store is then created, which is a data structure that allows for efficient storage and retrieval of data using keys.

4. **Subscribe to data changes, and call put() and get() to modify and query data**: This step involves subscribing to changes in the data stored in the KV store. The `put()` method is used to add or update data, while the `get()` method is used to retrieve data based on the key.

5. **Synchronize data to peer devices**: Finally, the data is synchronized to peer devices, ensuring that all devices have the same data. This is essential for maintaining consistency across the distributed system.

6. **End**: The process concludes with the end symbol, indicating the completion of the data synchronization procedure.

### Analysis and Description

The flowchart is a clear and concise representation of the steps involved in managing data synchronization in a distributed system. Here are some key points to consider:

- **Permission and Authorization**: The first step emphasizes the importance of permissions and user authorization. This is critical for ensuring that the application operates within the bounds of user consent and legal requirements.

- **KV Store**: The creation of a KV store is a fundamental step in managing data in a distributed system. KV stores are widely used for their simplicity and efficiency in storing and retrieving data using keys.

- **Data Manipulation**: The use of `put()` and `get()` methods for modifying and querying data highlights the dynamic nature of data management in a distributed environment. These methods allow for efficient data manipulation and retrieval.

- **Data Synchronization**: The final step ensures that data is synchronized across peer devices, which is crucial for maintaining consistency and reliability in distributed systems.

Overall, this flowchart provides a structured approach to managing data synchronization in a distributed system, emphasizing the importance of permissions, data storage, and synchronization.
