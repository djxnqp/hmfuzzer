# Color Effect


## Color

You can use the color gradient APIs to apply a background color gradient effect to a component.

| API| Description|
| -------- | -------- |
| [linearGradient](../reference/apis-arkui/arkui-ts/ts-universal-attributes-gradient-color.md#lineargradient) | Applies a linear gradient to the component.|
| [sweepGradient](../reference/apis-arkui/arkui-ts/ts-universal-attributes-gradient-color.md#sweepgradient) | Applies a sweep gradient effect to the component.|
| [radialGradient](../reference/apis-arkui/arkui-ts/ts-universal-attributes-gradient-color.md#radialgradient) | Applies a radial gradient effect to the component.|


## Applying Linear Gradient Effect


```ts
@Entry
@Component
struct LinearGradientDemo {
  build() {
    Grid() {
      GridItem() {
        Column() {
          Text('angle: 180')
            .fontSize(15)
        }
        .width(100)
        .height(100)
        .justifyContent(FlexAlign.Center)
        .borderRadius(10)
        .linearGradient({
          // A positive value indicates a clockwise rotation from the origin, (0, 0). The default value of the linear gradient start angle is 180°.
          colors: [
            [0xf56c6c, 0.0], // Color and weight of color stop 1, corresponding to the start position of the component in the 180° direction.
            [0xffffff, 1.0], // Color and weight of color stop 2, corresponding to the end position of the component in the 180° direction.
          ]
        })
      }

      GridItem() {
        Column() {
          Text('angle: 45')
            .fontSize(15)
        }
        .width(100)
        .height(100)
        .justifyContent(FlexAlign.Center)
        .borderRadius(10)
        .linearGradient({
          angle: 45, // Set the linear gradient start angle to 45°.
          colors: [
            [0xf56c6c, 0.0],
            [0xffffff, 1.0],
          ]
        })
      }

      GridItem() {
        Column() {
          Text('repeat: true')
            .fontSize(15)
        }
        .width(100)
        .height(100)
        .justifyContent(FlexAlign.Center)
        .borderRadius(10)
        .linearGradient({
          repeating: true, // Repeat the gradients of the area from 0 to 0.3 in the area from 0.3 to 1.0.
          colors: [
            [0xf56c6c, 0.0],
            [0xE6A23C, .3],
          ]
        })
      }

      GridItem() {
        Column() {
          Text('repeat: false')
            .fontSize(15)
        }
        .width(100)
        .height(100)
        .justifyContent(FlexAlign.Center)
        .borderRadius(10)
        .linearGradient({
          colors: [
            [0xf56c6c, 0.0], // As repeating is not specified, the default value false is used. In this case, only the area from 0 to 0.3 in the component have the color gradient effect.
            [0xE6A23C, .3],
          ]
        })
      }
    }
    .columnsGap(10)
    .rowsGap(10)
    .columnsTemplate('1fr 1fr')
    .rowsTemplate('1fr 1fr 1fr')
    .width('100%')
    .height('100%')
  }
}
```

![en-us_image_0000001641176829](figures/en-us_image_0000001641176829.png)


## Applying Sweep Gradient Effect


```ts
@Entry
@Component
struct SweepGradientDemo {
  build() {
    Grid() {
      GridItem() {
        Column() {
          Text('center: 50')
            .fontSize(15)
        }
        .width(100)
        .height(100)
        .justifyContent(FlexAlign.Center)
        .borderRadius(10)
        .sweepGradient({
          center: [50, 50], // Center point of the sweep gradient.
          start: 0, // Start point of the sweep gradient.
          end: 360, // End point of the sweep gradient.
          repeating: true, // The gradients are repeated.
          colors: [
          // Based on the center point, start point, and end point settings,
          // the color changes from color stop 1 to color stop 2 in the area within angles from 0 to 0.125;
          // the color changes from color stop 2 to color stop 3 in the area within angles from 0.125 to 0.25;
          // the color gradients of the area within angles from 0 to 0.25 are repeated in the area within angles from 0.25 to 1.
            [0xf56c6c, 0], // Color and weight of color stop 1. The corresponding angle is 0° (0 x 360°), and the corner is the center point.
            [0xffffff, 0.125], // Color and weight of color stop 2.
            [0x409EFF, 0.25] // Color and weight of color stop 3.
          ]
        })
      }

      GridItem() {
        Column() {
          Text('center: 0')
            .fontSize(15)
        }
        .width(100)
        .height(100)
        .justifyContent(FlexAlign.Center)
        .borderRadius(10)
        .sweepGradient({
          center: [0, 0], // Center point of the sweep gradient, which is the coordinate of the upper left corner of the component in this example.
          start: 0,
          end: 360,
          repeating: true,
          colors: [
          // In the current component, the sweep gradient center is the upper left corner of the component. Therefore, the angle range from color stop 1 to color stop 3 can cover the entire component.
            [0xf56c6c, 0], // Color and weight of color stop 1. The corresponding angle is 0° (0 x 360°)
            [0xffffff, 0.125], // Color and weight of color stop 2. The corresponding angle is 45° (0.125 x 360°).
            [0x409EFF, 0.25] // Color and weight of color stop 3. The corresponding angle is 90° (0.25 x 360°).
          ]
        })
      }

      GridItem() {
        Column() {
          Text('repeat: true')
            .fontSize(15)
        }
        .width(100)
        .height(100)
        .justifyContent(FlexAlign.Center)
        .borderRadius(10)
        .sweepGradient({
          center: [50, 50],
          start: 0,
          end: 360,
          repeating: true,
          colors: [
            [0xf56c6c, 0],
            [0xffffff, 0.125],
            [0x409EFF, 0.25]
          ]
        })
      }

      GridItem() {
        Column() {
          Text('repeat: false')
            .fontSize(15)
        }
        .width(100)
        .height(100)
        .justifyContent(FlexAlign.Center)
        .borderRadius(10)
        .sweepGradient({
          center: [50, 50],
          start: 0,
          end: 360,
          repeating: false, // The color gradient effect is generated only within the coverage of the color stop angles.
          colors: [
            [0xf56c6c, 0],
            [0xffffff, 0.125],
            [0x409EFF, 0.25]
          ]
        })
      }
    }
    .columnsGap(10)
    .rowsGap(10)
    .columnsTemplate('1fr 1fr')
    .rowsTemplate('1fr 1fr 1fr')
    .width('100%')
    .height(437)
  }
}
```

![en-us_image_0000001641177073](figures/en-us_image_0000001641177073.png)


## Applying Radial Gradient Effect


```ts
@Entry
@Component
struct radialGradientDemo {
  build() {
    Grid() {
      GridItem() {
        Column() {
          Text('center: 50')
            .fontSize(15)
        }
        .width(100)
        .height(100)
        .justifyContent(FlexAlign.Center)
        .borderRadius(10)
        .radialGradient({
          center: [50, 50], // Center point of the radial gradient.
          radius: 100, // Radius of the radial gradient.
          repeating: true, // The gradients are repeated outside the specified range to fill the entire component.
          colors: [
            // With [50, 50] as the center point, the gradient changes from color stop 1 to color stop 2 within the range of radius 0 to 12.5;
            // the gradient changes from color stop 2 to color stop 3 within the range of radius 12.5 to 25;
            // the gradients in the range of radius 0 to 25 are repeated to fill the entire component.
            [0xf56c6c, 0], // Color and weight of color stop 1. The corresponding radius is 0 (0 x 100).
            [0xffffff, 0.125], // Color and weight of color stop 2. The corresponding radius is 12.5 (0.125 x 100).
            [0x409EFF, 0.25] // Color and weight of color stop 3. The corresponding radius is 25 (0.25 x 100).
          ]
        })
      }

      GridItem() {
        Column() {
          Text('center: 0')
            .fontSize(15)
        }
        .width(100)
        .height(100)
        .justifyContent(FlexAlign.Center)
        .borderRadius(10)
        .radialGradient({
          center: [0, 0], // Center point of the radial gradient, which is the coordinate of the upper left corner of the component in this example.
          radius: 100,
          repeating: true,
          colors: [
            [0xf56c6c, 0],
            [0xffffff, 0.125],
            [0x409EFF, 0.25]
          ]
        })
      }

      GridItem() {
        Column() {
          Text('repeat: true')
            .fontSize(15)
        }
        .width(100)
        .height(100)
        .justifyContent(FlexAlign.Center)
        .borderRadius(10)
        .radialGradient({
          center: [50, 50],
          radius: 100,
          repeating: true,
          colors: [
            [0xf56c6c, 0],
            [0xffffff, 0.125],
            [0x409EFF, 0.25]
          ]
        })
      }

      GridItem() {
        Column() {
          Text('repeat: false')
            .fontSize(15)
        }
        .width(100)
        .height(100)
        .justifyContent(FlexAlign.Center)
        .borderRadius(10)
        .radialGradient({
          center: [50, 50],
          radius: 100,
          repeating: false, // The gradients are not repeated.
          colors: [
            [0xf56c6c, 0],
            [0xffffff, 0.125],
            [0x409EFF, 0.25]
          ]
        })
      }
    }
    .columnsGap(10)
    .rowsGap(10)
    .columnsTemplate('1fr 1fr')
    .rowsTemplate('1fr 1fr 1fr')
    .width('100%')
    .height('100%')
  }
}
```

![en-us_image_0000001592904050](figures/en-us_image_0000001592904050.png)
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: en-us_image_0000001641176829.png
###Image description: The image consists of four square blocks, each with a different gradient background and text indicating specific properties. Here is a detailed description of each block:

1. **Top Left Block:**
   - **Background:** The background gradient transitions from a light pink at the top to a darker pink at the bottom.
   - **Text:** The text in the center reads "angle: 180".

2. **Top Right Block:**
   - **Background:** The background gradient transitions from a light pink at the top to a darker pink at the bottom.
   - **Text:** The text in the center reads "angle: 45".

3. **Bottom Left Block:**
   - **Background:** The background gradient transitions from a light orange at the top to a darker orange at the bottom.
   - **Text:** The text in the center reads "repeat: true".

4. **Bottom Right Block:**
   - **Background:** The background gradient transitions from a light orange at the top to a darker orange at the bottom.
   - **Text:** The text in the center reads "repeat: false".

### Analysis and Description:

- **Top Left Block (Angle: 180):**
  - This block has a gradient that starts with a light pink at the top and transitions to a darker pink at the bottom. The text "angle: 180" indicates that the gradient is applied with an angle of 180 degrees. This suggests that the gradient is applied in a circular manner, starting from the top and wrapping around to the bottom.

- **Top Right Block (Angle: 45):**
  - This block also has a gradient that starts with a light pink at the top and transitions to a darker pink at the bottom. The text "angle: 45" indicates that the gradient is applied with an angle of 45 degrees. This suggests that the gradient is applied in a diagonal manner, starting from the top left and moving towards the bottom right.

- **Bottom Left Block (Repeat: True):**
  - This block has a gradient that starts with a light orange at the top and transitions to a darker orange at the bottom. The text "repeat: true" indicates that the gradient is repeated. This means that the gradient pattern will repeat itself horizontally across the block.

- **Bottom Right Block (Repeat: False):**
  - This block also has a gradient that starts with a light orange at the top and transitions to a darker orange at the bottom. The text "repeat: false" indicates that the gradient is not repeated. This means that the gradient pattern will not repeat horizontally across the block.

### Relevant Knowledge:

- **Gradient Angles:** In graphical design, gradients can be applied with specific angles to create various visual effects. An angle of 180 degrees typically results in a circular gradient, while an angle of 45 degrees results in a diagonal gradient.
- **Gradient Repeats:** In CSS (Cascading Style Sheets), gradients can be set to repeat either horizontally, vertically, or both. Setting "repeat: true" means the gradient will repeat horizontally, while "repeat: false" means it will not repeat horizontally.

### Conclusion:

The image effectively demonstrates how different gradient angles and repeat settings can be used to create distinct visual effects in graphical design. The top left and top right blocks show the impact of different angles on the gradient, while the bottom left and bottom right blocks illustrate the effect of repeat settings on the gradient pattern.
##Image Name: en-us_image_0000001641177073.png
###Image description: The image consists of four squares, each with a different background gradient and text indicating specific CSS properties. Here is a detailed description of each square:

1. **Top Left Square**:
   - **Background Gradient**: The gradient transitions from red at the top left corner to blue at the bottom right corner.
   - **Text**: "center: 50"
   - **Description**: This square demonstrates a gradient with a center point set at 50%. This means that the gradient is centered horizontally at the 50% mark of the square.

2. **Top Right Square**:
   - **Background Gradient**: The gradient transitions from red at the top left corner to blue at the bottom right corner.
   - **Text**: "center: 0"
   - **Description**: This square shows a gradient with a center point set at 0%. This means that the gradient is centered horizontally at the 0% mark of the square, effectively starting from the left edge.

3. **Bottom Left Square**:
   - **Background Gradient**: The gradient transitions from red at the top left corner to blue at the bottom right corner.
   - **Text**: "repeat: true"
   - **Description**: This square illustrates a gradient that repeats horizontally. The gradient pattern is repeated across the width of the square, creating a continuous effect.

4. **Bottom Right Square**:
   - **Background Gradient**: The gradient transitions from red at the top left corner to blue at the bottom right corner.
   - **Text**: "repeat: false"
   - **Description**: This square shows a gradient that does not repeat horizontally. The gradient pattern is applied only once across the width of the square, resulting in a single, non-repeating gradient.

### Analysis and Explanation

The image effectively demonstrates the use of CSS properties for gradients and their visual outcomes. The `center` property controls the horizontal alignment of the gradient, while the `repeat` property determines whether the gradient pattern is repeated or applied once.

- **Center Alignment**:
  - Setting `center: 50` centers the gradient horizontally at the 50% mark.
  - Setting `center: 0` centers the gradient at the 0% mark, starting from the left edge.

- **Repetition**:
  - Setting `repeat: true` repeats the gradient pattern across the width of the square.
  - Setting `repeat: false` applies the gradient pattern only once, creating a single, non-repeating gradient.

These properties are fundamental in CSS for creating visually appealing and responsive designs. Understanding how to manipulate gradients and their properties can significantly enhance the aesthetic and functionality of web designs.
##Image Name: en-us_image_0000001592904050.png
###Image description: The image consists of four square graphics, each with a different pattern and label indicating specific properties. Here is a detailed description of each square:

1. **Top Left Square**:
   - **Pattern**: The square has concentric circles with alternating colors of blue and red.
   - **Label**: The label in the square reads "center: 50".
   - **Description**: This suggests that the pattern is centered at the 50th position, likely referring to a pixel or coordinate system.

2. **Top Right Square**:
   - **Pattern**: The square has concentric circles with alternating colors of red and blue.
   - **Label**: The label in the square reads "center: 0".
   - **Description**: This suggests that the pattern is centered at the 0th position, indicating the origin or starting point of the pattern.

3. **Bottom Left Square**:
   - **Pattern**: The square has concentric circles with alternating colors of red and blue.
   - **Label**: The label in the square reads "repeat: true".
   - **Description**: This indicates that the pattern is repeated, meaning the same pattern is repeated multiple times within the square.

4. **Bottom Right Square**:
   - **Pattern**: The square has a single, solid blue color.
   - **Label**: The label in the square reads "repeat: false".
   - **Description**: This indicates that the pattern is not repeated, meaning the square has a single, solid color without any repetition.

### Analysis and Description

The image appears to be a demonstration of different properties of patterns in a graphical context, possibly related to image processing or computer graphics. The labels "center: 50" and "center: 0" suggest that the patterns are centered at different positions, which could be useful in understanding how patterns are aligned within a canvas or image.

The labels "repeat: true" and "repeat: false" indicate whether the pattern is repeated within the square. In computer graphics, repeating patterns are often used to fill larger areas or to create textures. The "repeat: true" square shows a pattern that is repeated, creating a continuous, seamless pattern, while the "repeat: false" square shows a single, solid color without repetition.

### Conclusion

This image serves as a visual guide to understanding how different properties of patterns can be manipulated in a graphical context. The labels provide clear instructions on the centering and repetition of patterns, which are fundamental concepts in image processing and computer graphics.
