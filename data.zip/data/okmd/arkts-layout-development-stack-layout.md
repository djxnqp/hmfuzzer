# Stack Layout (Stack)


## Overview

The stack layout reserves an area on the screen to display elements in a component and allows the elements to be stacked. You can implement a stack layout through the [Stack](../reference/apis-arkui/arkui-ts/ts-container-stack.md) component, which provides a stack container where positioned or non-positioned child elements are pushed successively and the latter one sits on top of the previous one.

The stack layout excels at page stacking and positioning, and is widely used in ad and widget arrangement.

In the **Stack** component shown in Figure 1, the sequence of child elements is Item1 -> Item2 -> Item3.


  **Figure 1** Stack layout 

![stack-layout](figures/stack-layout.png)


## How to Develop

The **Stack** component can contain various child elements, which are stacked in the center by default. While respecting the constraints of **Stack**, child elements are laid out in their respective style.

```ts
// xxx.ets
let MTop:Record<string,number> = { 'top': 50 }

@Entry
@Component
struct StackExample {
  build() {
    Column(){
      Stack({ }) {
        Column(){}.width('90%').height('100%').backgroundColor('#ff58b87c')
        Text('text').width('60%').height('60%').backgroundColor('#ffc3f6aa')
        Button('button').width('30%').height('30%').backgroundColor('#ff8ff3eb').fontColor('#000')
      }.width('100%').height(150).margin(MTop)
    }
  }
}
```


![stack-layout-sample](figures/stack-layout-sample.png)


## Alignment

Alignment of elements in the **Stack** component is set through the [alignContent](../reference/apis-arkui/arkui-ts/ts-container-stack.md#aligncontent) parameter. As shown in Figure 2, nine alignment modes are supported.

  **Figure 2** Alignment modes in the Stack component 

![en-us_image_0000001562940621](figures/en-us_image_0000001562940621.png)

```ts
// xxx.ets
@Entry
@Component
struct StackExample {
  build() {
    Stack({ alignContent: Alignment.TopStart }) {
      Text('Stack').width('90%').height('100%').backgroundColor('#e1dede').align(Alignment.BottomEnd)
      Text('Item 1').width('70%').height('80%').backgroundColor(0xd2cab3).align(Alignment.BottomEnd)
      Text('Item 2').width('50%').height('60%').backgroundColor(0xc1cbac).align(Alignment.BottomEnd)
    }.width('100%').height(150).margin({ top: 5 })
  }
}
```

## Z-order Control

The stacking order of child elements in the **Stack** component is set through the [zIndex](../reference/apis-arkui/arkui-ts/ts-universal-attributes-z-order.md) attribute. A larger **zIndex** value indicates a higher display level.

  In the stack layout, if the size of an element is greater than that of the one before it, the one before it is hidden.

```ts
Stack({ alignContent: Alignment.BottomStart }) {
  Column() {
    Text('Stacked element 1').textAlign(TextAlign.End).fontSize(20)
  }.width(100).height(100).backgroundColor(0xffd306)

  Column() {
    Text('Stacked element 2').fontSize(20)
  }.width(150).height(150).backgroundColor(Color.Pink)

  Column() {
    Text('Stacked element 3').fontSize(20)
  }.width(200).height(200).backgroundColor(Color.Grey)
}.width(350).height(350).backgroundColor(0xe0e0e0)
```

![en-us_image_0000001511900544](figures/en-us_image_0000001511900544.png)

In the preceding figure, the size of the stacked element 3 is greater than that of all the elements before it. Therefore, the first two elements are completely hidden. To show these elements, modify their **zIndex** attribute settings.


```ts
Stack({ alignContent: Alignment.BottomStart }) {
  Column() {
    Text('Stacked element 1').fontSize(20)
  }.width(100).height(100).backgroundColor(0xffd306).zIndex(2)

  Column() {
    Text('Stacked element 2').fontSize(20)
  }.width(150).height(150).backgroundColor(Color.Pink).zIndex(1)

  Column() {
    Text('Stacked element 3').fontSize(20)
  }.width(200).height(200).backgroundColor(Color.Grey)
}.width(350).height(350).backgroundColor(0xe0e0e0)
```

![en-us_image_0000001563060797](figures/en-us_image_0000001563060797.png)


## Example Scenario

In this example, the stack layout is used to quickly set up a page.


```ts
@Entry
@Component
struct StackSample {
  private arr: string[] = ['APP1', 'APP2', 'APP3', 'APP4', 'APP5', 'APP6', 'APP7', 'APP8'];

  build() {
    Stack({ alignContent: Alignment.Bottom }) {
      Flex({ wrap: FlexWrap.Wrap }) {
        ForEach(this.arr, (item:string) => {
          Text(item)
            .width(100)
            .height(100)
            .fontSize(16)
            .margin(10)
            .textAlign(TextAlign.Center)
            .borderRadius(10)
            .backgroundColor(0xFFFFFF)
        }, (item:string):string => item)
      }.width('100%').height('100%')

      Flex({ justifyContent: FlexAlign.SpaceAround, alignItems: ItemAlign.Center }) {
        Text('Contacts').fontSize(16)
        Text('Settings').fontSize(16)
        Text('Messaging').fontSize(16)
      }
      .width('50%')
      .height(50)
      .backgroundColor('#16302e2e')
      .margin({ bottom: 15 })
      .borderRadius(15)
    }.width('100%').height('100%').backgroundColor('#CFD0CF')
  }
}
```


![en-us_image_0000001511421368](figures/en-us_image_0000001511421368.png)
<!--RP1--><!--RP1End-->
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: stack-layout.png
###Image description: The image depicts a hierarchical structure of three items arranged in a stack. Here is a detailed description:

1. **Item1**: This is the topmost item in the stack. It is a large, light blue rectangle.
2. **Item2**: This is the second item in the stack, positioned directly below Item1. It is a smaller, light green rectangle.
3. **Item3**: This is the bottommost item in the stack, positioned directly below Item2. It is a yellow rectangle.

The items are arranged in a vertical stack, with Item1 at the top, followed by Item2, and then Item3 at the bottom. The background of the image is white, and the text "Stack" is written at the bottom right corner, indicating the nature of the arrangement.
##Image Name: stack-layout-sample.png
###Image description: The image shows a simple graphical user interface (GUI) layout. The layout consists of two rectangular shapes, one larger and one smaller. The larger rectangle is green and occupies the entire background of the image. Inside the green rectangle, there is a smaller rectangle that is light green. This smaller rectangle contains two elements: a label and a button.

The label inside the smaller rectangle is positioned at the top and is labeled "text." The button is positioned below the label and is labeled "button." The button is highlighted with a blue border, indicating that it is the focus or selected element in the layout.

The overall design is minimalistic, with a clean and straightforward layout. The use of contrasting colors (green and light green) helps to distinguish the different elements within the layout.
##Image Name: en-us_image_0000001562940621.png
###Image description: The image consists of a grid of nine smaller images arranged in a 3x3 layout. Each smaller image represents a different arrangement of three items labeled as Item1, Item2, and Item3. The items are colored in shades of blue, green, and yellow. The background of each smaller image is white, and the grid is bordered by a black frame.

Here is a detailed description of each smaller image in the grid:

1. **Top Row, First Column (Leftmost Image):**
   - Item1 is at the bottom, colored blue.
   - Item2 is in the middle, colored green.
   - Item3 is at the top, colored yellow.
   - The background is white.

2. **Top Row, Second Column (Middle Image):**
   - Item1 is at the bottom, colored blue.
   - Item2 is in the middle, colored green.
   - Item3 is at the top, colored yellow.
   - The background is white.

3. **Top Row, Third Column (Rightmost Image):**
   - Item1 is at the bottom, colored blue.
   - Item2 is in the middle, colored green.
   - Item3 is at the top, colored yellow.
   - The background is white.

4. **Middle Row, First Column (Leftmost Image):**
   - Item1 is at the bottom, colored blue.
   - Item2 is in the middle, colored green.
   - Item3 is at the top, colored yellow.
   - The background is white.

5. **Middle Row, Second Column (Middle Image):**
   - Item1 is at the bottom, colored blue.
   - Item2 is in the middle, colored green.
   - Item3 is at the top, colored yellow.
   - The background is white.

6. **Middle Row, Third Column (Rightmost Image):**
   - Item1 is at the bottom, colored blue.
   - Item2 is in the middle, colored green.
   - Item3 is at the top, colored yellow.
   - The background is white.

7. **Bottom Row, First Column (Leftmost Image):**
   - Item1 is at the bottom, colored blue.
   - Item2 is in the middle, colored green.
   - Item3 is at the top, colored yellow.
   - The background is white.

8. **Bottom Row, Second Column (Middle Image):**
   - Item1 is at the bottom, colored blue.
   - Item2 is in the middle, colored green.
   - Item3 is at the top, colored yellow.
   - The background is white.

9. **Bottom Row, Third Column (Rightmost Image):**
   - Item1 is at the bottom, colored blue.
   - Item2 is in the middle, colored green.
   - Item3 is at the top, colored yellow.
   - The background is white.

Each smaller image shows the same arrangement of items but with different stacking orders. The items are consistently colored and positioned in the same manner across all images, with the only variation being the stacking order of the items.
##Image Name: en-us_image_0000001511900544.png
###Image description: The image depicts a simple graphical representation of a stack data structure. The stack is shown as a rectangular box with a gradient fill, transitioning from a darker shade at the top to a lighter shade at the bottom. The box is positioned on the left side of the image, occupying a significant portion of the vertical space.

Inside the box, there is a text label that reads "Stack element 3." This label is centered within the box and is in a bold, black font. The text is positioned towards the bottom of the box, indicating that it represents the third element in the stack.

The background of the image is a gradient that transitions from a lighter shade at the top to a darker shade at the bottom, creating a subtle visual effect. The overall design is minimalistic, focusing on the stack representation and the text label.

### Analysis and Description

1. **Stack Representation**:
   - The rectangular box represents a stack data structure.
   - Stacks are a type of abstract data structure that follow the Last In, First Out (LIFO) principle.
   - The gradient fill of the box adds a visual distinction, making it easier to identify the stack.

2. **Text Label**:
   - The text "Stack element 3" indicates that the stack contains at least three elements.
   - The label is positioned at the bottom of the box, suggesting that "3" is the third element in the stack.

3. **Visual Design**:
   - The gradient background enhances the visual appeal without distracting from the main content.
   - The use of a single color for the text ensures readability against the gradient background.

### Relevant Knowledge

- **Stacks** are commonly used in computer science for various applications, such as function calls in programming languages, parsing expressions, and more.
- The LIFO principle means that the last element added to the stack is the first one to be removed.

### Conclusion

The image effectively communicates the concept of a stack data structure with a clear and concise representation. The gradient fill and the text label provide a straightforward way to understand the stack's structure and the position of its elements. This minimalistic design ensures that the focus remains on the stack representation, making it an ideal visual aid for educational purposes.
##Image Name: en-us_image_0000001563060797.png
###Image description: The image depicts a stack of three rectangular elements, each with a different color and labeled accordingly. The stack is arranged vertically, with the elements positioned from bottom to top. Here is a detailed description of each element:

1. **Stack element 1**: This is the bottommost element of the stack. It is colored yellow and has the label "Stack element 1" written on it. The element appears to be the largest among the three.

2. **Stack element 2**: This element is located above stack element 1. It is colored pink and has the label "Stack element 2" written on it. This element is smaller than stack element 1 but larger than stack element 3.

3. **Stack element 3**: This is the topmost element of the stack. It is colored gray and has the label "Stack element 3" written on it. This element is the smallest among the three.

The background of the image is a light gray color, which contrasts with the colors of the stack elements, making them easily distinguishable. The overall layout is simple and clear, with each element clearly labeled and stacked in a vertical sequence.

### Analysis and Description

The image represents a basic stack structure, which is a data structure used in computer science. In a stack, elements are added and removed in a Last-In-First-Out (LIFO) manner. This means that the last element added to the stack is the first one to be removed. The image visually demonstrates this principle by showing the elements stacked from bottom to top, with the most recently added element (stack element 1) at the bottom and the oldest element (stack element 3) at the top.

### Relevant Knowledge

Stacks are commonly used in various applications, including programming languages for managing function calls, parsing expressions, and implementing recursive algorithms. They are also used in algorithms for tasks such as sorting and searching.

### Conclusion

The image effectively illustrates the concept of a stack with three elements, each labeled and stacked in a clear, vertical sequence. This visual representation helps in understanding the basic structure and behavior of a stack, which is a fundamental data structure in computer science.
##Image Name: en-us_image_0000001511421368.png
###Image description: The image depicts a smartphone screen displaying a grid of eight app icons. Each icon is a white square with rounded corners, and they are arranged in a 3x3 grid pattern. The background of the screen is a light gray color. At the bottom of the screen, there is a navigation bar with three icons labeled "Contacts," "Settings," and "Messaging." The icons are arranged horizontally, with "Contacts" on the left, "Settings" in the middle, and "Messaging" on the right. The overall layout suggests that this is a typical smartphone home screen.
