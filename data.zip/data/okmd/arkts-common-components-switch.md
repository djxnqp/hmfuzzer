# Toggle


The **Toggle** component provides a clickable element in the check box, button, or switch type, typically used to switch between two states. For details, see [Toggle](../reference/apis-arkui/arkui-ts/ts-basic-components-toggle.md).


## Creating a Toggle

You can create a toggle by calling the following API:

```ts
Toggle(options: { type: ToggleType, isOn?: boolean })
```

In this API, **ToggleType** indicates the toggle type, which can be **Button**, **Checkbox**, or **Switch**, and **isOn** specifies whether the toggle is turned on.

Since API version 11, the default style of the **Checkbox** component is changed from rounded square to circle.

The API can be called in either of the following ways:


- Create a toggle that does not contain child components.
  This can be achieved by calling the API with **ToggleType** set to **Checkbox** or **Switch**.
  
  
    ```ts
  Toggle({ type: ToggleType.Checkbox, isOn: false })
  Toggle({ type: ToggleType.Checkbox, isOn: true })
    ```

  ![en-us_image_0000001562940485](figures/en-us_image_0000001562940485.png)
  
  ```ts
  Toggle({ type: ToggleType.Switch, isOn: false })
  Toggle({ type: ToggleType.Switch, isOn: true })
  ```
  
    ![en-us_image_0000001511421228](figures/en-us_image_0000001511421228.png)
  
- Create a toggle that contains a child component.
  When **ToggleType** is set to **Button**, only one child component is allowed. If the child component has text set, the text content is displayed on the button.

  ```ts
  Toggle({ type: ToggleType.Button, isOn: false }) {
    Text('status button')
      .fontColor('#182431')
      .fontSize(12)
  }.width(100)
  Toggle({ type: ToggleType.Button, isOn: true }) {
    Text('status button')
      .fontColor('#182431')
      .fontSize(12)
  }.width(100)
  ```

    ![en-us_image_0000001511900404](figures/en-us_image_0000001511900404.png)


## Setting Styles

- Use the **selectedColor** attribute to set the background color of the toggle for when it is turned on.

  ```ts
  Toggle({ type: ToggleType.Button, isOn: true }) {
    Text('status button')
    .fontColor('#182431')
    .fontSize(12)
  }.width(100).selectedColor(Color.Pink)
  Toggle({ type: ToggleType.Checkbox, isOn: true })
    .selectedColor(Color.Pink)
  Toggle({ type: ToggleType.Switch, isOn: true })
    .selectedColor(Color.Pink)
  ```

  ![en-us_image_0000001563060657](figures/en-us_image_0000001563060657.png)

- Use the **switchPointColor** attribute to set the color of the circular slider. This attribute is valid only when **type** of the toggle is set to **ToggleType.Switch**.

  ```ts
  Toggle({ type: ToggleType.Switch, isOn: false })
    .switchPointColor(Color.Pink)
  Toggle({ type: ToggleType.Switch, isOn: true })
    .switchPointColor(Color.Pink)
  ```

  ![en-us_image_0000001511421232](figures/en-us_image_0000001511421232.png)


## Adding Events

The **Toggle** component supports the [universal events](../reference/apis-arkui/arkui-ts/ts-universal-events-click.md). In addition, it can be bound to the **onChange** event so that it responds with custom behavior after being turned on or off.


```ts
Toggle({ type: ToggleType.Switch, isOn: false })
  .onChange((isOn: boolean) => {
      if(isOn) {
        // Operation
      }
  })
```


## Example Scenario

In this example, the **Toggle** component is used to enable or disable Bluetooth.

```ts
// xxx.ets
import { promptAction } from '@kit.ArkUI';
@Entry
@Component
struct ToggleExample {
  @State BOnSt:promptAction.ShowToastOptions = {'message': 'Bluetooth is on.'}
  @State BOffSt:promptAction.ShowToastOptions = {'message': 'Bluetooth is off.'}
  build() {
    Column() {
      Row() {
        Text("Bluetooth Mode")
          .height(50)
          .fontSize(16)
      }
      Row() {
        Text("Bluetooth")
          .height(50)
          .padding({left: 10})
          .fontSize(16)
          .textAlign(TextAlign.Start)
          .backgroundColor(0xFFFFFF)
        Toggle({ type: ToggleType.Switch })
          .margin({left: 200, right: 10})
          .onChange((isOn: boolean) => {
            if(isOn) {
              promptAction.showToast(this.BOnSt)
            } else {
              promptAction.showToast(this.BOffSt)
            }
          })
      }
      .backgroundColor(0xFFFFFF)
    }
    .padding(10)
    .backgroundColor(0xDCDCDC)
    .width('100%')
    .height('100%')
  }
}
```


![en-us_image_0000001511740448](figures/en-us_image_0000001511740448.png)
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: en-us_image_0000001562940485.png
###Image description: The image contains two distinct icons placed side by side against a plain white background. 

1. **Left Icon:**
   - **Shape:** The icon on the left is a circle.
   - **Color:** The circle is white.
   - **Design:** The circle is solid, with no additional patterns or markings.

2. **Right Icon:**
   - **Shape:** The icon on the right is also a circle.
   - **Color:** The circle is blue.
   - **Design:** Inside the blue circle, there is a checkmark. The checkmark is white and is placed in the center of the blue circle.

**Analysis and Description:**
The two icons are simple and minimalistic, each representing a different state or action. The left icon, being a white circle, could symbolize an option that is not selected or an inactive state. The right icon, with a blue circle and a white checkmark inside, typically represents an option that is selected or an active state. This is a common visual convention used in user interfaces to indicate selection or confirmation.

**Relevant Knowledge:**
In user interfaces and software applications, such icons are often used to visually communicate the selection status of options. The checkmark is a universally recognized symbol for confirmation or selection. The blue color is often used to denote a positive or selected state, while white is used for clarity and contrast against the blue background.

**Conclusion:**
The image effectively uses simple shapes and colors to convey the concept of selection or confirmation. The left icon represents the absence of selection, while the right icon represents the presence of selection. This visual distinction is crucial in user interfaces to help users quickly understand the state of options they are interacting with.
##Image Name: en-us_image_0000001511421228.png
###Image description: The image shows two toggle switches, which are commonly used in user interfaces to represent on/off states. The toggle switches are depicted in a minimalist style with a white background.

1. **Left Toggle Switch**:
   - The toggle switch is in the off position.
   - It is represented by a horizontal bar that is white in color.
   - The bar is positioned to the left side of the switch, indicating that it is not turned on.

2. **Right Toggle Switch**:
   - The toggle switch is in the on position.
   - It is represented by a horizontal bar that is blue in color.
   - The bar is positioned to the right side of the switch, indicating that it is turned on.

The toggle switches are simple and clear, making it easy to understand whether they are on or off at a glance.
##Image Name: en-us_image_0000001511900404.png
###Image description: The image contains two buttons labeled "status button." The buttons are displayed side by side. The button on the left is white with a light gray background, while the button on the right is blue with a light blue background. Both buttons have a rounded rectangular shape and are placed against a white background.
##Image Name: en-us_image_0000001563060657.png
###Image description: The image shows a user interface element with the text "status button" written below it. To the right of the text, there are two icons: a checkmark and a toggle switch. The checkmark is filled in, indicating that the status is currently active or enabled. The toggle switch is in the off position, suggesting that the status is currently turned off or disabled. The background of the interface element is pink.
##Image Name: en-us_image_0000001511421232.png
###Image description: The image shows two toggle switches, each with a simple design. The toggle switch on the left is in the off position, indicated by the pink color, while the toggle switch on the right is in the on position, indicated by the blue color. The switches are rectangular with rounded corners and have a minimalist design.
##Image Name: en-us_image_0000001511740448.png
###Image description: The image shows a simple interface for enabling or disabling Bluetooth mode. The interface has a title "Bluetooth Mode" at the top. Below the title, there is a toggle switch labeled "Bluetooth" with a blue circle on the right side, indicating that Bluetooth is currently on. At the bottom of the interface, there is a button labeled "Bluetooth is on."
