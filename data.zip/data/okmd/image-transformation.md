# Using PixelMap to Transform Images

Image processing refers to a series of operations performed on the PixelMap, such as obtaining image information, cropping, scaling, translating, rotating, flipping, setting opacity, and reading and writing pixel data. These operations can be classified into image transformation and [PixelMap operation](image-pixelmap-operation.md). This topic describes the image transformation operations that you can perform.

## How to Develop

Read [Image](../../reference/apis-image-kit/js-apis-image.md#pixelmap7) for APIs related to image transformation.

1. Complete [image decoding](image-decoding.md) and obtain a **PixelMap** object.

2. Obtain image information.

   ```ts
   import { BusinessError } from '@kit.BasicServicesKit';
   // Obtain the image size.
   pixelMap.getImageInfo().then( (info : image.ImageInfo) => {
     console.info('info.width = ' + info.size.width);
     console.info('info.height = ' + info.size.height);
   }).catch((err : BusinessError) => {
     console.error("Failed to obtain the image pixel map information.And the error is: " + err);
   });
   ```

3. Perform image transformation.

   Original image:

     ![Original drawing](figures/original-drawing.jpeg)

   - Crop the image.

     ```ts
     // x: x-axis coordinate of the start point for cropping (0).
     // y: y-axis coordinate of the start point for cropping (0).
     // height: height after cropping (400), cropping from top to bottom.
     // width: width after cropping (400), cropping from left to right.
     pixelMap.crop({x: 0, y: 0, size: { height: 400, width: 400 } });
     ```

     ![cropping](figures/cropping.jpeg)

   - Scale the image.

     ```ts
     // The width of the image after scaling is 0.5 of the original width.
     // The height of the image after scaling is 0.5 of the original height.
     pixelMap.scale(0.5, 0.5);
     ```

     ![zoom](figures/zoom.jpeg)

   - Translate the image.

     ```ts
     // Translate the image by 100 units downwards.
     // Translate the image by 100 units rightwards.
     pixelMap.translate(100, 100);
     ```

     ![offsets](figures/offsets.jpeg)

   - Rotate the image.

     ```ts
     // Rate the image clockwise by 90°.
     pixelMap.rotate(90);
     ```

     ![rotate](figures/rotate.jpeg)

   - Flip the image.

     ```ts
     // Flip the image vertically.
     pixelMap.flip(false, true);
     ```

     ![Vertical Flip](figures/vertical-flip.jpeg)

     ```ts
     // Flip the image horizontally.
     pixelMap.flip(true, false);
     ```

     ![Horizontal Flip](figures/horizontal-flip.jpeg)

   - Set the opacity of the image.

     ```ts
     // Set the opacity to 0.5.
     pixelMap.opacity(0.5);
     ```

     ![Transparency](figures/transparency.png)

<!--RP1-->
<!--RP1End-->
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: original-drawing.jpeg
###Image description: The image depicts a close-up view of a tree branch adorned with yellow leaves against a clear blue sky. The leaves are vibrant and appear to be in the midst of changing colors, possibly indicating the transition from summer to autumn. The branch is slightly angled, with the leaves hanging down, creating a natural and organic feel to the image. The sky in the background is a deep blue with a few wispy white clouds scattered throughout, adding to the serene and picturesque quality of the scene. The contrast between the yellow leaves and the blue sky highlights the beauty of the natural environment.
##Image Name: cropping.jpeg
###Image description: The image depicts a close-up view of a tree during what appears to be autumn. The tree's leaves are predominantly yellow, indicating the fall season when many deciduous trees shed their leaves. The leaves are broad and somewhat rounded, with visible veins and edges. The branches are dark and somewhat bare, with a few leaves still attached. The background is a clear blue sky, suggesting that the photograph was taken on a sunny day. The contrast between the yellow leaves and the blue sky creates a vibrant and striking image.
##Image Name: zoom.jpeg
###Image description: The image depicts a close-up view of a tree branch adorned with yellow leaves against a backdrop of a clear blue sky. The leaves are arranged in a somewhat dense cluster, with some leaves overlapping each other, creating a rich tapestry of yellow hues. The branches are slender and slightly curved, extending outward from the main trunk of the tree. The sky in the background is a vivid blue, with a few wispy white clouds scattered across it. The contrast between the bright yellow leaves and the clear blue sky creates a striking and serene visual effect. The overall composition of the image suggests a peaceful and natural setting, likely taken during the autumn season when many trees change color.
##Image Name: offsets.jpeg
###Image description: The image depicts a close-up view of a tree branch adorned with yellow leaves against a backdrop of a clear blue sky. The leaves are clustered together, forming a dense canopy. The branches are thin and slightly curved, extending outward from the main trunk. The sky is a vivid blue with a few wispy clouds scattered across it, indicating a bright and sunny day. The overall scene suggests a late summer or early autumn setting, as the leaves are in their autumnal colors.
##Image Name: rotate.jpeg
###Image description: The image depicts a close-up view of a tree branch adorned with vibrant yellow leaves against a clear blue sky. The leaves are clustered together, forming a dense canopy. The branches are thin and dark, contrasting with the bright yellow of the leaves. The sky in the background is a deep blue, with a few wispy white clouds scattered across it. The overall scene suggests a sunny day, likely during the autumn season when trees typically change color. The image captures the beauty of nature, highlighting the contrast between the vivid yellow leaves and the serene blue sky.
##Image Name: vertical-flip.jpeg
###Image description: The image depicts a close-up view of a tree branch adorned with yellow leaves against a clear blue sky. The leaves are broad and have a slightly wavy edge, characteristic of aspen trees. The branches are thin and dark, contrasting with the bright yellow color of the leaves. The sky in the background is a vivid blue with a few wispy white clouds scattered throughout. The overall scene suggests a sunny day, likely during the autumn season when aspen trees typically change color. The image captures the beauty of nature with its vibrant colors and serene atmosphere.
##Image Name: horizontal-flip.jpeg
###Image description: The image depicts a close-up view of a tree branch adorned with yellow leaves against a backdrop of a clear blue sky. The leaves are broad and have a slightly pointed tip, characteristic of certain deciduous trees. The branch is relatively thin and appears to be part of a larger tree, as indicated by the multiple branches extending from it. The leaves are arranged in a somewhat dense cluster, covering a significant portion of the branch. The sky is a vivid blue with a few wispy white clouds scattered throughout, suggesting a calm and sunny day. The contrast between the bright yellow leaves and the blue sky creates a striking and visually appealing image.
##Image Name: transparency.png
###Image description: The image depicts a close-up view of a tree branch with leaves against a clear blue sky. The leaves are light yellow or pale green, suggesting they might be in the autumn season when leaves typically change color. The branches are thin and slightly curved, and the leaves are arranged in a somewhat random pattern along the branches. The sky in the background is a solid blue with no visible clouds, indicating a clear day. The overall scene is serene and natural, with the focus on the interplay between the leaves and the sky.
