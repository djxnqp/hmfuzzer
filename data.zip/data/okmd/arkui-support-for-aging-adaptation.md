# Supporting Aging-Friendly Design

## Basic Concepts

Aging-friendly design offers a method to enlarge selected areas or components through a long-press action with a mouse or finger. Specifically, when the system font is larger than 1x, this action on a component with aging-friendly features extracts data from the component within the selected area and presents it in a dialog box. This way, both the component and its internal data (child components) are enlarged, and the entire component is centered on the screen for better visibility.

## Constraints

* Aging-friendly rules

  To ensure that components enlarge appropriately when the system font size is greater than 1x, you need to configure the [configuration tag](../quick-start/app-configuration-file.md#configuration) for implementing an aging-friendly feature.

<!--RP1--><!--RP1End-->

* Aging-friendly operations

  Long-pressing a component that supports aging-friendly capabilities triggers a dialog box. The aging-friendly operation ends when the user releases the press. When the system font size is set to be greater than 1x, the component automatically enlarges, and when the system font size returns to 1x, the component returns to its normal state.

* Aging-friendly objects

  The components that trigger the aging-friendly operation and provide the data.

* Aging-friendly dialog box targets

  The components capable of receiving and processing the aging-friendly data.

* Dialog box restrictions

  When users set the system font to more than 2x, the dialog box content, including icons and text, is magnified at a fixed 2x scale.

* Combination with other capabilities

  Aging-friendly capabilities can be integrated with other features (such as swipe and drag). When the bottom tab bar (**tabBar**) component is activated for aging-friendly features, users can swipe their fingers or use a mouse to trigger aging-friendly features for other child components within the tab bar.

## Aging-Friendly Component Adaptation and Activation Methods

| Activation Method            | Component                                                    |
| -------------------- | ------------------------------------------------------------ |
| Long press on the component        | [SideBarContainer](../reference/apis-arkui/arkui-ts/ts-container-sidebarcontainer.md), [Bottom Tab Bar (tabBar)](../reference/apis-arkui/arkui-ts/ts-container-tabcontent.md#tabbar9), [Navigation](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md), [NavDestination](../reference/apis-arkui/arkui-ts/ts-basic-components-navigation.md#navdestination10), [Tabs](../reference/apis-arkui/arkui-ts/ts-container-tabs.md)|
| Default system font enlargement| [PickerDialog](../reference/apis-arkui/arkui-ts/ts-methods-calendarpicker-dialog.md), [Button](../reference/apis-arkui/arkui-ts/ts-basic-components-button.md), [Menu](../reference/apis-arkui/arkui-ts/ts-basic-components-menu.md), [Stepper](../reference/apis-arkui/arkui-ts/ts-basic-components-stepper.md), [BindSheet](../reference/apis-arkui/arkui-ts/ts-universal-attributes-sheet-transition.md#bindsheet), [TextInput](../reference/apis-arkui/arkui-ts/ts-basic-components-textinput.md), [TextArea](../reference/apis-arkui/arkui-ts/ts-basic-components-textarea.md), [Search](../reference/apis-arkui/arkui-ts/ts-basic-components-search.md), [SelectionMenu](../reference/apis-arkui/arkui-ts/ohos-arkui-advanced-SelectionMenu.md), [Chip](../reference/apis-arkui/arkui-ts/ohos-arkui-advanced-Chip.md#chip), [Dialog](../reference/apis-arkui/arkui-ts/ohos-arkui-advanced-Dialog.md), [Slider](../reference/apis-arkui/arkui-ts/ts-basic-components-slider.md), [Progress](../reference/apis-arkui/arkui-ts/ts-basic-components-progress.md), [Badge](../reference/apis-arkui/arkui-ts/ts-container-badge.md)|

## Example

<!--RP2-->
This example uses the **SideBarContainer** component to trigger an aging-friendly dialog box through a long press of the control button. Note that the dialog box does not appear if the system font size is at the 1x setting. Instead, it appears only when the system font size is set to greater than 1x.

```ts
import { abilityManager, Configuration } from '@kit.AbilityKit';
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
struct SideBarContainerExample {
  @State currentFontSizeScale: number = 1
  normalIcon: Resource = $r("app.media.icon")
  selectedIcon: Resource = $r("app.media.icon")
  @State arr: number[] = [1, 2, 3]
  @State current: number = 1
  @State title: string = 'Index01';
  // Set the font scale.
  async setFontScale(scale: number): Promise<void> {
    let configInit: Configuration = {
      language: 'zh-Ch',
      fontSizeScale: scale,
    };
    // Update the font size.
    abilityManager.updateConfiguration(configInit, (err: BusinessError) => {
      if (err) {
        console.error(`updateConfiguration fail, err: ${JSON.stringify(err)}`);
      } else {
        this.currentFontSizeScale = scale;
        console.log('updateConfiguration success.');
      }
    });
  }

  build() {
    SideBarContainer(SideBarContainerType.Embed) {
      Column() {
        ForEach(this.arr, (item: number) => {
          Column({ space: 5 }) {
            Image(this.current === item ? this.selectedIcon : this.normalIcon).width(64).height(64)
            Text("0" + item)
              .fontSize(25)
              .fontColor(this.current === item ? '#0A59F7' : '#999')
              .fontFamily('source-sans-pro,cursive,sans-serif')
          }
          .onClick(() => {
            this.current = item;
            this.title = "Index0" + item;
          })
        }, (item: string) => item)
      }.width('100%')
      .justifyContent(FlexAlign.SpaceEvenly)
      .backgroundColor($r('sys.color.mask_fifth'))

      Column() {
        Text(this.title)
        Button('1x').onClick(() => {
          this.setFontScale(1)
        }).margin(10)
        Button('1.75x').onClick(() => {
          this.setFontScale(1.75)
        }).margin(10)
        Button('2x').onClick(() => {
          this.setFontScale(2)
        }).margin(10)
        Button('3.2x').onClick(() => {
          this.setFontScale(3.2)
        }).margin(10)
      }
      .margin({ top: 50, left: 20, right: 30 })
    }
    .controlButton({
      icons: {
        hidden: $r('sys.media.ohos_ic_public_drawer_open_filled'),
        shown: $r('sys.media.ohos_ic_public_drawer_close')
      }
    })
    .sideBarWidth(150)
    .minSideBarWidth(50)
    .maxSideBarWidth(300)
    .minContentWidth(0)
    .onChange((value: boolean) => {
      console.info('status:' + value)
    })
    .divider({ strokeWidth: '1vp', color: Color.Gray, startMargin: '4vp', endMargin: '4vp' })
  }
}
```

Switching system font sizes and long-pressing components with aging-friendly capabilities yields the effects as follows.

| System Font at 1x (Before Aging-Friendly Features Are Enabled)| System Font at 1.75x (After Aging-Friendly Features Are Enabled)|
| ---------------------------------- | ------------------------------------ |
| ![](figures/aging_01.png)          | ![](figures/aging_02.png)            |

The [TextPickerDialog](../reference/apis-arkui/arkui-ts/ts-methods-textpicker-dialog.md) component triggers an aging-friendly dialog box when the system font is set to greater than 1x, which does not occur at the default 1x setting.

```ts
import { abilityManager, Configuration } from '@kit.AbilityKit';
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
struct TextPickerExample {
  private select: number | number[] = 0;
  private cascade: TextCascadePickerRangeContent[] = [
    {
      text: 'Category 1',
      children: [{ text: 'Subcategory 1', children: [{ text: 'Subcategory 2' }, { text: 'Subcategory 3' }, { text: 'Subcategory 4' }] },
        { text: 'Item 1', children: [{ text: 'Item 2' }, { text: 'Item 3' }, { text: 'Item 4' }] }]
    },
    {
      text: 'Category 2',
      children: [{ text: 'Subcategory 1', children: [{ text: 'Subcategory 2' }, { text: 'Subcategory 3' }, { text: 'Subcategory 4' }] },
        { text: 'Item 1', children: [{ text: 'Item 2' }, { text: 'Item 3' }, { text: 'Item 4' }] }]
    },
    {
      text: 'Category 3',
      children: [{ text: 'Subcategory 1', children: [{ text: 'Subcategory 2' }, { text: 'Subcategory 3' }, { text: 'Subcategory 4' }] },
        { text: 'Item 1', children: [{ text: 'Item 2' }, { text: 'Item 3' }, { text: 'Item 4' }] }]
    }
  ]
  @State v: string = '';
  @State showTriggered: string = '';
  private triggered: string = '';
  private maxLines: number = 3;
  // Set the font scale.
  async setFontScale(scale: number): Promise<void> {
    let configInit: Configuration = {
      fontSizeScale: scale,
    };

    abilityManager.updateConfiguration(configInit, (err: BusinessError) => {
      if (err) {
        console.error(`updateConfiguration fail, err: ${JSON.stringify(err)}`);
      } else {
        console.log('updateConfiguration success.');
      }
    });
  }

  linesNum(max: number): void {
    let items: string[] = this.triggered.split('\n').filter(item => item != '');
    if (items.length > max) {
      this.showTriggered = items.slice(-this.maxLines).join('\n');
    } else {
      this.showTriggered = this.triggered;
    }
  }

  build() {
    Column() {
      Button("TextPickerDialog.show:" + this.v)
        .onClick(() => {
          this.getUIContext().showTextPickerDialog({
            range: this.cascade,
            selected: this.select,
            onAccept: (value: TextPickerResult) => {
              this.select = value.index
              console.log(this.select + '')
              this.v = value.value as string
              console.info("TextPickerDialog:onAccept()" + JSON.stringify(value))
              if (this.triggered != '') {
                this.triggered += `\nonAccept(${JSON.stringify(value)})`;
              } else {
                this.triggered = `onAccept(${JSON.stringify(value)})`;
              }
              this.linesNum(this.maxLines);
            },
            onCancel: () => {
              console.info("TextPickerDialog:onCancel()")
              if (this.triggered != '') {
                this.triggered += `\nonCancel()`;
              } else {
                this.triggered = `onCancel()`;
              }
              this.linesNum(this.maxLines);
            },
            onChange: (value: TextPickerResult) => {
              console.info("TextPickerDialog:onChange()" + JSON.stringify(value))
              if (this.triggered != '') {
                this.triggered += `\nonChange(${JSON.stringify(value)})`;
              } else {
                this.triggered = `onChange(${JSON.stringify(value)})`;
              }
              this.linesNum(this.maxLines);
            },
          })
        })
        .margin({ top: 60 })

      Row() {
        Button('1x').onClick(() => {
          this.setFontScale(1)
        }).margin(10)
        Button('1.75x').onClick(() => {
          this.setFontScale(1.75)
        }).margin(10)

        Button('2x').onClick(() => {
          this.setFontScale(2)
        }).margin(10)
        Button('3.2x').onClick(() => {
          this.setFontScale(3.2)
        }).margin(10)
      }.margin({ top: 50 })
    }

  }
}
```

| System Font at 1x (Before Aging-Friendly Features Are Enabled)| System Font at 1.75x (After Aging-Friendly Features Are Enabled)|
| ---------------------------------- | ------------------------------------ |
| ![](figures/aging_03.png)          | ![](figures/aging_04.png)            |
<!--RP2End-->
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: aging_01.png
###Image description: The image shows a user interface with two main sections. On the left side, there is a vertical list of items, each accompanied by a blue icon and a number. The items are labeled "01" and "02." The icons are square with a blue background and a white four-leaf clover pattern.

On the right side, there is a section labeled "Index01" with three options: "1x," "1.75x," "2x," and "3.2x." These options are presented in a vertical list with blue circular buttons, each containing the respective multiplier value. The "1x" option is highlighted, indicating it is currently selected.

The overall design suggests that this interface is likely part of a software application or a digital device, possibly related to adjusting display scaling or image size.
##Image Name: aging_02.png
###Image description: The image shows a user interface, likely from a design or development tool, with several elements and options. Here is a detailed description:

1. **Top Section**:
   - There are two blue square icons with white text inside them. The text reads "Index01" and "Index02".
   - Below these icons, there are three blue buttons with white text indicating different zoom levels: "1x", "1.75x", and "2x".

2. **Middle Section**:
   - A white square with a black arrow pointing downwards is visible. This likely represents a dropdown menu or a more detailed view option.

3. **Bottom Section**:
   - The background is light gray, and the overall layout suggests a clean and modern design.

### Analysis and Description:

This image appears to be part of a user interface for a design or development tool, possibly for managing or viewing different index or page elements. The presence of zoom options indicates that the user can adjust the view to see more or less detail, which is common in design tools to help with precision and detail work.

The "Index01" and "Index02" icons suggest that there are at least two different pages or sections that can be accessed or viewed. This could be useful for organizing different parts of a project or document.

The zoom options (1x, 1.75x, 2x) allow the user to switch between different magnification levels, which is essential for tasks that require high precision, such as editing text, adjusting images, or working with small details.

The white square with the black arrow likely serves as a button to open a dropdown menu, which could contain additional options or settings related to the index or page elements.

Overall, this interface is designed to provide a user-friendly experience for managing and viewing different sections of a project with adjustable zoom levels for detailed work.
##Image Name: aging_03.png
###Image description: The image shows a text picker dialog interface with several options and settings. Here is a detailed description:

### Interface Layout:
- **Title Bar:**
  - The title bar at the top of the dialog contains the text "TextPickerDialog.show:".
  
- **Font Size Options:**
  - Below the title bar, there are four buttons labeled with different font sizes:
    - 1x
    - 1.75x
    - 2x
    - 3.2x

### Content Area:
- **Table:**
  - The main content area is a table with three columns:
    - **Category 1**
    - **Subcategory 1**
    - **Item 1**
    - **Category 2**
    - **Subcategory 2**
    - **Item 2**
    - **Category 3**
    - **Subcategory 3**
    - **Item 3**

### Buttons:
- **Cancel Button:**
  - Located at the bottom left of the table.
- **OK Button:**
  - Located at the bottom right of the table.

### Background:
- The background of the dialog is a gradient of light gray to dark gray, creating a subtle contrast with the text and buttons.

### Analysis:
This text picker dialog is likely used for selecting text with specific font sizes and categorization. The user can choose from different font sizes (1x, 1.75x, 2x, 3.2x) and select items from different categories and subcategories. The table structure helps in organizing the options in a clear and structured manner.

### Relevant Knowledge:
Text picker dialogs are commonly used in applications where users need to select text with specific formatting options. The font size options allow for customization to meet different display requirements, such as readability on different devices or screen sizes. The categorization helps in organizing the options logically, making it easier for users to find and select the desired items.

### Conclusion:
The image depicts a well-organized text picker dialog with options for selecting text with different font sizes and categorization. The interface is designed to provide a user-friendly experience for selecting and customizing text formatting.
##Image Name: aging_04.png
###Image description: The image shows a text picker dialog with a title "TextPickerDialog.show:" at the top. The dialog contains a list of categories, each with a corresponding font size multiplier. The categories are:

1. Category 1 (1x)
2. Category 2 (1.75x)
3. Category 3 (2x)
4. Category 4 (3.2x)

Below the list of categories, there are two buttons: "Cancel" on the left and "Next" on the right. The "Next" button is highlighted, indicating that it is the selected action. The background of the dialog is a light gray color, and the text is in a dark color for contrast.
