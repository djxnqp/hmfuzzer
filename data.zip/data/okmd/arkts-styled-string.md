# Styled String (StyledString/MutableStyledString)

Styled strings, implemented by **StyledString** or **MutableStyledString** (collectively referred to as **StyledString**, with **MutableStyledString** inheriting from **StyledString**), are powerful markup objects designed to set text styles at the character or paragraph level. By binding a **StyledString** object to a text component, you can modify the text in various ways, including changing the font size, adding font colors, making the text clickable, and customizing the drawing of text, among others. For details, see [Styled String](../reference/apis-arkui/arkui-ts/ts-universal-styled-string.md).

Styled strings provide a variety of style objects that cover various common text formatting styles, such as text decorative lines, line height, and text shadows. You can also create **CustomSpan** objects to apply custom styles.

## Creating and Applying a StyledString Object

  You can bind a **StyledString** object to a text component using the [setStyledString](../reference/apis-arkui/arkui-ts/ts-basic-components-text.md#setstyledstring12) API provided by **TextController**. You are advised to call the API in the [onPageShow](../reference/apis-arkui/arkui-ts/ts-custom-component-lifecycle.md#onpageshow) callback for immediate display of the styled string text content.
  > **NOTE**
  >
  > Avoid calling the **setStyledString** API in **aboutToAppear**, as the component may have not yet been mounted to the node tree at the time **aboutToAppear** is executed, preventing the styled string text content from appearing upon page load.

  ```ts
  @Entry
  @Component
  struct styled_string_demo1 {
    styledString1: StyledString = new StyledString("45-minute workout");
    mutableStyledString1: MutableStyledString = new MutableStyledString("35-minute workout");
    controller1: TextController = new TextController();
    controller2: TextController = new TextController();

    async onPageShow() {
      this.controller1.setStyledString(this.styledString1)
      this.controller2.setStyledString(this.mutableStyledString1)
    }

    build() {
      Column() {
        // Display the styled string.
        Text(undefined, { controller: this.controller1 })
        Text(undefined, { controller: this.controller2 })
      }
      .width('100%')
    }
  }
  ```
  ![StyledString_Init](figures/span_string_init.png)

## Setting the Text Style

Styled strings offer multiple style objects, such as [TextStyle](../reference/apis-arkui/arkui-ts/ts-universal-styled-string.md#textstyle), [TextShadowStyle](../reference/apis-arkui/arkui-ts/ts-universal-styled-string.md#textshadowstyle), [DecorationStyle](../reference/apis-arkui/arkui-ts/ts-universal-styled-string.md#decorationstyle), [BaselineOffsetStyle](../reference/apis-arkui/arkui-ts/ts-universal-styled-string.md#baselineoffsetstyle), [LineHeightStyle](../reference/apis-arkui/arkui-ts/ts-universal-styled-string.md#lineheightstyle), and [LetterSpacingStyle](../reference/apis-arkui/arkui-ts/ts-universal-styled-string.md#letterspacingstyle), for setting text styles.

- Creating and applying a **TextStyle** object

  ```ts
  import { LengthMetrics } from '@kit.ArkUI'
  @Entry
  @Component
  struct styled_string_demo2 {
    textStyleAttrs: TextStyle = new TextStyle({ fontWeight: FontWeight.Bolder, fontSize: LengthMetrics.vp(24), fontStyle: FontStyle.Italic })
    mutableStyledString: MutableStyledString = new MutableStyledString("35-minute workout goal achieved", [
      {
        start: 2,
        length: 2,
        styledKey: StyledStringKey.FONT,
        styledValue: this.textStyleAttrs
      },
      {
        start: 7,
        length: 4,
        styledKey: StyledStringKey.FONT,
        styledValue: new TextStyle({ fontColor: Color.Orange, fontSize: LengthMetrics.vp(12)})
      }
    ]);
    controller: TextController = new TextController();

    async onPageShow() {
      this.controller.setStyledString(this.mutableStyledString)
    }

    build() {
      Column() {
        // Display the styled string.
        Text(undefined, { controller: this.controller })
          .margin({ top: 10 })
      }
      .width('100%')
    }
  }
  ```
  ![StyledString_TextStyle](figures/StyledString_TextStyle.png)

- Creating and applying a **TextShadowStyle** object

  ```ts
  // xxx.ets
  @Entry
  @Component
  struct styled_string_demo3 {
    mutableStyledString: MutableStyledString = new MutableStyledString("35-minute workout", [
    {
      start: 0,
      length: 3,
      styledKey: StyledStringKey.TEXT_SHADOW,
      styledValue: new TextShadowStyle({
        radius: 5,
        type: ShadowType.COLOR,
        color: Color.Red,
        offsetX: 10,
        offsetY: 10
      })
    }
    ]);
    controller: TextController = new TextController();

    async onPageShow() {
      this.controller.setStyledString(this.mutableStyledString)
    }

    build() {
      Column() {
        // Display the styled string.
        Text(undefined, { controller: this.controller })
      }
      .width('100%')
    }
  }
  ```
  ![StyledString_TextShadow](figures/styled_string_text_shadow.png)

- Creating and applying a **Text DecorationStyle** object

  ```ts
  // xxx.ets
  @Entry
  @Component
  struct styled_string_demo4 {
    mutableStyledString: MutableStyledString = new MutableStyledString("35-minute workout", [
    {
      start: 0,
      length: 3,
      styledKey: StyledStringKey.DECORATION,
      styledValue: new DecorationStyle({type: TextDecorationType.LineThrough, color: Color.Red})
    }
    ]);
    controller: TextController = new TextController();

    async onPageShow() {
      this.controller.setStyledString(this.mutableStyledString)
    }

    build() {
      Column() {
        // Display the styled string.
        Text(undefined, { controller: this.controller })
      }
      .width('100%')
    }
  }
  ```
  ![StyledString_Decoration](figures/styled_string_decoration.png)

- Creating and applying a **Text BaselineOffsetStyle** object

  ```ts
  import { LengthMetrics, LengthUnit } from '@kit.ArkUI'
  // xxx.ets
  @Entry
  @Component
  struct styled_string_demo5 {
    mutableStyledString: MutableStyledString = new MutableStyledString("35-minute workout", [
      {
        start: 0,
        length: 3,
        styledKey: StyledStringKey.BASELINE_OFFSET,
        styledValue: new BaselineOffsetStyle(LengthMetrics.px(20))
      }
    ]);
    controller: TextController = new TextController();

    async onPageShow() {
      this.controller.setStyledString(this.mutableStyledString)
    }

    build() {
      Column() {
        // Display the styled string.
        Text(undefined, { controller: this.controller })
      }
      .width('100%')
    }
  }
  ```
  ![StyledString_Baseline](figures/styled_string_baselineoffset.png)

- Creating and applying a **LineHeightStyle** object

  ```ts
  import { LengthMetrics, LengthUnit } from '@kit.ArkUI'
  // xxx.ets
  @Entry
  @Component
  struct styled_string_demo6 {
    mutableStyledString: MutableStyledString = new MutableStyledString("35-minute workout\nFighting\nAchieved", [
      {
        start: 8,
        length: 3,
        styledKey: StyledStringKey.LINE_HEIGHT,
        styledValue: new LineHeightStyle(LengthMetrics.vp(50))
      }
    ]);
    controller: TextController = new TextController();

    async onPageShow() {
      this.controller.setStyledString(this.mutableStyledString)
    }

    build() {
      Column() {
        // Display the styled string.
        Text(undefined, { controller: this.controller })
      }
      .width('100%')
      .margin({ top: 10 })
    }
  }
  ```
  ![StyledString_lineHeight](figures/styled_string_lineHeight.png)

- Creating and applying a **LetterSpacingStyle** object

  ```ts
  import { LengthMetrics, LengthUnit } from '@kit.ArkUI'
  // xxx.ets
  @Entry
  @Component
  struct styled_string_demo7 {
    mutableStyledString: MutableStyledString = new MutableStyledString("35-minute workout", [
      {
        start: 0,
        length: 2,
        styledKey: StyledStringKey.LETTER_SPACING,
        styledValue: new LetterSpacingStyle(new LengthMetrics(20, LengthUnit.VP))
      }
    ]);
    controller: TextController = new TextController();

    async onPageShow() {
      this.controller.setStyledString(this.mutableStyledString)
    }

    build() {
      Column() {
        // Display the styled string.
        Text(undefined, { controller: this.controller })
      }
      .width('100%')
    }
  }
  ```
  ![StyledString_letterSpacing](figures/styled_string_letterspacing.png)

## Setting the Paragraph Style

You can set the paragraph style using [ParagraphStyle](../reference/apis-arkui/arkui-ts/ts-universal-styled-string.md#paragraphstyle). The figure below shows how to divide paragraphs in the text, with each paragraph ending with a newline character \n.

![paragraphs](figures/styledstringParagraphs.png)

The following example shows how to create and apply a paragraph style. The style is applied to the start, end or any position within a paragraph; it does not apply to non-paragraph areas.

  ```ts
  import { LengthMetrics } from '@kit.ArkUI'
  titleParagraphStyleAttr: ParagraphStyle = new ParagraphStyle({ textAlign: TextAlign.Center });
  // Create a paragraph style for a 15 vp first-line text indent.
  paragraphStyleAttr1: ParagraphStyle = new ParagraphStyle({ textIndent: LengthMetrics.vp(15) });
  // Line height style object
  lineHeightStyle1: LineHeightStyle= new LineHeightStyle(new LengthMetrics(24));
  // Create a paragraph style object paragraphStyledString1.
  paragraphStyledString1: MutableStyledString = new MutableStyledString("Paragraph Title\nFirst paragraph starts 0123456789 First paragraph ends.", [
    {
      start: 0,
      length: 4,
      styledKey: StyledStringKey.PARAGRAPH_STYLE,
      styledValue: this.titleParagraphStyleAttr
    },
    {
      start: 0,
      length: 4,
      styledKey: StyledStringKey.LINE_HEIGHT,
      styledValue: new LineHeightStyle(new LengthMetrics(50))
    },{
    start: 0,
    length: 4,
    styledKey: StyledStringKey.FONT,
    styledValue: new TextStyle({ fontSize: LengthMetrics.vp(24), fontWeight: FontWeight.Bolder })
  },
    {
      start: 5,
      length: 3,
      styledKey: StyledStringKey.PARAGRAPH_STYLE,
      styledValue: this.paragraphStyleAttr1
    },
    {
      start: 5,
      length: 20,
      styledKey: StyledStringKey.LINE_HEIGHT,
      styledValue: this.lineHeightStyle1
    }
  ]);
  ```

  In addition to presetting styles when creating a styled string, you can also clear the original styles and replace them with new ones later using the [replaceStyle](../reference/apis-arkui/arkui-ts/ts-universal-styled-string.md#replacestyle) API. After the replacement, you need to proactively trigger an update to the bound styled string on the attached text component's controller.

  ```ts
  import { LengthMetrics } from '@kit.ArkUI'
  // Set the maximum number of lines and text overflow mode for the paragraph, without setting the indent.
  paragraphStyleAttr3: ParagraphStyle = new ParagraphStyle({ textAlign: TextAlign.End, maxLines: 1, wordBreak: WordBreak.BREAK_ALL, overflow: TextOverflow.Ellipsis});
  // Later in the code, trigger an update to the paragraph style.
  controller: TextController = new TextController();
  this.paragraphStyledString1.replaceStyle({
    start: 5,
    length: 3,
    styledKey: StyledStringKey.PARAGRAPH_STYLE,
    styledValue: this.paragraphStyleAttr3
  })
  this.controller.setStyledString(this.paragraphStyledString1)
  ```

## Using Images

You can add images using [ImageAttachment](../reference/apis-arkui/arkui-ts/ts-universal-styled-string.md#imageattachment).

The following example shows how to attach images and text to the same **MutableStyledString** object for mixed display of text and images.

  ```ts
  // xxx.ets
  import { image } from '@kit.ImageKit'
  import { LengthMetrics } from '@kit.ArkUI'

  @Entry
  @Component
  struct styled_string_demo4 {
    @State message: string = 'Hello World'
    imagePixelMap: image.PixelMap | undefined = undefined
    @State imagePixelMap3: image.PixelMap | undefined = undefined
    mutableStr: MutableStyledString = new MutableStyledString('123');
    controller: TextController = new TextController();
    mutableStr2: MutableStyledString = new MutableStyledString('This is set decoration line style to the mutableStr2', [{
      start: 0,
      length: 15,
      styledKey: StyledStringKey.DECORATION,
      styledValue: new DecorationStyle({
        type: TextDecorationType.Overline,
        color: Color.Orange,
        style: TextDecorationStyle.DOUBLE
      })
    }])

    async aboutToAppear() {
      console.info("aboutToAppear initial imagePixelMap")
      this.imagePixelMap = await this.getPixmapFromMedia($r('app.media.sea'))
    }

    private async getPixmapFromMedia(resource: Resource) {
      let unit8Array = await this.getUIContext().getHostContext()?.resourceManager?.getMediaContent({
        bundleName: resource.bundleName,
        moduleName: resource.moduleName,
        id: resource.id
      })
      let imageSource = image.createImageSource(unit8Array?.buffer?.slice(0, unit8Array?.buffer?.byteLength))
      let createPixelMap: image.PixelMap = await imageSource.createPixelMap({
        desiredPixelFormat: image.PixelMapFormat.RGBA_8888
      })
      await imageSource.release()
      return createPixelMap
    }

    leadingMarginValue: ParagraphStyle = new ParagraphStyle({ leadingMargin: LengthMetrics.vp(5)})
    // Line height style object
    lineHeightStyle1: LineHeightStyle= new LineHeightStyle(new LengthMetrics(24));
    //Bold style
    boldTextStyle: TextStyle = new TextStyle({ fontWeight: FontWeight.Bold });
    // Create a paragraph style object paragraphStyledString1.
    paragraphStyledString1: MutableStyledString = new MutableStyledString("\n30 HD prints\nCYN5.15 off Limited offer", [
      {
        start: 0,
        length: 28,
        styledKey: StyledStringKey.PARAGRAPH_STYLE,
        styledValue: this.leadingMarginValue
      },
      {
        start: 14,
        length: 9,
        styledKey: StyledStringKey.FONT,
        styledValue: new TextStyle({ fontSize: LengthMetrics.vp(14), fontColor: '#B22222' })
      },
      {
        start: 24,
        length: 4,
        styledKey: StyledStringKey.FONT,
        styledValue: new TextStyle({ fontSize: LengthMetrics.vp(14), fontWeight: FontWeight.Lighter })
      },
      {
        start: 11,
        length: 4,
        styledKey: StyledStringKey.LINE_HEIGHT,
        styledValue: this.lineHeightStyle1
      }
    ]);
    paragraphStyledString2: MutableStyledString = new MutableStyledString("\n¥16.21 3000+ reviews", [
      {
        start: 0,
        length: 5,
        styledKey: StyledStringKey.PARAGRAPH_STYLE,
        styledValue: this.leadingMarginValue
      },
      {
        start: 0,
        length: 4,
        styledKey: StyledStringKey.LINE_HEIGHT,
        styledValue: new LineHeightStyle(new LengthMetrics(60))
      },
      {
        start: 0,
        length: 7,
        styledKey: StyledStringKey.FONT,
        styledValue: this.boldTextStyle
      },
      {
        start: 1,
        length: 1,
        styledKey: StyledStringKey.FONT,
        styledValue: new TextStyle({ fontSize: LengthMetrics.vp(18) })
      },
      {
        start: 2,
        length: 2,
        styledKey: StyledStringKey.FONT,
        styledValue: new TextStyle({ fontSize: LengthMetrics.vp(36) })
      },
      {
        start: 4,
        length: 3,
        styledKey: StyledStringKey.FONT,
        styledValue: new TextStyle({ fontSize: LengthMetrics.vp(20) })
      },
      {
        start: 7,
        length: 9,
        styledKey: StyledStringKey.FONT,
        styledValue: new TextStyle({ fontColor: Color.Grey, fontSize: LengthMetrics.vp(14)})
      }
    ])

    build() {
      Row() {
        Column({ space: 10 }) {
          Text(undefined, { controller: this.controller })
            .copyOption(CopyOptions.InApp)
            .draggable(true)
            .backgroundColor('#FFFFFF')
            .borderRadius(5)

          Button('View Product Details')
            .onClick(() => {
              if (this.imagePixelMap !== undefined) {
                this.mutableStr = new MutableStyledString(new ImageAttachment({
                  value: this.imagePixelMap,
                  size: { width: 180, height: 160 },
                  verticalAlign: ImageSpanAlignment.BASELINE,
                  objectFit: ImageFit.Fill
                }))
                this.paragraphStyledString1.appendStyledString(this.paragraphStyledString2)
                this.mutableStr.appendStyledString(this.paragraphStyledString1)
                this.controller.setStyledString(this.mutableStr)
              }
            })
        }
        .width('100%')
      }
      .height('100%')
      .backgroundColor('#F8F8FF')
    }
  }
  ```
  ![StyledString_ImageAttachment](figures/StyledStringImageAttachment.png)

## Setting Events

You can use [GestureStyle](../reference/apis-arkui/arkui-ts/ts-universal-styled-string.md#gesturestyle) to set up **onClick** and **onLongPress** events to enable text to respond to click and long-press actions.

In addition to initializing styled strings with initial style objects, you can also use the [setStyle](../reference/apis-arkui/arkui-ts/ts-universal-styled-string.md#setstyle) API to overlay new styles or update existing ones. After making changes, you need to manually trigger an update of the bound styled string on the attached text component's controller. 

  ```ts
import { drawing } from '@kit.ArkGraphics2D';

class MyCustomSpan extends CustomSpan {
  constructor(word: string, width: number, height: number, fontSize: number) {
    super();
    this.word = word;
    this.width = width;
    this.height = height;
    this.fontSize = fontSize;
  }

  onMeasure(measureInfo: CustomSpanMeasureInfo): CustomSpanMetrics {
    return { width: this.width, height: this.height }
  }

  onDraw(context: DrawContext, options: CustomSpanDrawInfo) {
    let canvas = context.canvas;

    const brush = new drawing.Brush();
    brush.setColor({ alpha: 255, red: 0, green: 0, blue: 0 })
    const font = new drawing.Font()
    font.setSize(vp2px(this.fontSize))
    const textBlob = drawing.TextBlob.makeFromString(this.word.substring(0, 5), font, drawing.TextEncoding.TEXT_ENCODING_UTF8)
    canvas.attachBrush(brush)

    this.onDrawRectByRadius(context, options.x, options.x + vp2px(this.width), options.lineTop, options.lineBottom, 20)
    brush.setColor({ alpha: 255, red: 255, green: 255, blue: 255 })
    canvas.attachBrush(brush)
    canvas.drawTextBlob(textBlob, options.x, options.lineBottom - 30)
    brush.setColor({ alpha: 255, red: 255, green: 228 , blue: 196 })
    canvas.attachBrush(brush)
    const textBlob1 = drawing.TextBlob.makeFromString(this.word.substring(5), font, drawing.TextEncoding.TEXT_ENCODING_UTF8)
    canvas.drawTextBlob(textBlob1, options.x + vp2px(100), options.lineBottom - 30)

    canvas.detachBrush()
  }
  onDrawRectByRadius(context: DrawContext, left: number, right: number, top: number, bottom: number, radius: number) {
    let canvas = context.canvas
    let path = new drawing.Path()

    // Draw a rectangle with rounded corners.
    path.moveTo(left  + radius, top)
    path.lineTo(right - radius, top)
    path.arcTo(right - 2 * radius, top, right, top + 2 * radius, 270, 90)
    path.lineTo(right, bottom - radius)
    path.arcTo(right - 2 * radius, bottom - 2 * radius, right, bottom, 0, 90)

    path.lineTo(left + 2 * radius, bottom)
    path.arcTo(left, bottom - 2 * radius, left + 2 * radius, bottom, 90, 90)
    path.lineTo(left, top + 2 * radius)
    path.arcTo(left, top, left + 2 * radius, top + 2 * radius, 180, 90)

    canvas.drawPath(path)
  }
  setWord(word: string) {
    this.word = word;
  }

  width: number = 160
  word: string = "drawing"
  height: number = 10
  fontSize: number = 16
}

@Entry
@Component
struct styled_string_demo6 {
  customSpan3: MyCustomSpan = new MyCustomSpan("99VIP88%off", 200, 40, 30)
  textStyle: MutableStyledString = new MutableStyledString("123");
  textController: TextController = new TextController()
  isPageShow: boolean = true

  async onPageShow() {
    if (!this.isPageShow) {
      return
    }
    this.isPageShow = false
    this.textController.setStyledString(new StyledString(this.customSpan3))
  }

  build() {
    Row() {
      Column() {
        Text(undefined, { controller: this.textController })
          .copyOption(CopyOptions.InApp)
          .fontSize(30)
      }
      .width('100%')
    }
    .height('100%')
  }
}
  ```
![CustomSpanDemo](figures/StyledString_CustomSpan_Scene.PNG)

## Example

This example shows how to implement an expired membership notification using **ParagraphStyle**, **LineHeightStyle**, and **TextStyle** objects.

```ts
import { LengthMetrics } from '@kit.ArkUI';

@Entry
@Component
struct Index {
  alignCenterParagraphStyleAttr: ParagraphStyle = new ParagraphStyle({ textAlign: TextAlign.Center });
  // Line height style object
  lineHeightStyle1: LineHeightStyle= new LineHeightStyle(LengthMetrics.vp(24));
  //Bold style
  boldTextStyle: TextStyle = new TextStyle({ fontWeight: FontWeight.Bold });
  // Create a paragraph style object paragraphStyledString1.
  paragraphStyledString1: MutableStyledString = new MutableStyledString("Diamond Membership expired\nRenew to keep your perks ", [
    {
      start: 0,
      length: 4,
      styledKey: StyledStringKey.PARAGRAPH_STYLE,
      styledValue: this.alignCenterParagraphStyleAttr
    },
    {
      start: 0,
      length: 4,
      styledKey: StyledStringKey.LINE_HEIGHT,
      styledValue: new LineHeightStyle(LengthMetrics.vp(40))
    },
    {
      start: 11,
      length: 14,
      styledKey: StyledStringKey.FONT,
      styledValue: new TextStyle({ fontSize: LengthMetrics.vp(14), fontColor: Color.Grey })
    },
    {
      start: 11,
      length: 4,
      styledKey: StyledStringKey.PARAGRAPH_STYLE,
      styledValue: this.alignCenterParagraphStyleAttr
    },
    {
      start: 11,
      length: 4,
      styledKey: StyledStringKey.LINE_HEIGHT,
      styledValue: this.lineHeightStyle1
    }
  ]);
  paragraphStyledString2: MutableStyledString = new MutableStyledString("\n￥4.88￥15", [
    {
      start: 0,
      length: 4,
      styledKey: StyledStringKey.PARAGRAPH_STYLE,
      styledValue: this.alignCenterParagraphStyleAttr
    },
    {
      start: 0,
      length: 4,
      styledKey: StyledStringKey.LINE_HEIGHT,
      styledValue: new LineHeightStyle(LengthMetrics.vp(60))
    },
    {
      start: 0,
      length: 6,
      styledKey: StyledStringKey.FONT,
      styledValue: this.boldTextStyle
    },
    {
      start: 1,
      length: 1,
      styledKey: StyledStringKey.FONT,
      styledValue: new TextStyle({ fontSize: LengthMetrics.vp(18)})
    },
    {
      start: 2,
      length: 4,
      styledKey: StyledStringKey.FONT,
      styledValue: new TextStyle({ fontSize: LengthMetrics.vp(40)})
    },
    {
      start: 6,
      length: 3,
      styledKey: StyledStringKey.FONT,
      styledValue: new TextStyle({ fontColor: Color.Grey, fontSize: LengthMetrics.vp(14)})
    },
    {
      start: 6,
      length: 3,
      styledKey: StyledStringKey.DECORATION,
      styledValue: new DecorationStyle({ type: TextDecorationType.LineThrough, color: Color.Grey })
    }
  ])
  paragraphStyledString3: MutableStyledString = new MutableStyledString("\nOffer ends in 02:06", [
    {
      start: 0,
      length: 4,
      styledKey: StyledStringKey.PARAGRAPH_STYLE,
      styledValue: this.alignCenterParagraphStyleAttr
    },
    {
      start: 0,
      length: 4,
      styledKey: StyledStringKey.LINE_HEIGHT,
      styledValue: new LineHeightStyle(LengthMetrics.vp(30))
    },
    {
      start: 1,
      length: 2,
      styledKey: StyledStringKey.FONT,
      styledValue: new TextStyle({ fontColor: '#FFD700', fontWeight: FontWeight.Bold })
    },
    {
      start: 4,
      length: 2,
      styledKey: StyledStringKey.FONT,
      styledValue: new TextStyle({ fontColor: '#FFD700', fontWeight: FontWeight.Bold })
    }
  ])
  controller: TextController = new TextController();

  build() {
    Row() {
      Column( { space : 5 }) {
        Text(undefined, { controller: this.controller })
          .width(240)
          .copyOption(CopyOptions.InApp)
          .draggable(true)
          .onAppear(()=>{
            this.paragraphStyledString2.appendStyledString(this.paragraphStyledString3)
            this.paragraphStyledString1.appendStyledString(this.paragraphStyledString2)
            this.controller.setStyledString(this.paragraphStyledString1)
          })

        Button("Renew")
          .width(200)
          .fontColor(Color.White)
          .fontSize(18)
          .backgroundColor('#3CB371')
          .margin({ bottom: 10 })
      }
      .borderWidth(1).borderColor('#FFDEAD')
      .margin({ left: 10 })
    }
    .height('60%')
  }
}
```
![StyledString_SceneDemo](figures/styledString_sceneDemo.png)
#The following is a description of the image (format: png/jpg/jpeg/gif) that appeared in the previous text: 
##Image Name: span_string_init.png
###Image description: The image contains two phrases written in a simple, sans-serif font. The phrases are:

1. "45-minute workout"
2. "35-minute workout"

These phrases are likely referring to different workout durations, with "45-minute workout" indicating a longer duration compared to the "35-minute workout." The text is presented in a straightforward manner, with no additional decorative elements or images. The font color appears to be black on a white background, making the text easily readable.
##Image Name: StyledString_TextStyle.png
###Image description: The image is a simple, rectangular graphic with a white background. It contains text in black, bold, sans-serif font. The text is divided into two lines. The first line reads "35-minute workout," and the second line reads "goal achieved." The text is centered horizontally and vertically within the image. The phrase "goal achieved" is slightly larger and bolder than the first line, emphasizing the accomplishment. The overall design is minimalistic and straightforward, focusing on conveying the message clearly and effectively. 

### Analysis and Description:

1. **Text Content**:
   - The first line of text reads "35-minute workout," indicating that the workout duration is 35 minutes.
   - The second line reads "goal achieved," which suggests that the goal of completing a 35-minute workout has been successfully accomplished.

2. **Typography**:
   - The font used is bold and sans-serif, which makes the text easy to read and emphasizes the importance of the message.
   - The size of the text is consistent, with "35-minute workout" being slightly smaller than "goal achieved," but both are clearly visible and readable.

3. **Color Scheme**:
   - The background is white, which provides a clean and neutral backdrop that makes the black text stand out prominently.
   - The text color is black, which contrasts sharply with the white background, ensuring high visibility and readability.

4. **Design Elements**:
   - The design is minimalistic, with no additional graphics or images. This simplicity helps to focus the viewer's attention on the text message.
   - The centered alignment of the text ensures that it is balanced and visually appealing.

5. **Contextual Implications**:
   - The image likely serves as a motivational or celebratory message, possibly used in a fitness or wellness context.
   - It could be part of a workout program, a fitness app, or a personal achievement tracker.

### Answer to Potential Questions:

**Q: What is the purpose of this image?**
A: The purpose of this image is to celebrate the achievement of completing a 35-minute workout. It serves as a motivational or celebratory message, likely used in a fitness or wellness context.

**Q: How does the design contribute to the message?**
A: The design contributes to the message by using a clean, minimalistic layout with bold, sans-serif text. The centered alignment and contrasting colors (white background and black text) ensure that the message is clear and easily readable. The simplicity of the design helps to focus the viewer's attention on the accomplishment, making the message impactful and memorable.

**Q: What can be inferred about the target audience?**
A: The target audience is likely individuals who are engaged in fitness or wellness activities, particularly those who track their workout durations. The message is tailored to motivate and celebrate the completion of a specific workout goal, suggesting that the audience values their fitness progress and achievements.
##Image Name: styled_string_text_shadow.png
###Image description: The image contains the text "35-minute workout."
##Image Name: styled_string_decoration.png
###Image description: The image contains the text "35-minute workout."
##Image Name: styled_string_baselineoffset.png
###Image description: The image contains a text that reads "35-minute workout." This text is written in a simple, sans-serif font and is centered in the image. The background of the image is plain white, which makes the text stand out clearly. The text is black, which provides a high contrast against the white background, making it easy to read.

### Analysis and Description:

1. **Text Content**:
   - The text "35-minute workout" is the primary focus of the image. It suggests that the image is likely related to a workout routine or exercise plan that lasts for 35 minutes. This could be a part of a fitness program, a workout guide, or an advertisement for a fitness product or service.

2. **Typography**:
   - The font used is sans-serif, which is characterized by its clean and modern appearance. Sans-serif fonts are often used in digital contexts due to their readability and clarity.
   - The text is centered, which is a common design choice for titles or headings as it creates a balanced and symmetrical look.

3. **Color Scheme**:
   - The text is black, which is a neutral color that contrasts well with the white background. This color choice ensures that the text is highly visible and easy to read.

4. **Background**:
   - The background is plain white, which is a common choice for text-heavy images as it helps to keep the focus on the text without any distractions.

### Relevant Knowledge Integration:

- **Workouts and Fitness**:
  - A 35-minute workout is a relatively short duration, which might be suitable for individuals who have limited time but want to maintain a regular fitness routine. It could include a combination of cardiovascular exercises, strength training, and flexibility exercises.
  - The duration of 35 minutes is often considered a good balance between time efficiency and effectiveness, allowing for a comprehensive workout that can target multiple fitness components.

- **Design Principles**:
  - The use of a sans-serif font and a centered layout is a common design principle in creating clear and effective headings. This design choice is effective in drawing attention to the main message and ensuring that the text is easily readable.

### Conclusion:

The image is a straightforward representation of a 35-minute workout, likely intended to convey the idea of a brief yet effective fitness routine. The design choices, including the use of a sans-serif font and a centered layout, are effective in ensuring that the text is clear and easy to read. This type of image could be used in various contexts, such as fitness blogs, workout apps, or promotional materials for fitness products.
##Image Name: styled_string_lineHeight.png
###Image description: The image contains two lines of text. The first line reads "35-minute workout," and the second line reads "Fighting Achieved."
##Image Name: styled_string_letterspacing.png
###Image description: The image contains the text "3 5-minute workout."
##Image Name: styledstringParagraphs.png
###Image description: The image depicts a diagram illustrating the structure of a `StyledString` object in a programming context. The `StyledString` object is composed of two `Paragraph` objects, labeled as `paragraph1` and `paragraph2`. 

Here is a detailed description of the diagram:

1. **`StyledString` Object**: This is the main object in the diagram. It is represented as a rectangle with the text "StyledString\nText" inside it. The `\n` character indicates a line break, suggesting that the text is formatted with multiple lines.

2. **`Paragraph` Objects**: There are two `Paragraph` objects within the `StyledString` object. 
   - The first `Paragraph` object is labeled `paragraph1` and is positioned above the `StyledString` object.
   - The second `Paragraph` object is labeled `paragraph2` and is positioned below the `StyledString` object.

3. **Arrows**: There are two arrows in the diagram:
   - An arrow pointing from `paragraph1` to the `StyledString` object, indicating that `paragraph1` is a part of the `StyledString`.
   - An arrow pointing from `paragraph2` to the `StyledString` object, indicating that `paragraph2` is also a part of the `StyledString`.

The diagram visually represents the hierarchical structure of the `StyledString` object, showing how the `Paragraph` objects are nested within it. This structure is typical in text formatting systems where different paragraphs can be styled independently but are part of a larger text structure.
##Image Name: StyledStringImageAttachment.png
###Image description: The image is an advertisement for a product that offers 30 HD prints at a discounted price. The advertisement is presented in a clear and straightforward manner, with the following key elements:

1. **Product Description**: The top part of the advertisement states "30 HD prints," indicating that the product being advertised is a set of 30 high-definition prints.

2. **Discount Information**: Below the product description, there is a discount offer. It reads "CYN5.15 off," which means that the original price is reduced by 5.15 Chinese Yuan (CYN). This discount is highlighted to draw attention to the savings.

3. **Price**: The price of the 30 HD prints is prominently displayed as "¥16.21." This is the final price after the discount has been applied.

4. **Limited Offer**: The advertisement includes the phrase "Limited offer," suggesting that the discount is available for a limited time, which can create a sense of urgency for potential buyers.

5. **Customer Reviews**: The advertisement mentions "3000+ reviews," indicating that the product has received positive feedback from a significant number of customers. This can be used to build trust and credibility with potential buyers.

6. **Visual Element**: The background of the advertisement features a serene beach scene with a tree and a clear sky, which may be intended to evoke a sense of relaxation and enjoyment, potentially appealing to customers looking for high-quality prints of scenic images.

### Analysis and Description

The advertisement is designed to attract customers by highlighting the savings available through the discount. The use of a clear and concise layout makes it easy for potential buyers to understand the offer at a glance. The mention of the high number of reviews adds a layer of credibility, suggesting that the product is well-regarded by previous customers. The scenic background image is likely chosen to appeal to customers who are interested in high-definition prints of natural landscapes, potentially enhancing the appeal of the product.

### Answer to Potential Questions

**Q: What is the price of the 30 HD prints after the discount?**
A: The price of the 30 HD prints after the discount is ¥16.21.

**Q: How much is the discount on the 30 HD prints?**
A: The discount on the 30 HD prints is CYN5.15.

**Q: How many reviews does the product have?**
A: The product has over 3000 reviews.

**Q: What is the main visual element in the advertisement?**
A: The main visual element in the advertisement is a serene beach scene with a tree and a clear sky.

**Q: What does the "Limited offer" signify?**
A: The "Limited offer" signifies that the discount is available for a limited time, creating a sense of urgency for potential buyers to take advantage of the deal.

By providing a detailed description and analysis of the advertisement, a text model can effectively answer any related questions based on the provided information.
##Image Name: StyledString_CustomSpan_Scene.PNG
###Image description: The image displays a promotional banner with the following text:

- "99VIP" is prominently displayed in the upper left corner of the banner.
- Below "99VIP," there is a percentage value "88%" in a slightly smaller font size, indicating a discount or special offer.
- The text "99VIP" is in a bold, black font with a slight gradient effect, making it stand out against the background.
- The percentage "88%" is in a similar black font but with a lighter shade, providing a subtle contrast to the bold text above it.
- The background of the banner is a gradient of dark colors, transitioning from black at the top to a slightly lighter shade towards the bottom, which helps to highlight the text.

### Analysis and Description

The image is a promotional banner likely used for an online shopping platform or a digital service. The term "99VIP" suggests a VIP membership or a special tier, often associated with exclusive benefits or discounts. The "88%" off indicates a significant discount, which is a common tactic used to attract customers by offering substantial savings on products or services.

### Relevant Knowledge

VIP memberships are often used by companies to reward loyal customers or to incentivize purchases. Memberships can offer various benefits such as exclusive access to sales, discounts, early access to new products, or personalized customer service. The percentage "88%" off is a strong incentive, as it implies that customers can save nearly 90% of the original price, making the offer highly attractive.

### Answer to Potential Questions

1. **What does "99VIP" signify?**
   - "99VIP" likely refers to a VIP membership or a special tier that offers exclusive benefits or discounts.

2. **What is the discount being offered?**
   - The discount being offered is 88%, meaning customers can save 88% off the original price.

3. **What is the purpose of the banner?**
   - The purpose of the banner is to promote a special offer or discount for VIP members, encouraging them to take advantage of the savings.

4. **What can be inferred about the target audience?**
   - The target audience is likely existing customers who have already signed up for the VIP membership, as the offer is specifically for them.

5. **What is the significance of the gradient background?**
   - The gradient background serves to draw attention to the text by creating a visual contrast, making the promotional message more noticeable and appealing to the viewer.

By providing a detailed description and analysis of the image, a text model can effectively answer any related questions based on the information presented.
##Image Name: styledString_sceneDemo.png
###Image description: The image is a screenshot of a membership renewal notification. The text on the image reads:

---

**Diamond Membership expired**

**Renew to keep your perks**

**¥4.88 ¥15**

**Offer ends in 02:06**

**Renew**

---

### Detailed Description:

1. **Header Text:**
   - The top line of the image states, "Diamond Membership expired," indicating that the user's current membership has lapsed.

2. **Perks Reminder:**
   - Below the expiration notice, it says, "Renew to keep your perks," suggesting that renewing the membership will maintain the user's current benefits.

3. **Membership Cost:**
   - The cost of renewing the membership is displayed as ¥4.88, which is significantly lower than the original price of ¥15. This indicates a discount or special offer.

4. **Offer Duration:**
   - The text "Offer ends in 02:06" informs the user that the current offer will expire in 2 minutes and 6 seconds. This urgency is likely intended to encourage the user to renew quickly.

5. **Renew Button:**
   - At the bottom of the image, there is a green button labeled "Renew," which the user can click to proceed with the renewal process.

### Analysis:

- **Membership Status:** The user's Diamond Membership has expired, and they need to renew to continue enjoying their perks.
- **Discounted Renewal:** The renewal cost is significantly reduced from ¥15 to ¥4.88, making it an attractive offer for the user.
- **Time Sensitivity:** The offer is time-limited, ending in 2 minutes and 6 seconds, which adds a sense of urgency to the renewal process.

### Conclusion:

The image is a clear and concise notification for a membership renewal, emphasizing the urgency of the offer and the discounted price. The user is prompted to renew their Diamond Membership to maintain their perks, with a clear indication of the remaining time for the offer.
